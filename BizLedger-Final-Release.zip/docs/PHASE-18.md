# BizLedger Phase 18 — Reliability & Recovery

Phase 18 adds database-backed reliability controls without changing the accounting meaning of existing records.

## Added

- `financial_operation_keys` for tenant-scoped idempotency keys.
- Idempotent wrappers for critical sale, purchase, expense, payment, loan-payment and withholding-remittance operations.
- `application_error_events` for tenant-scoped application error reporting.
- `report_application_error()` RPC.
- `get_reliability_report()` read-only diagnostic RPC.
- `/reliability` operational screen.

## Recovery model

A retry can reuse the same operation key. If the original operation completed, the wrapper returns the original result UUID instead of intentionally creating a second transaction.

An operation without a result remains visible. Operations older than 15 minutes without a result are flagged as stale for investigation.

## Safety

This phase does not automatically repair financial records. It surfaces incomplete or failed operations so an authorized operator can investigate them using the audit trail and accounting integrity checks.

## Production note

Remote Supabase migration execution and a production TypeScript/Vite build were not performed in this environment. The migration and source changes were assembled and the project archive was integrity-checked locally.
