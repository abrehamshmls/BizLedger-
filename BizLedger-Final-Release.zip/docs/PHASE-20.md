# BizLedger Phase 20 — Commercial Production Enforcement

Phase 20 turns the existing subscription foundation into a database-enforced commercial boundary.

## Included

- Effective subscription status handling.
- Free-plan continuation after an expired trial.
- Subscription feature checks.
- Member, product and monthly sales-invoice capacity enforcement.
- Production, loan and withholding feature gates.
- Provider-neutral commercial status RPC for the UI.
- Database enforcement rather than client-only feature hiding.

## Plans already defined by Phase 5

- FREE
- STARTER
- BUSINESS
- PRO

The phase does not invent new prices or connect a payment provider. Existing Phase 5 prices/features remain the source of truth until a real provider and final commercial pricing are selected.

## Safety boundary

The database rejects premium operations when the organization does not have the corresponding feature. The browser may hide premium navigation for usability, but direct API calls cannot bypass the same subscription checks.

## Verification limitation

This phase has been statically inspected and packaged. A live Supabase migration and production TypeScript/Vite build still require the actual deployment environment and credentials.
