# BizLedger Phase 19 — Production Observability & Recovery

Phase 19 adds a database-backed production operations check and a privacy-safe operational dashboard.

## Added

- `recovery_check_runs` for audited recovery-check results.
- `run_production_recovery_checks(org)` for read-only checks of:
  - unbalanced posted journal entries;
  - stale incomplete idempotency operations;
  - unresolved migration rows.
- `get_production_release_report(org)` for operational release status.
- `/operations` UI for production checks and recovery guidance.
- Backup/restore runbook documentation.

## Scope boundary

BizLedger does not pretend that an application can replace provider-level PostgreSQL backups. Actual backup retention, point-in-time recovery, restore testing, secrets management and infrastructure monitoring remain deployment responsibilities.

No third-party telemetry SDK is required by this phase. Application errors remain tenant-scoped in BizLedger. If Sentry or another provider is enabled later, only privacy-safe event metadata should be sent and financial payloads should remain excluded.

## Verification limitation

This phase was assembled and statically inspected in the project environment. A live Supabase deployment and production Vite/TypeScript build were not available for execution, so this phase does not claim a successful remote deployment.
