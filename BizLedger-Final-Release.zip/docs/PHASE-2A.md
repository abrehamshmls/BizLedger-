# BizLedger Phase 2A — Accounting Core

## Delivered

1. Default chart of accounts is created automatically for each organization.
2. Posted sales create balanced journal entries:
   - Customer receivable
   - Sales revenue
   - Tax payable when tax exists
   - Withholding tax receivable when withholding exists
3. Posted purchases create balanced journal entries:
   - Inventory
   - Input tax receivable when tax exists
   - Supplier payable
   - Withholding tax payable when withholding exists
4. Customer and supplier payments create balanced journal entries against cash/bank and receivable/payable accounts.
5. Customer receivables, supplier payables and cash/bank balances are exposed through database views.
6. Dashboard metrics now read from the accounting data instead of hard-coded zero values.
7. Posting is auditable through `audit_logs`.

## Important accounting boundary

Inventory quantity movement and cost-of-goods-sold valuation are deliberately not finalized in Phase 2A. The existing application supports inventory movements and production, but a reliable valuation method must be selected and implemented before the new system calculates COGS or inventory profit effects.

Phase 2B will implement inventory valuation, stock movement posting, production costing and COGS using a consistent method.

## Posting rules

A source document remains `DRAFT` until explicitly posted. Once posted, the accounting engine creates a balanced journal transaction. Posted source documents should not be silently edited or deleted; later corrections should use controlled reversal/adjustment transactions.

## Database migration

Apply migration:

`supabase/migrations/005_accounting_core.sql`

The migration is designed for the Phase 1C/1D schema and should be applied after migrations 001–004.

## Frontend

`apps/web/src/lib/accounting.ts` provides the dashboard summary queries. The dashboard now displays live sales, receivable, payable and cash/bank balances.

## Verification checklist

- Create an organization and confirm the default chart of accounts exists.
- Create a draft sale, then post it and confirm the journal debits equal credits.
- Create a draft purchase, then post it and confirm the journal debits equal credits.
- Record an incoming customer payment and verify receivables decrease and cash/bank increases.
- Record an outgoing supplier payment and verify payables decrease and cash/bank decreases.
- Confirm a user in organization A cannot read organization B's records.
