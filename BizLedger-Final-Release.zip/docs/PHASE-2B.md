# BizLedger Phase 2B — Inventory & Costing

## Costing policy

BizLedger now uses **per-product weighted-average costing**. Each inventory movement stores a unit cost. Incoming stock carries its purchase/opening/production cost; outgoing stock is assigned the weighted-average cost immediately before the issue.

## Controls

- Negative stock is rejected when posting a sale, production input, or other outbound movement.
- Inventory quantity is derived from inventory movements.
- Average cost is derived from the same movement ledger.
- Inventory value is quantity × weighted-average cost.
- Posted sales create COGS and reduce inventory in the accounting journal.
- Posted inventory purchases create inventory movements for tracked products.
- Non-inventory purchase lines are posted to operating expenses rather than inventory.
- Production can have multiple inputs and multiple outputs. Input cost is transferred into output inventory using total input cost / total output quantity.
- Opening inventory creates an inventory movement and opening-equity journal.
- Quantity adjustments are recorded as inventory movements with an accounting offset.

## Important implementation rule

Users should not directly edit historical inventory movements after posting. Corrections should be represented by reversal/adjustment transactions so the inventory and accounting audit trail remains intact.

## Remaining costing work

Future phases can add explicit costing configuration, stock-count workflows, batch/serial tracking where needed, and period closing controls. FIFO is not enabled by this migration; the current engine is weighted-average only.
