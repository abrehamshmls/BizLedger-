# Phase 14 — Migration Reconciliation & Cutover

Phase 14 adds a read-only reconciliation center and an explicit migration sign-off gate.

## Reconciliation checks

- Staged legacy sales vs imported BizLedger sales.
- Staged purchases vs imported purchases.
- Staged expenses vs imported expenses.
- Legacy transaction payments vs imported payments.
- Current receivables and payables for imported documents.
- Total posted journal debits vs credits.
- Duplicate staged document keys.
- Imported/review/error/skipped coverage by migration module.
- Unresolved migration rows.

## Safety

The reconciliation function does not create sales, purchases, payments, inventory movements, loans, or withholding records. Sign-off is separate and requires every current gate to pass. A signed-off run is written to `migration_reconciliation_runs` and to the audit log.

## UI

A new `/migration/reconciliation` page is available from the Migration navigation. Enter the migration batch UUID, run reconciliation, review the comparison, then explicitly sign off if all gates pass.

## Verification note

The project environment has not completed a dependency-backed Vite production build; previous `npm install` attempts timed out. The source and ZIP structure were checked directly.
