# BizLedger Production Operations Runbook

## Before release

1. Confirm the target database backup/PITR policy is active.
2. Record the application and migration versions.
3. Review the migration SQL for destructive operations.
4. Deploy during a controlled maintenance window for financial schema changes.
5. Run `/operations`, `/integrity`, and `/reliability` after deployment.

## Backup

Use the managed PostgreSQL/Supabase backup and point-in-time recovery facilities configured for the production project. Do not treat browser exports as the authoritative accounting backup.

## Restore

1. Stop financial writes.
2. Identify the last known-good database timestamp.
3. Restore through the provider/database recovery mechanism.
4. Verify authentication and organization isolation.
5. Run accounting integrity and recovery checks.
6. Reconcile financial totals before reopening writes.
7. Record the incident and recovery timestamp in the operational log.

## Privacy

Do not send invoice lines, customer names, TINs, bank details, journal lines, or other financial payloads to third-party telemetry. Error events should contain only operational metadata needed to diagnose software failures.
