# BizLedger Phase 15 — Migration completion and cutover

Phase 15 completes the controlled migration boundary for the remaining legacy modules and adds a database-enforced final cutover lock.

## Remaining modules

- Opening inventory candidates
- Production batches (legacy one-input / up-to-two-output structure)
- Loan disbursements
- Loan repayments matched by legacy loan ID
- Withholding received
- Withholding collected
- Withholding remittances

## Inventory rule

The legacy inventory table contains movement direction and quantity but not a reliable unit valuation. Positive inbound movements are treated as opening candidates and use the target product purchase price as the explicit migration valuation rule. Other historical movements are retained as reconciliation/review items instead of silently creating accounting values.

## Reconciliation

The completion function compares imported quantities/amounts against source staging for inventory, loans, repayments and withholding. Any unresolved financial row or unreviewed inventory movement blocks final cutover.

## Cutover lock

After reconciliation passes, an authorized user can lock the organization. Database triggers prevent normal inserts, updates, and deletes on core financial and migration-relevant tables while locked. An audited unlock requires a member-management permission and a written reason.

## Important sequencing

Core financial imports can create inventory movements and COGS. Therefore opening inventory should exist before importing sales/purchases that require stock. If an earlier financial import failed because opening stock was absent, the batch remains transactional and can be retried after the required opening stock is imported.
