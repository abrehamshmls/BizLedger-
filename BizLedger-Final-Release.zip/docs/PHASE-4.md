# BizLedger Phase 4 — Reports & Documents

## Delivered
- Period-aware financial reporting foundation.
- Trial balance, Profit & Loss, Balance Sheet account views.
- Receivables and payables period lists with payment deductions.
- Printable sales invoices with Ethiopian/Gregorian date display.
- Printable payment receipts.
- `/documents` workspace for invoices and receipts.
- Supabase reporting RPCs protected by organization membership.

## Accounting note
Reports use posted accounting transactions and posted operational documents. Draft documents are excluded from financial summaries.

## Next
Phase 5 — subscriptions, plans, SaaS administration, usage limits, billing integration, and production deployment hardening.
