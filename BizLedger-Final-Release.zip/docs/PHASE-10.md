# BizLedger Phase 10 — Controlled Master Data Import

Phase 10 turns validated migration staging into the first controlled production import step.

## Scope

Only legacy **contacts** and **products** are imported in this phase. Sales, purchases, expenses, payments, inventory, production, loans and withholding remain staged and are not posted.

## Matching rules

- Contacts: exact normalized name + TIN match first; otherwise create a new contact.
- Products: SKU match first; otherwise exact normalized product name; otherwise create a new product.
- Every imported/matched row receives a `migration_mappings` record.
- The batch must already be `VALIDATED`.
- Import requires explicit confirmation and is transactional.

## Why master data first

Document migration depends on stable contact/product UUIDs. Establishing those mappings before financial documents prevents orphaned references and makes the later sales/purchases/payment migration auditable.

## Next stage

Use the stored mappings to transform legacy sales and purchases into document headers/lines, resolve payments to source documents, and produce a financial reconciliation report before any posting.
