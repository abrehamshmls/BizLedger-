# Phase 23 — Complete Multi-Organization Isolation

Phase 23 removes remaining frontend assumptions that the first active organization is the selected organization.

## Updated modules

- Dashboard accounting summaries
- Contacts and products refresh when organization changes
- Sales and payment account selection
- Purchases and expenses
- Inventory movement/product lists
- Production
- Loans and repayment account lists
- Withholding received/collected/remittance workflows
- Financial reports
- Printable invoices and receipts
- Subscription/billing state and upgrade requests
- Team management
- Audit log
- Business settings and chart of accounts

## Database support

`025_complete_multi_org_isolation.sql` adds `assert_active_organization()` and `organization_context_status()` for explicit server-side validation of the selected organization. RLS remains the authorization boundary.

## Safety

The browser's selected organization is context, not authority. Every organization-scoped read/write added in this phase carries the selected organization ID where the table supports it, while protected RPCs continue to validate the underlying source record and permissions.

## Verification limitation

A live Supabase deployment and full production Vite/TypeScript build were not executed in this environment.
