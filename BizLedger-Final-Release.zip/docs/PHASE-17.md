# BizLedger Phase 17 — Production Security Hardening

Phase 17 tightens the browser/API boundary so users cannot bypass BizLedger's accounting workflows by directly editing posted financial records.

## Main changes

- Split RLS into read/manage policies for master data.
- Sales, purchases and expenses can only be inserted/edited/deleted while `DRAFT`.
- Posting and voiding remain controlled by existing RPC workflows.
- Payment rows are append-only from the browser.
- Inventory, production, loans and withholding are read-only through the browser; existing controlled RPCs remain the write path.
- Financial journal transactions and journal lines are read-only through the browser.
- Audit logs are read-only through the browser.
- Roles, permissions and role-permission definitions are read-only through the browser.
- Added `is_cutover_locked(org)` as a database helper for financial workflows.

## Security model

The browser is treated as an untrusted client. RLS determines what the authenticated user may read or directly mutate, while `SECURITY DEFINER` posting/recording functions remain responsible for accounting mutations.

## Important implementation note

The existing workflow functions must continue to enforce their own organization, permission, status and accounting checks. Phase 17 does not replace those checks; it adds another protection layer at the table boundary.

## Verification

This phase was statically inspected against the existing Phase 16 schema and frontend write paths. A full remote Supabase migration/test run was not available in the build environment, so deployment-time SQL execution remains required before production use.
