# BizLedger Phase 7 — Production Launch & Migration Foundation

## Added
- Secure invitation creation that returns a one-time plaintext token only to the authorized inviter.
- Invitation acceptance RPC that hashes the supplied token, verifies expiry and matching authenticated email, and activates the organization membership.
- `/invite/:token` acceptance route.
- Team invitation UI copies the generated invitation link when clipboard access is available.
- Invitation acceptance and creation are recorded in the organization audit log.
- Launch documentation covering environment setup, Supabase migration order, Vercel deployment, backups, monitoring, billing webhooks, and migration/reconciliation.

## Important operational boundary
The repository does not attempt to manufacture external credentials or pretend that backups, email delivery, payment processing, or production monitoring are configured. Those require the owner's real Supabase, Vercel, email, payment-provider, and monitoring accounts.

## Migration principle
Legacy data should be imported into a staging organization first, validated, reconciled against the original export, and only then promoted to production. Financial documents should retain their original references and never be silently deleted or rewritten during migration.
