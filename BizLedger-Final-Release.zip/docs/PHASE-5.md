# BizLedger Phase 5 — SaaS Commercialization Foundation

Phase 5 introduces subscription infrastructure without coupling the accounting engine to a payment provider.

## Included
- Free, Starter, Business and Pro plan catalog.
- Organization-level subscription state.
- Trial period support.
- Provider/customer/subscription identifiers for future payment integrations.
- Subscription event/audit storage for webhook processing.
- Feature/usage limits stored with each plan.
- Tenant-aware RLS.
- Existing organizations automatically receive a Free-plan trial record.
- In-app subscription page showing current plan, limits and status.

## Billing provider boundary
The database deliberately stores `provider`, `provider_customer_id`, and `provider_subscription_id` rather than hard-coding a payment processor. A production payment adapter can be added later for an Ethiopian payment provider or international processor, with signed webhook handling writing to `subscription_events` and updating `organization_subscriptions`.

## Important
Prices in this migration are starter configuration values, not a final commercial pricing decision. They should be reviewed before launch.
