# BizLedger — Production Candidate

This package is the consolidated production-candidate build after the Phase 24 accounting workflow hardening work.

## What is included

- Multi-organization SaaS architecture with PostgreSQL/Supabase RLS.
- Authentication, roles, permissions, invitations, audit logging.
- Contacts, products, sales, purchases, expenses, payments.
- Weighted-average inventory and production workflows.
- Loans, repayments, withholding and financial reporting.
- Ethiopian/Gregorian date support.
- Legacy JSON migration, staged validation, controlled financial import, reconciliation and cutover controls.
- Subscription plans, feature/usage enforcement and onboarding.
- Reliability, operational integrity and accounting diagnostics.
- Database-level financial posting validation and tenant-boundary checks.

## Production prerequisites

1. Create the production Supabase project.
2. Apply `supabase/migrations/*.sql` in filename order.
3. Configure the web application's Supabase URL and anonymous key using `apps/web/.env.example`.
4. Create the first organization through the onboarding flow.
5. Test authentication, organization switching and RLS with at least two test organizations.
6. Run the accounting workflow diagnostics on the test organization.
7. Test sale, purchase, payment, inventory, production, loan and withholding workflows with representative data.
8. Test the legacy migration using a copy of the real backup before any production cutover.
9. Configure provider-level database backups/PITR and test restoration outside the application.
10. Configure the production hosting environment and domain.

## Important verification limitation

This environment does not have the project's live Supabase credentials, and `npm install` timed out while attempting to obtain dependencies. Therefore this package must be treated as a **production candidate**, not as proof of a successful live deployment or production build.

## Release principle

Do not import real financial history into production until the migration reconciliation screen reports acceptable results and the business owner has reviewed the cutover decision.
