# BizLedger — Final Launch Checklist

## Before production
- [ ] Create production Supabase project.
- [ ] Apply migrations `001` through `026` in filename order.
- [ ] Configure `VITE_SUPABASE_URL` and `VITE_SUPABASE_ANON_KEY`.
- [ ] Create a test owner account and organization.
- [ ] Test two organizations with separate users and confirm RLS isolation.
- [ ] Test sale, purchase, payment, expense, inventory, production, loan, repayment, withholding and reports.
- [ ] Run accounting workflow and operational diagnostics.
- [ ] Configure database backups/PITR and perform a restore test.
- [ ] Import a copy of the legacy backup into staging and review migration reconciliation.
- [ ] Only after reconciliation is accepted, perform production cutover.

## Build verification
The repository contains the normal Vite/TypeScript build command:

`npm run build`

The included environment could not complete `npm install`, so dependency installation and the final production build must be executed in the deployment/CI environment.

## Release rule
No real financial migration should be performed until the live deployment passes authentication, RLS isolation, accounting workflow, reconciliation, backup/restore, and browser smoke tests.
