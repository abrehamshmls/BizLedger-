# Phase 22 — Organization Context & Multi-Organization UX

## Goal
Allow a user who belongs to multiple businesses to select the active organization explicitly.

## Changes
- Added organization switcher to the application header.
- Selected organization is persisted locally under `bizledger_active_org`.
- Stored selection is validated against the user's current ACTIVE memberships on every authenticated load.
- Sign-out clears the selected organization.
- Contacts, products, purchases, and expenses now explicitly scope reads and writes to the selected organization.
- Added `user_has_active_membership(uuid)` as a reusable database membership check.
- Added an index supporting active-membership lookup.

## Security boundary
The selected organization ID is a UX context, not an authorization mechanism. PostgreSQL RLS and permission checks remain authoritative. The browser cannot grant itself membership by changing local storage.

## Remaining follow-up
Several older modules predate the organization-context component pattern and still resolve their organization internally. They should be migrated to receive the active membership explicitly in a subsequent cleanup phase rather than pretending the switcher alone makes every legacy component multi-organization aware.
