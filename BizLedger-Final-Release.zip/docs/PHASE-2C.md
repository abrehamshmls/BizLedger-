# BizLedger — Phase 2C

## Transaction UI

Phase 2C connects the new React application to the accounting and inventory engine for the first operational workflows.

### Delivered
- Contacts: shared customer/supplier directory with TIN, trade license, phone and email.
- Products: SKU, unit, purchase/sales prices, inventory tracking and module flags.
- Sales: draft invoice creation, one-line sale entry, posting, tax/withholding fields and receipt workflow.
- Purchases: draft supplier invoice creation, one-line purchase entry, posting and payment workflow.
- Payments: cash/bank account selection and server-side accounting entry through `record_payment_for_source`.
- Inventory: dashboard summary, movement ledger and opening-stock workflow.
- Expenses: draft expense capture.
- Navigation shell for remaining modules.

### Important behavior
- Sales and purchases remain `DRAFT` until the user presses **Post**.
- Posting calls the database accounting functions rather than writing journal lines from the browser.
- Posted stocked sales calculate COGS and inventory movement in the database.
- Posted stocked purchases create inventory movements in the database.
- Payment recording resolves the organization from the source document rather than trusting a browser-supplied organization id.

### Known next work
- Multi-line sales/purchases editor.
- Full expense posting and payment integration.
- Production UI and production costing.
- Loans and withholding workflows.
- Edit/void/reversal workflows.
- Permission-aware UI actions.
- Ethiopian calendar/date display and fiscal-year controls.
- Reports and printable invoices/receipts.
