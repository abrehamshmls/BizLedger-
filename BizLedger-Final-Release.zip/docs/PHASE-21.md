# Phase 21 — Customer Experience & Launch Readiness

## Scope
Phase 21 improves first-run usability without changing the accounting engine.

### Added
- Dashboard first-run checklist.
- Live onboarding completion counts for contacts, products, inventory activity, and sales.
- Subscription activity warning when the effective commercial state is inactive.
- Direct navigation from checklist items to the relevant module.
- Dismissal persisted per organization in browser local storage.

## Safety
The checklist is informational and does not create accounting records. Inventory readiness is intentionally conservative: if the business has products, the checklist expects inventory activity; if no products exist, it does not block the user on inventory.

## Verification boundary
This phase was assembled and statically inspected in the project environment. A live Supabase deployment and full production Vite/TypeScript build were not available for verification in this environment.
