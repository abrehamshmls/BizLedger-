# BizLedger Phase 24 — Accounting & Workflow Completion

Phase 24 hardens the accounting boundary without rewriting historical records.

## Changes

- Journal posting now validates tenant ownership of every account.
- Journal lines must contain exactly one non-zero, non-negative side.
- Journal totals must balance to two decimal places.
- Added `assert_account_in_org()` for controlled workflow checks.
- Added `accounting_workflow_diagnostics(org)` for read-only production checks.
- Added indexes for source-document/journal lookup.

## Diagnostic checks

- Unbalanced posted journals
- Posted journals without lines
- Cross-organization journal lines
- Negative inventory
- Posted source documents without a journal
- Draft source documents that already have a posted journal

The diagnostics are read-only. They do not repair or rewrite accounting data.

## Scope boundary

This phase does not claim a live Supabase deployment or production build. Provider-level backups and deployment verification remain environment responsibilities.
