# BizLedger Phase 9 — Controlled Migration Staging

## Purpose
Phase 9 moves legacy migration from simple validation into a controlled staging workflow. Legacy JSON is analyzed locally, then copied into isolated migration tables only after the user explicitly chooses to stage it.

## Legacy coverage
The source application stores contacts and products in `CFG`, while transaction arrays include `cashbook`, `purchases`, `production`, `sales`, `expenses`, `inventory`, `loans`, `loanpay`, `wht`, `whc`, `txpay`, and `whremit`. Debtor/creditor arrays are retained as reconciliation references rather than duplicate ledgers.

## Safety boundary
Staging does not write to sales, purchases, expenses, payments, inventory, loans, withholding, accounts, or financial transaction tables. It stores raw legacy rows with a READY/ERROR status and an issues array.

## Validation
The client performs structural checks for dates, identifiers, positive quantities/amounts where required, negative principal/interest, and duplicate legacy sales invoice numbers or purchase voucher numbers. A batch with field errors or duplicate document identifiers remains unvalidated.

## Next import step
The next migration phase should:
1. Match contacts by legacy ID, TIN and normalized name.
2. Match products by legacy ID, SKU and normalized name.
3. Resolve source IDs into new UUIDs.
4. Convert legacy dates to canonical PostgreSQL dates.
5. Transform one-line legacy sales/purchases into the new document + line model.
6. Match legacy `txpay` rows to their source documents.
7. Reconcile cashbook balances.
8. Reconcile inventory quantity and weighted-average cost.
9. Reconcile loan principal/interest and repayment links.
10. Reconcile withholding received/collected/remittance records.
11. Produce a before/after reconciliation report.
12. Require explicit confirmation before any financial posting.

## Current limitation
This phase intentionally does not perform the final production import. That import should be implemented as a separate controlled operation after staging has been reviewed.
