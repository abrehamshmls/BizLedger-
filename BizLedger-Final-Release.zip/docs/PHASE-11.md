# BizLedger Phase 11 — Financial Migration Dry-Run

Phase 11 introduces a controlled, server-staged dry-run for legacy financial records.

## Covered modules
- sales
- purchases
- expenses
- txpay payments
- cashbook
- inventory
- production
- loans
- loanpay
- withholding received/collected/remittances

## Safety
No Phase 11 function creates or posts records in the accounting tables. Proposed rows live in `migration_financial_rows` and retain the original JSON payload for review.

## Current transformation behavior
- Canonical ISO dates are accepted when available.
- Amount and quantity hints are normalized for review.
- Missing dates, invalid quantities/prices, and invalid required amounts become `ERROR` rows.
- Contact/product names are retained as matching hints for the next migration stage.
- Existing legacy debtor/creditor snapshots remain reconciliation references.

## Not yet imported
Sales, purchases, expenses, payments, inventory, production, loans, loan payments, withholding and journal entries are intentionally not posted in this phase.

## Next stage
Implement exact source-document matching and controlled import functions with an approval gate and before/after reconciliation totals.
