# BizLedger Phase 16 — Operational integrity diagnostics

Phase 16 adds a read-only production diagnostic layer.

## Checks

- Posted journal entries are balanced.
- Posted sales, purchases and expenses have matching posted journal entries.
- Payments reference accounts belonging to the same organization.
- Journal lines use accounts belonging to the same organization.
- Sale, purchase, inventory and production lines use products belonging to the same organization.
- Loan repayments reference loans in the same organization.
- Tracked products do not have negative net stock.
- The configured default payment account is valid and active.
- Audit log records contain an action.
- Current migration cutover state is surfaced.

## Safety

The diagnostics RPC is read-only and requires organization membership. It does not repair records automatically. A failed check is a finding for investigation rather than permission to mutate accounting data.

## UI

A new `/integrity` route is available from the main navigation as **Operational integrity**.
