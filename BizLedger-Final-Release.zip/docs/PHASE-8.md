# BizLedger Phase 8 — Ethiopian SME Readiness & Migration Foundation

## Implemented
- Migration Center for the legacy BizLedger JSON backup format.
- Browser-local structural validation: the selected file is parsed locally and is not uploaded automatically.
- Legacy module counts and destination mapping.
- Explicit migration warnings for cashbook, inventory, calendar preference, and legacy debtor/creditor arrays.
- Downloadable JSON validation report.
- Existing Ethiopian calendar utility retained as the presentation layer; PostgreSQL remains canonical Gregorian ISO dates.

## Legacy mapping
- `CFG.contacts` → `contacts`
- `CFG.products` → `products`
- `DATA.sales` → `sales` + `sale_lines`
- `DATA.purchases` → `purchases` + `purchase_lines`
- `DATA.expenses` → `expenses`
- `DATA.cashbook` → `payments` and/or `financial_transactions` after reconciliation
- `DATA.inventory` → `inventory_movements` after reconciliation
- `DATA.production` → `production_batches` + `production_lines`
- `DATA.loans` → `loans`
- `DATA.loanpay` → `loan_payments`
- `DATA.wht` → `withholding_received`
- `DATA.whc` → `withholding_collected`
- withholding remittance data → `withholding_remittances`
- legacy debtor/creditor arrays → derived balances, not duplicate tables

## Not yet automatic
No production import is performed by Phase 8. Before automatic import, implement field-level transforms, duplicate detection, foreign-key resolution, date validation, accounting reconciliation, inventory reconciliation, opening balances, and an explicit import confirmation.
