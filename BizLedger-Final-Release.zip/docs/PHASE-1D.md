# BizLedger Phase 1D — Authentication & Organization Onboarding

Implemented:
- Supabase email/password authentication.
- Persistent browser session and auth-state listener.
- First-login organization onboarding.
- Secure database RPC for organization creation.
- Automatic Owner role creation and assignment.
- All seeded permissions granted to the Owner role.
- Organization settings created automatically.
- Tenant-aware dashboard shell.

## Apply migration
Run `004_onboarding.sql` after the Phase 1C migrations.

## Local web setup
```bash
cd apps/web
cp .env.example .env.local
npm install
npm run dev
```

Set the Supabase URL and anon key in `.env.local`.

## Supabase Auth
Enable Email provider in Supabase Auth. If email confirmation is enabled, signup will require confirmation before the first session is established.

## Important
The dashboard metrics are placeholders in this phase. No financial totals are calculated here yet. Financial calculations begin in Phase 2.
