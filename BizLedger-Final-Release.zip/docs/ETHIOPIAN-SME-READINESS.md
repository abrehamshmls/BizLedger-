# Ethiopian SME readiness checklist

## Business identity
- Organization legal name
- TIN
- Trade licence
- Phone, email and address
- ETB base currency

## Dates
- Store canonical dates as Gregorian ISO/PostgreSQL `date`.
- Display Ethiopian dates where the organization enables Ethiopian calendar.
- Preserve Pagume handling.
- Keep fiscal year/month independent from display-calendar labels.

## Tax and withholding
- VAT/tax settings must be configurable per organization.
- Withholding received, collected and remitted records must retain TIN/reference/certificate information where available.
- Tax rules should be configurable rather than hard-coded into financial posting functions.

## Accounting
- Opening balances must be reconciled before production use.
- Receivables/payables must be derived from posted documents and payments.
- Inventory quantities and weighted-average costs must reconcile to the legacy source before cutover.

## Migration acceptance
1. Export legacy JSON backup.
2. Run Migration Center validation.
3. Resolve structural warnings.
4. Map and validate every foreign key.
5. Import into a staging organization.
6. Compare sales, purchases, payments, inventory, loans and withholding totals.
7. Reconcile opening balances.
8. Obtain business-owner confirmation.
9. Freeze legacy data.
10. Perform production cutover.
