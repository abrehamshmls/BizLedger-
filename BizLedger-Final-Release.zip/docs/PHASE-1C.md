# Phase 1C implementation notes

## Tenant boundary
Every organization-owned business table contains `organization_id`. PostgreSQL RLS is the second enforcement layer after application authorization.

## Money and quantity
- Money: `numeric(18,2)`
- Quantities: `numeric(18,6)`
- Dates: PostgreSQL `date`

The Gregorian date is canonical. Ethiopian-calendar display/conversion belongs in application services and reporting; it is not stored as the canonical date.

## Financial lifecycle
Sales, purchases and expenses support DRAFT, POSTED, PARTIALLY_PAID, PAID and VOIDED. Posted records should be reversed/voided rather than silently deleted.

## Receivables/payables
The new system does not keep duplicate debtor/creditor balance tables. Receivables are derived from posted sales and customer payments; payables from posted purchases and supplier payments.

## Migration
The existing JSON/Google-Sheets data should be handled by a separate migration pipeline:
1. Parse
2. Validate
3. Transform
4. Import
5. Reconcile totals

The migration must report warnings/errors rather than silently dropping records.
