# BizLedger Phase 2D — Complex Workflows

Phase 2D completes the core operational workflows around the Phase 2 accounting and inventory engine.

## Added
- Expense posting to the accounting ledger.
- Expense payment support through the common payment engine.
- Loan disbursement posting into cash/bank and loan liability.
- Loan repayment split between principal and interest.
- Loan closure when principal is fully repaid.
- Production batch posting with one or more inputs and outputs.
- Withholding received/collected registers and remittance journal posting.
- Posted-document reversal/void workflow for sales, purchases and expenses.
- Inventory reversal movements when a posted stock-linked sale or purchase is voided.
- Basic trial-balance/account-balance report.
- Business settings/chart-of-accounts view.

## Document lifecycle
`DRAFT -> POSTED -> PARTIALLY_PAID -> PAID`

Posted sales, purchases and expenses are not deleted as a normal edit operation. A void creates a reversing journal and marks the source `VOIDED`.

## Important limitation
A document with linked payments cannot currently be voided. Payments must first have their own reversal workflow implemented. This prevents silently leaving orphaned cash movements.

## Inventory policy
Weighted-average costing remains the active costing method. Production uses current average input cost and allocates the resulting input cost across output quantity.

## Migration
Apply migration `008_complex_workflows.sql` after migrations 001–007.
