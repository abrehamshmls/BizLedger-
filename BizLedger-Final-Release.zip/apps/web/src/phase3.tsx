import React, {useEffect, useState} from 'react';
import {formatEthiopian} from './lib/ethiopian';

export function DateField({value,onChange,required=false}:{value:string;onChange:(value:string)=>void;required?:boolean}){
  return <div className="date-field"><input className="date-input" type="date" value={value} onChange={e=>onChange(e.target.value)} required={required}/>{value&&<small className="date-secondary">{formatEthiopian(value)}</small>}</div>;
}

export function ToastHost(){
  const [message,setMessage]=useState<string|null>(null);
  useEffect(()=>{
    const handler=(e:Event)=>{const detail=(e as CustomEvent<string>).detail;setMessage(detail);window.setTimeout(()=>setMessage(null),3200)};
    window.addEventListener('bizledger:toast',handler); return()=>window.removeEventListener('bizledger:toast',handler);
  },[]);
  return message?<div className="toast" role="status">{message}</div>:null;
}

export function toast(message:string){ window.dispatchEvent(new CustomEvent('bizledger:toast',{detail:message})); }
