import { useMemo, useState } from 'react';
import { parseLegacyBackup, validateLegacyBackup, migrationWarnings, buildMigrationReport, type MigrationCheck } from './lib/legacyMigration';
import { toast } from './phase3';

function PageTitle({title,subtitle}:{title:string;subtitle?:string}){return <div className="page-heading"><div><h1>{title}</h1>{subtitle&&<p className="muted">{subtitle}</p>}</div></div>}

export function MigrationCenter(){
 const [checks,setChecks]=useState<MigrationCheck[]>([]); const [warnings,setWarnings]=useState<string[]>([]); const [error,setError]=useState(''); const [fileName,setFileName]=useState(''); const [report,setReport]=useState<any>(null);
 const ready=useMemo(()=>checks.filter(c=>c.status==='ready').reduce((n,c)=>n+c.count,0),[checks]);
 async function load(file:File){setError('');setFileName(file.name);try{const backup=parseLegacyBackup(await file.text());setChecks(validateLegacyBackup(backup));setWarnings(migrationWarnings(backup));setReport(buildMigrationReport(backup));toast('Legacy backup validated locally. No records were imported.');}catch(e){setChecks([]);setWarnings([]);setReport(null);setError(e instanceof Error?e.message:'Could not read backup.');}}
 function download(){if(!report)return;const blob=new Blob([JSON.stringify(report,null,2)],{type:'application/json'});const url=URL.createObjectURL(blob);const a=document.createElement('a');a.href=url;a.download='bizledger-migration-report.json';a.click();URL.revokeObjectURL(url);}
 return <><PageTitle title="Migration Center" subtitle="Validate a legacy BizLedger backup before any production import."/>
 <section className="card panel"><h2>1. Select legacy backup</h2><p className="muted">Use the JSON backup exported by the original BizLedger app. Validation runs in your browser; the file is not uploaded or imported automatically.</p><input type="file" accept="application/json,.json" onChange={e=>{const f=e.target.files?.[0];if(f)load(f)}}/>{fileName&&<p className="small muted">Loaded: {fileName}</p>}{error&&<div className="error">{error}</div>}</section>
 {checks.length>0&&<><div className="cards three"><div className="metric"><strong>{ready.toLocaleString()}</strong><span>Records detected</span></div><div className="metric"><strong>{checks.filter(c=>c.status==='ready').length}</strong><span>Populated modules</span></div><div className="metric"><strong>{warnings.length}</strong><span>Review items</span></div></div>
 <section className="card table-wrap"><table><thead><tr><th>Legacy section</th><th>Records</th><th>Destination</th><th>Status</th><th>Note</th></tr></thead><tbody>{checks.map(c=><tr key={c.key}><td>{c.label}</td><td>{c.count.toLocaleString()}</td><td>{c.destination}</td><td><span className={`status ${c.status}`}>{c.status}</span></td><td>{c.note}</td></tr>)}</tbody></table></section>
 <section className="card panel"><h2>Review before import</h2>{warnings.length?<ul>{warnings.map((w,i)=><li key={i}>{w}</li>)}</ul>:<p className="muted">No structural warnings were detected.</p>}<div className="actions"><button onClick={download}>Download validation report</button></div></section>
 <section className="card panel"><h2>Migration safety</h2><p className="muted">This step only validates structure and counts. It does not create customers, invoices, payments, inventory, loans, or accounting entries. Production import will require field-level mapping, duplicate checks, date validation, opening-balance reconciliation, and an explicit confirmation step.</p></section></>}
 </>;
}
