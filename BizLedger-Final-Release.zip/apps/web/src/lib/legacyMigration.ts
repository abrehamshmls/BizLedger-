export type LegacyBackup = {
  config?: Record<string, any>;
  data?: Record<string, any>;
};

export type MigrationCheck = {
  key: string;
  label: string;
  count: number;
  destination: string;
  status: 'ready' | 'review' | 'empty';
  note: string;
};

const dataArrays: Array<[string,string,string]> = [
  ['cashbook','Cashbook','payments / financial transactions'],
  ['purchases','Purchases','purchases + purchase_lines'],
  ['production','Production','production_batches + production_lines'],
  ['sales','Sales','sales + sale_lines'],
  ['expenses','Expenses','expenses'],
  ['inventory','Inventory','inventory_movements'],
  ['loans','Loans','loans'],
  ['loanpay','Loan repayments','loan_payments'],
  ['wht','Withholding received','withholding_received'],
  ['whc','Withholding collected','withholding_collected'],
  ['txpay','Payments','payments'],
  ['whremit','Withholding remittances','withholding_remittances'],
];

const configArrays: Array<[string,string,string]> = [
  ['contacts','Contacts','contacts'],
  ['products','Products','products'],
];

function arr(value: unknown): any[] { return Array.isArray(value) ? value : []; }

export function parseLegacyBackup(text: string): LegacyBackup {
  const parsed = JSON.parse(text) as LegacyBackup;
  if (!parsed || typeof parsed !== 'object') throw new Error('The file is not a JSON object.');
  if (parsed.config !== undefined && (!parsed.config || typeof parsed.config !== 'object')) throw new Error('config must be an object.');
  if (parsed.data !== undefined && (!parsed.data || typeof parsed.data !== 'object')) throw new Error('data must be an object.');
  return parsed;
}

export function validateLegacyBackup(backup: LegacyBackup): MigrationCheck[] {
  const data = backup.data ?? {};
  const config = backup.config ?? {};
  const checks = [
    ...configArrays.map(([key,label,destination]) => {
      const value = arr(config[key]);
      return {key,label,count:value.length,destination,status:(value.length?'ready':'empty') as MigrationCheck['status'],note:value.length?'Records detected in CFG configuration.':'No records detected.'};
    }),
    ...dataArrays.map(([key,label,destination]) => {
      const value = arr(data[key]);
      return {key,label,count:value.length,destination,status:(value.length?'ready':'empty') as MigrationCheck['status'],note:value.length?'Records detected; field-level validation remains required.':'No records detected.'};
    }),
  ];
  if (arr(data.debtors).length || arr(data.creditors).length) {
    checks.push({key:'balances',label:'Legacy debtor/creditor snapshots',count:arr(data.debtors).length+arr(data.creditors).length,destination:'derived receivables / payables',status:'review',note:'Snapshots are retained for reconciliation only; they are not imported as duplicate ledgers.'});
  }
  return checks;
}

export function migrationWarnings(backup: LegacyBackup): string[] {
  const warnings:string[]=[];
  const config=backup.config ?? {};
  const data=backup.data ?? {};
  if(!backup.data) warnings.push('The backup has no data section. Nothing can be migrated yet.');
  if(!backup.config) warnings.push('The backup has no config section. Contacts, products and business settings cannot be migrated.');
  if(arr(data.debtors).length||arr(data.creditors).length) warnings.push('Legacy debtor/creditor snapshots are reconciliation references only; balances will be derived from posted documents and payments.');
  if(arr(data.cashbook).length) warnings.push('Cashbook entries require reconciliation before conversion to payments or financial transactions.');
  if(arr(data.txpay).length) warnings.push('Legacy payment rows must be matched to their source documents before posting into the new payment ledger.');
  if(arr(data.inventory).length) warnings.push('Inventory requires quantity/cost reconciliation before opening or movement records are posted.');
  if(arr(data.loanpay).length) warnings.push('Loan repayments must be matched to their legacy loan IDs before posting.');
  if(typeof config.calendar==='string') warnings.push(`Legacy calendar preference detected: ${config.calendar}. Canonical database dates remain Gregorian ISO dates.`);
  return warnings;
}

export function buildMigrationReport(backup: LegacyBackup) {
  return {
    generatedAt: new Date().toISOString(),
    checks: validateLegacyBackup(backup),
    warnings: migrationWarnings(backup),
    rules: {
      contacts: 'CFG.contacts -> contacts',
      products: 'CFG.products -> products',
      sales: 'DATA.sales -> sales + sale_lines',
      purchases: 'DATA.purchases -> purchases + purchase_lines',
      expenses: 'DATA.expenses -> expenses',
      cashbook: 'DATA.cashbook -> payments and/or financial_transactions after validation',
      txpay: 'DATA.txpay -> payments after source-document matching',
      inventory: 'DATA.inventory -> inventory_movements after validation',
      production: 'DATA.production -> production_batches + production_lines',
      loans: 'DATA.loans -> loans; DATA.loanpay -> loan_payments',
      withholding: 'DATA.wht / DATA.whc / DATA.whremit -> withholding tables',
      balances: 'Legacy debtor/creditor arrays are retained for reconciliation only; balances are derived from documents/payments',
    },
  };
}

export function migrationPayload(backup: LegacyBackup) {
  const config=backup.config ?? {};
  const data=backup.data ?? {};
  const modules: Record<string, any[]> = {};
  for (const [key] of configArrays) modules[key]=arr(config[key]);
  for (const [key] of dataArrays) modules[key]=arr(data[key]);
  modules.debtors=arr(data.debtors);
  modules.creditors=arr(data.creditors);
  return {config, modules};
}

export function rowIssues(module:string,row:any): string[] {
  const issues:string[]=[];
  const required=(key:string,label:string)=>{if(row?.[key]===undefined||row?.[key]===null||String(row[key]).trim()==='')issues.push(`${label} is missing`)};
  if(['sales','purchases'].includes(module)){required('dateISO','dateISO'); required(module==='sales'?'invoice':'voucher',module==='sales'?'invoice':'voucher'); required('productId','productId'); if(!(Number(row.qty)>0))issues.push('qty must be greater than zero'); if(Number(row.price)<0||Number.isNaN(Number(row.price)))issues.push('price is invalid');}
  if(module==='expenses'){required('dateISO','dateISO'); if(!(Number(row.amount)>0))issues.push('amount must be greater than zero');}
  if(module==='inventory'){required('dateISO','dateISO'); required('productId','productId'); if(!(Number(row.qty)>0))issues.push('qty must be greater than zero');}
  if(module==='loans'){required('dateISO','dateISO'); if(!(Number(row.amount)>0))issues.push('amount must be greater than zero');}
  if(module==='loanpay'){required('dateISO','dateISO'); if(Number(row.principal)<0||Number(row.interest)<0)issues.push('principal/interest cannot be negative');}
  if(module==='wht'||module==='whc'){required('dateISO','dateISO'); if(Number(row.withheld)<0)issues.push('withheld cannot be negative');}
  if(module==='whremit'){required('dateISO','dateISO'); if(!(Number(row.amount)>0))issues.push('amount must be greater than zero');}
  return issues;
}
