import { supabase } from './supabase';

export type AccountingSummary = {
  sales: number;
  receivables: number;
  payables: number;
  cash: number;
};

export async function loadAccountingSummary(organizationId: string): Promise<AccountingSummary> {
  const [sales, receivables, payables, cash] = await Promise.all([
    supabase
      .from('sales')
      .select('total_amount, withholding_amount')
      .eq('organization_id', organizationId)
      .in('status', ['POSTED', 'PARTIALLY_PAID', 'PAID']),
    supabase.from('v_customer_balances').select('balance').eq('organization_id', organizationId),
    supabase.from('v_supplier_balances').select('balance').eq('organization_id', organizationId),
    supabase.from('v_cash_balances').select('balance').eq('organization_id', organizationId),
  ]);

  const error = sales.error || receivables.error || payables.error || cash.error;
  if (error) throw error;

  return {
    sales: (sales.data ?? []).reduce((sum, row) => sum + Number(row.total_amount ?? 0), 0),
    receivables: (receivables.data ?? []).reduce((sum, row) => sum + Number(row.balance ?? 0), 0),
    payables: (payables.data ?? []).reduce((sum, row) => sum + Number(row.balance ?? 0), 0),
    cash: (cash.data ?? []).reduce((sum, row) => sum + Number(row.balance ?? 0), 0),
  };
}
