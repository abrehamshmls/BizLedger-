import { supabase } from './supabase';

export type InventorySummary = {
  product_count: number;
  total_quantity: number;
  total_value: number;
};

export async function loadInventorySummary(organizationId: string) {
  const { data, error } = await supabase.rpc('inventory_dashboard', { p_org: organizationId });
  if (error) throw error;
  return ((data?.[0] ?? { product_count: 0, total_quantity: 0, total_value: 0 }) as InventorySummary);
}
