import type { LegacyBackup } from './legacyMigration';

export type DryRunRow = {
  module:string; rowNumber:number; key:string; date:string|null; amount:number; quantity:number; status:'READY'|'REVIEW'|'ERROR'; issues:string[]; contactHint:string; productHint:string;
};

const arr=(v:unknown)=>Array.isArray(v)?v:[];
const s=(v:any)=>v===undefined||v===null?'':String(v).trim();
const num=(v:any)=>Number(v);
function dateOf(r:any){
  const x=s(r?.dateISO||r?.date||r?.paymentDate||r?.receiptDate||r?.collectionDate||r?.remitDate);
  return /^\d{4}-\d{2}-\d{2}$/.test(x)?x:null;
}
function amountOf(r:any){
  for(const k of ['amount','total','totalAmount','owed','paid','received','cashin','cashout','principal','interest','withheld','net']) { const n=num(r?.[k]); if(Number.isFinite(n)&&n!==0)return Math.abs(n); }
  return 0;
}
export function buildFinancialDryRun(backup:LegacyBackup){
 const data=backup.data||{}; const out:DryRunRow[]=[];
 const modules=['sales','purchases','expenses','txpay','cashbook','inventory','production','loans','loanpay','wht','whc','whremit'];
 for(const module of modules){
  arr(data[module]).forEach((r:any,i)=>{
   const issues:string[]=[]; const d=dateOf(r); if(!d)issues.push('A canonical ISO date could not be determined.');
   const amount=amountOf(r); const quantity=Number(r?.qty||r?.quantity||r?.amountQty||0)||0;
   if(['sales','purchases'].includes(module)){if(!(quantity>0))issues.push('Quantity is missing or not positive.');if(!(num(r?.price)>=0))issues.push('Unit price is missing or invalid.');}
   if(['expenses','txpay','cashbook','whremit'].includes(module)&&!(amount>0))issues.push('Positive amount is required.');
   if(module==='loanpay' && !(num(r?.principal)>=0&&num(r?.interest)>=0&&num(r?.principal)+num(r?.interest)>0))issues.push('Principal + interest must be positive.');
   const key=s(r?.invoice||r?.voucher||r?.reference||r?.ref||`${module}-${i+1}`);
   out.push({module,rowNumber:i+1,key,date:d,amount,quantity,status:issues.length?'ERROR':'READY',issues,contactHint:s(r?.buyer||r?.supplier||r?.customer||r?.agent||r?.contactName||r?.name),productHint:s(r?.product||r?.productName)});
  });
 }
 return out;
}
export function dryRunSummary(rows:DryRunRow[]){
 const byModule:Record<string,{rows:number;amount:number;errors:number;ready:number}>={};
 for(const r of rows){const x=byModule[r.module]??={rows:0,amount:0,errors:0,ready:0};x.rows++;x.amount+=r.amount;if(r.status==='ERROR')x.errors++;else x.ready++;}
 return {rows:rows.length,errors:rows.filter(r=>r.status==='ERROR').length,ready:rows.filter(r=>r.status==='READY').length,byModule};
}
