const REF = Date.UTC(2024, 8, 11); // 1 Meskerem 2017 EC
const MONTHS = ['Meskerem','Tikimt','Hidar','Tahsas','Tir','Yekatit','Megabit','Miazia','Ginbot','Sene','Hamle','Nehase','Pagume'];

function isLeap(y:number){ return ((y % 4) + 4) % 4 === 3; }
function yearLength(y:number){ return isLeap(y) ? 366 : 365; }

export function gregorianToEthiopian(y:number,m:number,d:number){
  let days = Math.round((Date.UTC(y,m-1,d)-REF)/86400000);
  let year = 2017;
  if(days >= 0){ while(days >= yearLength(year)){ days -= yearLength(year); year++; } }
  else { while(days < 0){ year--; days += yearLength(year); } }
  const month = Math.floor(days/30)+1;
  return {year, month, day:days-(month-1)*30+1};
}

export function isoToEthiopian(iso:string){
  if(!iso) return null;
  const [y,m,d] = iso.split('-').map(Number);
  if(!y || !m || !d) return null;
  return gregorianToEthiopian(y,m,d);
}

export function formatEthiopian(iso:string){
  const e=isoToEthiopian(iso); if(!e) return '';
  return `${e.day} ${MONTHS[e.month-1]} ${e.year} EC`;
}

export const ethiopianMonthName=(month:number)=>MONTHS[month-1] ?? '';
