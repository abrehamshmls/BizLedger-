import { useEffect, useState } from 'react';
import { supabase } from './lib/supabase';

type Membership={organization_id:string};
type Check={check_code:string;severity:string;issue_count:number;details:any};

export function AccountingWorkflow({membership}:{membership:Membership}){
  const [checks,setChecks]=useState<Check[]>([]); const [error,setError]=useState(''); const [loading,setLoading]=useState(false);
  async function load(){setLoading(true);setError('');const{data,error}=await supabase.rpc('accounting_workflow_diagnostics',{p_org:membership.organization_id});if(error)setError(error.message);else setChecks((data||[]) as Check[]);setLoading(false)}
  useEffect(()=>{load()},[membership.organization_id]);
  const errors=checks.filter(c=>c.severity==='ERROR'&&Number(c.issue_count)>0).length;
  return <><div className="page-heading"><div><h1>Accounting workflow</h1><p className="muted">Read-only checks for posting, journals and inventory integrity.</p></div><button onClick={load} disabled={loading}>{loading?'Checking…':'Run checks'}</button></div>{error&&<div className="error">{error}</div>}<div className="cards three"><div className="metric"><span>Checks with errors</span><strong>{errors}</strong><small>{errors?'Review before production use':'No detected error checks'}</small></div><div className="metric"><span>Total checks</span><strong>{checks.length}</strong><small>Database diagnostics</small></div><div className="metric"><span>Organization</span><strong>Active</strong><small>Tenant-scoped</small></div></div><div className="card table-wrap"><table><thead><tr><th>Check</th><th>Severity</th><th>Issues</th><th>Details</th></tr></thead><tbody>{checks.map(c=><tr key={c.check_code}><td>{c.check_code.replaceAll('_',' ')}</td><td><span className={c.severity==='ERROR'?'status danger':'status'}>{c.severity}</span></td><td>{Number(c.issue_count)}</td><td>{Number(c.issue_count)?JSON.stringify(c.details):'OK'}</td></tr>)}</tbody></table>{!checks.length&&!loading&&<div className="empty">No diagnostic results.</div>}</div><section className="card panel"><h2>What this page does</h2><p className="muted">These checks inspect the current organization only. They never automatically change invoices, payments, inventory or journals.</p></section></>;
}
