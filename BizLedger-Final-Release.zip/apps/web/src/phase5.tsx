import React,{useEffect,useMemo,useState} from 'react';
import {supabase} from './lib/supabase';
import {toast} from './phase3';

const money=(n:number)=>`ETB ${Number(n||0).toLocaleString('en-ET',{minimumFractionDigits:2,maximumFractionDigits:2})}`;
const fmtDate=(v:string|null)=>v?new Date(v).toLocaleDateString('en-GB'):'—';

function PageTitle({title,subtitle}:{title:string;subtitle?:string}){return <div className="page-heading"><div><h1>{title}</h1>{subtitle&&<p className="muted">{subtitle}</p>}</div></div>}
function Status({value}:{value:string}){return <span className={`status ${value.toLowerCase()}`}>{value.replaceAll('_',' ')}</span>}

type Plan={id:string;code:string;name:string;description:string;monthly_price:number;yearly_price:number;max_members:number;max_products:number;max_monthly_invoices:number;features:Record<string,boolean>};
type Sub={organization_id:string;subscription_id:string;plan_code:string;plan_name:string;description:string;monthly_price:number;yearly_price:number;max_members:number;max_products:number;max_monthly_invoices:number;features:Record<string,boolean>;status:string;trial_ends_at:string|null;current_period_start:string|null;current_period_end:string|null;cancel_at_period_end:boolean};

export function Billing({organizationId}:{organizationId:string}){
 const [plans,setPlans]=useState<Plan[]>([]); const [sub,setSub]=useState<Sub|null>(null); const [commercial,setCommercial]=useState<any>(null); const [members,setMembers]=useState(0); const [products,setProducts]=useState(0); const [invoices,setInvoices]=useState(0); const [loading,setLoading]=useState(true); const [error,setError]=useState(''); const [busy,setBusy]=useState('');
 async function load(){
  setLoading(true);setError('');
  const org=organizationId; if(!org){setLoading(false);return;}
  await supabase.rpc('ensure_free_subscription',{p_org:org});
  const [p,s,mc,pc,sc,cs]=await Promise.all([
   supabase.from('subscription_plans').select('*').eq('active',true).order('monthly_price'),
   supabase.from('v_current_subscription').select('*').eq('organization_id',org).single(),
   supabase.from('organization_members').select('id',{count:'exact',head:true}).eq('organization_id',org).eq('status','ACTIVE'),
   supabase.from('products').select('id',{count:'exact',head:true}).eq('organization_id',org).eq('active',true),
   supabase.from('sales').select('id',{count:'exact',head:true}).eq('organization_id',org).gte('sale_date',new Date(new Date().getFullYear(),new Date().getMonth(),1).toISOString().slice(0,10)).lte('sale_date',new Date().toISOString().slice(0,10)).neq('status','VOIDED'),
   supabase.rpc('get_commercial_status',{p_org:org})
  ]);
  const firstError=[p.error,s.error,mc.error,pc.error,sc.error,cs.error].find(Boolean); if(firstError){setError((firstError as any).message);setLoading(false);return;}
  setPlans((p.data||[]) as Plan[]);setSub((s.data||null) as Sub|null);setMembers(mc.count||0);setProducts(pc.count||0);setInvoices(sc.count||0);setCommercial(cs.data||null);setLoading(false);
 }
 useEffect(()=>{load()},[organizationId]);
 const current=useMemo(()=>plans.find(p=>p.code===sub?.plan_code),[plans,sub]);
 async function requestUpgrade(plan:Plan){setBusy(plan.code);const {error}=await supabase.from('subscription_events').insert({organization_id:organizationId,subscription_id:sub?.subscription_id||null,event_type:'UPGRADE_REQUESTED',provider:null,payload:{requested_plan:plan.code}});setBusy('');if(error)setError(error.message);else toast(`Upgrade request recorded for ${plan.name}. Payment connection can be added next.`)}
 if(loading)return <div className="card panel">Loading subscription…</div>;
 return <><PageTitle title="Subscription" subtitle="Manage your BizLedger plan and monitor account limits."/>{error&&<div className="error">{error}</div>}
  {sub&&<section className="card panel subscription-current"><div><span className="eyebrow">Current plan</span><h2>{sub.plan_name}</h2><p className="muted">{sub.description}</p></div><div className="subscription-status"><Status value={sub.status}/>{sub.status==='TRIALING'&&<small>Trial ends {fmtDate(sub.trial_ends_at)}</small>}{sub.current_period_end&&<small>Period ends {fmtDate(sub.current_period_end)}</small>}</div></section>}
  <div className="cards three"><div className="metric"><span>Commercial status</span><strong>{commercial?.effective_active?'Active':'Restricted'}</strong><small>{commercial?.status||sub?.status||'—'}</small></div><div className="metric"><span>Team members</span><strong>{members} / {sub?.max_members??'—'}</strong><small>Active members</small></div><div className="metric"><span>Products</span><strong>{products.toLocaleString()} / {(sub?.max_products??0).toLocaleString()}</strong><small>Active products</small></div><div className="metric"><span>Invoices this month</span><strong>{invoices.toLocaleString()} / {(sub?.max_monthly_invoices??0).toLocaleString()}</strong><small>Non-voided sales</small></div></div>
  <div className="plan-grid">{plans.map(p=><article key={p.id} className={`card plan-card ${p.code===sub?.plan_code?'selected':''}`}><div className="plan-head"><div><span className="eyebrow">{p.code}</span><h2>{p.name}</h2></div>{p.code===sub?.plan_code&&<Status value="ACTIVE"/>}</div><p className="muted">{p.description}</p><div className="plan-price"><strong>{p.monthly_price===0?'Free':money(p.monthly_price)}</strong><span>{p.monthly_price===0?'':' / month'}</span></div><ul className="clean plan-features"><li>{p.max_members} team member{p.max_members===1?'':'s'}</li><li>{p.max_products.toLocaleString()} active products</li><li>{p.max_monthly_invoices.toLocaleString()} invoices/month</li>{Object.entries(p.features).filter(([,v])=>v).slice(0,6).map(([k])=><li key={k}>{k.replaceAll('_',' ')}</li>)}</ul>{p.code!==sub?.plan_code&&<button disabled={!!busy} onClick={()=>requestUpgrade(p)}>{busy===p.code?'Recording request…':(current&&p.monthly_price>current.monthly_price?'Request upgrade':'Request plan change')}</button>}</article>)}</div>
  <section className="card panel"><h2>Billing integration</h2><p className="muted">BizLedger currently stores subscription state and upgrade requests without charging a card or mobile-money account. The payment-provider adapter will verify callbacks/webhooks before changing subscription status.</p><div className="notice">Before launch, replace the starter plan prices with your final commercial pricing and connect a supported payment provider.</div></section>
 </>;
}
