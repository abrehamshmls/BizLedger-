import { useMemo, useState } from 'react';
import { supabase } from './lib/supabase';
import { toast } from './phase3';
import { buildMigrationReport, migrationPayload, parseLegacyBackup, rowIssues, type LegacyBackup, validateLegacyBackup, migrationWarnings } from './lib/legacyMigration';
import type { Membership } from './types';

function PageTitle({title,subtitle}:{title:string;subtitle?:string}){return <div className="page-heading"><div><h1>{title}</h1>{subtitle&&<p className="muted">{subtitle}</p>}</div></div>}

async function sha256(text:string){const bytes=new TextEncoder().encode(text);const hash=await crypto.subtle.digest('SHA-256',bytes);return Array.from(new Uint8Array(hash)).map(b=>b.toString(16).padStart(2,'0')).join('');}

export function MigrationCenter({membership}:{membership:Membership}){
 const [backup,setBackup]=useState<LegacyBackup|null>(null); const [fileName,setFileName]=useState(''); const [rawText,setRawText]=useState('');
 const [error,setError]=useState(''); const [busy,setBusy]=useState(false); const [batchId,setBatchId]=useState<string|null>(null); const [staged,setStaged]=useState(false); const [masterResult,setMasterResult]=useState<any>(null);
 const checks=useMemo(()=>backup?validateLegacyBackup(backup):[],[backup]);
 const warnings=useMemo(()=>backup?migrationWarnings(backup):[],[backup]);
 const report=useMemo(()=>backup?buildMigrationReport(backup):null,[backup]);
 const payload=useMemo(()=>backup?migrationPayload(backup):null,[backup]);
 const errors=useMemo(()=>{if(!payload)return 0;let n=0;for(const [module,rows] of Object.entries(payload.modules)) for(const row of rows)n+=rowIssues(module,row).length;return n},[payload]);
 const duplicateWarnings=useMemo(()=>{
   if(!payload)return [] as string[]; const out:string[]=[];
   for(const [module,field,label] of [['sales','invoice','invoice'],['purchases','voucher','voucher']] as const){const seen=new Map<string,number>();for(const row of payload.modules[module]||[]){const key=String(row?.[field]??'').trim().toLowerCase();if(!key)continue;seen.set(key,(seen.get(key)||0)+1)}for(const [key,count] of seen)if(count>1)out.push(`${label} "${key}" appears ${count} times in the legacy backup.`)}
   return out;
 },[payload]);
 async function load(file:File){setError('');setStaged(false);setBatchId(null);setMasterResult(null);try{const text=await file.text();const parsed=parseLegacyBackup(text);setRawText(text);setBackup(parsed);setFileName(file.name);toast('Legacy backup loaded and analyzed locally.')}catch(e){setBackup(null);setRawText('');setError(e instanceof Error?e.message:'Could not read backup.')}}
 async function stage(){if(!backup||!payload)return;setBusy(true);setError('');try{const hash=await sha256(rawText);const summary={checks,warnings,field_errors:errors,duplicate_warnings:duplicateWarnings};const created=await supabase.rpc('create_migration_batch',{p_org:membership.organization_id,p_source_name:fileName,p_source_sha256:hash,p_summary:summary,p_config:payload.config});if(created.error)throw created.error;const id=created.data as string;for(const [module,rows] of Object.entries(payload.modules)){if(!rows.length)continue;const chunk=rows.map((row:any,i:number)=>({batch_id:id,module,row_number:i+1,raw_data:row,status:rowIssues(module,row).length?'ERROR':'READY',issues:rowIssues(module,row)}));for(let i=0;i<chunk.length;i+=400){const {error}=await supabase.from('migration_rows').insert(chunk.slice(i,i+400));if(error)throw error;}}
 const invalid=errors>0||duplicateWarnings.length>0; if(!invalid){const {error}=await supabase.rpc('mark_migration_batch_validated',{p_batch:id});if(error)throw error;}setBatchId(id);setStaged(true);toast(invalid?'Migration batch staged for review.':'Migration batch staged and validated.');
 }catch(e){setError(e instanceof Error?e.message:'Could not stage migration batch.')}finally{setBusy(false)}}
 async function importMasterData(){if(!batchId)return; if(!confirm('Import legacy contacts and products into this organization? This is the first production import step.'))return; setBusy(true);setError('');try{const {data,error}=await supabase.rpc('import_migration_master_data',{p_batch:batchId,p_confirm:true});if(error)throw error;setMasterResult(data);toast('Legacy master data imported successfully.')}catch(e){setError(e instanceof Error?e.message:'Could not import master data.')}finally{setBusy(false)}}
 function download(){if(!report)return;const blob=new Blob([JSON.stringify(report,null,2)],{type:'application/json'});const url=URL.createObjectURL(blob);const a=document.createElement('a');a.href=url;a.download='bizledger-migration-report.json';a.click();URL.revokeObjectURL(url)}
 const total=checks.reduce((n,c)=>n+c.count,0);
 return <><PageTitle title="Migration Center" subtitle="Validate and stage a legacy BizLedger backup without posting anything into accounting."/>
 <section className="card panel"><h2>1. Select legacy backup</h2><p className="muted">Use the JSON backup exported by the original BizLedger app. The file is analyzed locally first. Staging creates an isolated migration batch; it does not create invoices, payments, inventory movements or journal entries.</p><input type="file" accept="application/json,.json" onChange={e=>{const f=e.target.files?.[0];if(f)load(f)}}/>{fileName&&<p className="small muted">Loaded: {fileName}</p>}{error&&<div className="error">{error}</div>}</section>
 {backup&&<>
 <div className="cards three"><div className="metric"><strong>{total.toLocaleString()}</strong><span>Legacy records</span></div><div className="metric"><strong>{checks.filter(c=>c.status==='ready').length}</strong><span>Populated modules</span></div><div className="metric"><strong>{errors}</strong><span>Field errors</span></div></div>
 <section className="card table-wrap"><table><thead><tr><th>Legacy section</th><th>Records</th><th>Destination</th><th>Status</th><th>Note</th></tr></thead><tbody>{checks.map(c=><tr key={c.key}><td>{c.label}</td><td>{c.count.toLocaleString()}</td><td>{c.destination}</td><td><span className={`status ${c.status}`}>{c.status}</span></td><td>{c.note}</td></tr>)}</tbody></table></section>
 <section className="card panel"><h2>2. Reconciliation warnings</h2>{warnings.length||duplicateWarnings.length?<ul>{[...warnings,...duplicateWarnings].map((w,i)=><li key={i}>{w}</li>)}</ul>:<p className="muted">No structural or duplicate warnings detected.</p>}<div className="actions"><button onClick={download}>Download validation report</button></div></section>
 <section className="card panel"><h2>3. Stage migration batch</h2><p className="muted">Rows are copied into isolated migration staging tables and marked READY or ERROR. A batch with errors or duplicate invoice/voucher numbers remains available for review and is not marked validated.</p>{batchId&&<div className="success">Batch staged: <code>{batchId}</code>{staged&&errors===0&&duplicateWarnings.length===0?' — validated and ready for the controlled import step.':' — review required before validation.'}</div>}<div className="actions"><button disabled={busy||!!batchId} onClick={stage}>{busy?'Staging…':batchId?'Batch staged':'Stage validated backup'}</button></div></section>
 <section className="card panel"><h2>4. Controlled master-data import</h2><p className="muted">After validation, BizLedger can import only Contacts and Products. Existing records are matched before new records are created. Financial documents and payments remain untouched.</p>{masterResult&&<div className="success">Imported master data: {masterResult.contacts||0} contacts and {masterResult.products||0} products. Created {masterResult.created||0}; matched {masterResult.matched||0}.</div>}<div className="actions"><button disabled={busy||!batchId||errors>0||duplicateWarnings.length>0||!staged||!!masterResult} onClick={importMasterData}>{busy?'Importing…':masterResult?'Master data imported':'Import contacts & products'}</button></div></section>
 <section className="card panel"><h2>Migration safety</h2><p className="muted">The staging layer is intentionally separate from the accounting tables. Master-data mappings are recorded before the next stage transforms sales, purchases, payments, inventory, loans and withholding. Financial records are not posted by this step.</p></section>
 </>}
 </>;
}
