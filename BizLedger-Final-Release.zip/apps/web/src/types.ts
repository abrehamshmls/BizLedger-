export type Organization = {
  id: string;
  name: string;
  legal_name: string | null;
  base_currency: string;
  country_code: string;
};

export type Membership = {
  id: string;
  organization_id: string;
  user_id: string;
  status: string;
  role_id: string | null;
  organizations: Organization;
  roles: { id: string; name: string } | null;
};
