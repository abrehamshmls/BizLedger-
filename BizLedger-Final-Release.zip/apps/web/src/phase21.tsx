import { useEffect, useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { supabase } from './lib/supabase';

export function LaunchReady({ organizationId }: { organizationId: string }) {
  const nav = useNavigate();
  const [dismissed, setDismissed] = useState(false);
  const [stats, setStats] = useState({ contacts: 0, products: 0, sales: 0, openingStock: 0 });
  const [subscription, setSubscription] = useState<any>(null);
  const [error, setError] = useState('');

  useEffect(() => {
    setDismissed(localStorage.getItem(`bizledger.launch.dismissed.${organizationId}`) === '1');
    (async () => {
      const [c, p, s, i, sub] = await Promise.all([
        supabase.from('contacts').select('id', { count: 'exact', head: true }).eq('organization_id', organizationId).eq('active', true),
        supabase.from('products').select('id', { count: 'exact', head: true }).eq('organization_id', organizationId).eq('active', true),
        supabase.from('sales').select('id', { count: 'exact', head: true }).eq('organization_id', organizationId).neq('status', 'VOIDED'),
        supabase.from('inventory_movements').select('id', { count: 'exact', head: true }).eq('organization_id', organizationId),
        supabase.rpc('subscription_snapshot', { p_org: organizationId })
      ]);
      const firstError = c.error || p.error || s.error || i.error || sub.error;
      if (firstError) setError(firstError.message);
      setStats({ contacts: c.count || 0, products: p.count || 0, sales: s.count || 0, openingStock: i.count || 0 });
      setSubscription(sub.data || null);
    })();
  }, [organizationId]);

  if (dismissed) return null;
  const steps = [
    { label: 'Add at least one customer or supplier', done: stats.contacts > 0, path: '/contacts' },
    { label: 'Add your products/services', done: stats.products > 0, path: '/products' },
    { label: 'Enter opening stock if you carry inventory', done: stats.openingStock > 0 || stats.products === 0, path: '/inventory' },
    { label: 'Record your first sale', done: stats.sales > 0, path: '/sales' }
  ];
  const completed = steps.filter(s => s.done).length;
  return <section className="card panel launch-panel">
    <div className="page-heading"><div><h2>Get BizLedger ready</h2><p className="muted">A short first-run checklist for your business.</p></div><span className="badge">{completed}/{steps.length}</span></div>
    {subscription && !subscription.effective_active && <div className="error">Your subscription is not active. Open Subscription to restore access.</div>}
    {error && <div className="error">Could not load onboarding status: {error}</div>}
    <div className="launch-steps">{steps.map(s => <button key={s.label} className={`launch-step ${s.done ? 'done' : ''}`} onClick={() => !s.done && nav(s.path)}><span>{s.done ? '✓' : '○'}</span><span>{s.label}</span></button>)}</div>
    <div className="launch-actions"><button className="secondary" onClick={() => nav('/settings')}>Business settings</button><button className="secondary" onClick={() => nav('/billing')}>Subscription</button><button className="link-button" onClick={() => { localStorage.setItem(`bizledger.launch.dismissed.${organizationId}`, '1'); setDismissed(true); }}>Dismiss</button></div>
  </section>;
}
