import { useState } from 'react';
import { supabase } from './lib/supabase';
import type { Membership } from './types';

function PageTitle({title,subtitle}:{title:string;subtitle?:string}){return <div className="page-heading"><div><h1>{title}</h1>{subtitle&&<p className="muted">{subtitle}</p>}</div></div>}
function Metric({label,value,hint}:{label:string;value:string;hint:string}){return <div className="metric"><span>{label}</span><strong>{value}</strong><small>{hint}</small></div>}

export function Reliability({membership}:{membership:Membership}){
 const [result,setResult]=useState<any>(null); const [error,setError]=useState(''); const [busy,setBusy]=useState(false);
 async function run(){setBusy(true);setError('');try{const {data,error}=await supabase.rpc('get_reliability_report',{p_org:membership.organization_id});if(error)throw error;setResult(data);}catch(e){setError(e instanceof Error?e.message:'Reliability check failed.')}finally{setBusy(false)}}
 return <><PageTitle title="Reliability & recovery" subtitle="Read-only visibility into idempotent financial operations and application errors."/>
 <section className="card panel"><h2>Run reliability checks</h2><p className="muted">BizLedger records idempotency keys for critical financial operations so retries do not intentionally create a second transaction. Application errors can also be reported without exposing sensitive payloads in the browser.</p><button disabled={busy} onClick={run}>{busy?'Checking…':'Run reliability checks'}</button>{error&&<div className="error">{error}</div>}</section>
 {result&&<><div className="cards five"><Metric label="Status" value={result.ready?'READY':'REVIEW'} hint={result.stale_operations+' stale operations'}/><Metric label="Errors" value={String(result.recent_errors_24h)} hint="Application errors, last 24h"/><Metric label="Operations" value={String(result.idempotent_operations)} hint="Idempotency records"/><Metric label="Completed" value={String(result.completed_operations)} hint="With result IDs"/><Metric label="Incomplete" value={String(result.incomplete_operations)} hint="Usually active/review"/></div><section className="card panel"><h2>Recovery behavior</h2><ul className="clean"><li>Critical retries can reuse the same operation key.</li><li>Completed operations return their original result identifier.</li><li>Stale incomplete operations are surfaced for investigation.</li><li>Error reporting is append-only and tenant-scoped.</li><li>Accounting data is not automatically repaired by diagnostics.</li></ul></section></>}
 </>;
}
