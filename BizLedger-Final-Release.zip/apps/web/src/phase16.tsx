import { useState } from 'react';
import { supabase } from './lib/supabase';
import type { Membership } from './types';

function PageTitle({title,subtitle}:{title:string;subtitle?:string}){return <div className="page-heading"><div><h1>{title}</h1>{subtitle&&<p className="muted">{subtitle}</p>}</div></div>}
function Check({row}:{row:any}){return <div className="card panel"><div className="page-heading"><div><h2>{row.label}</h2><p className="muted">{row.detail}</p></div><strong>{row.ok?'✓ PASS':'! REVIEW'}</strong></div><small>Findings: {Number(row.count||0).toLocaleString()}</small></div>}
export function Integrity({membership}:{membership:Membership}){
 const [result,setResult]=useState<any>(null); const [error,setError]=useState(''); const [busy,setBusy]=useState(false);
 async function run(){setBusy(true);setError('');try{const {data,error}=await supabase.rpc('get_operational_integrity_report',{p_org:membership.organization_id});if(error)throw error;setResult(data);}catch(e){setError(e instanceof Error?e.message:'Integrity check failed.')}finally{setBusy(false)}}
 return <><PageTitle title="Operational integrity" subtitle="Read-only production checks for accounting, inventory, tenant isolation and cutover state."/>
 <section className="card panel"><h2>Run diagnostics</h2><p className="muted">These checks do not create, modify, or delete business records. They identify conditions that should be investigated before a production release or accounting handover.</p><button disabled={busy} onClick={run}>{busy?'Checking…':'Run integrity checks'}</button>{error&&<div className="error">{error}</div>}</section>
 {result&&<><div className="cards three"><div className="metric"><span>Status</span><strong>{result.ready?'READY':'REVIEW'}</strong><small>{result.failed_checks} failed of {result.total_checks} checks</small></div><div className="metric"><span>Cutover</span><strong>{result.cutover_locked?'LOCKED':'OPEN'}</strong><small>Current migration state</small></div><div className="metric"><span>Generated</span><strong>{new Date(result.generated_at).toLocaleString()}</strong><small>Diagnostic timestamp</small></div></div><div className="two-col">{(result.checks||[]).map((r:any)=><Check key={r.code} row={r}/>)}</div></>}
 </>;
}
