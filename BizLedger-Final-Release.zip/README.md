# BizLedger — Production Candidate

Commercial SaaS business-management and accounting application for Ethiopian SMEs.

## Stack

- React + TypeScript
- Supabase Auth + PostgreSQL
- PostgreSQL Row Level Security for tenant isolation
- Vercel-compatible frontend deployment

## Core capabilities

Sales, purchases, expenses, payments, inventory, weighted-average costing, production, loans, withholding, financial reports, team management, audit logs, subscriptions, Ethiopian/Gregorian dates, and controlled migration from the legacy BizLedger JSON backup.

## Database

Apply all files under `supabase/migrations/` in filename order with the Supabase CLI or SQL editor.

Do not put production secrets in the repository.

## Web application

```text
apps/web
```

Copy `.env.example` to the deployment environment and provide the Supabase project URL and anonymous key.

## Release status

This is a **production candidate**. The codebase has been consolidated through Phase 24, but a live Supabase project and dependency installation were not available in the build environment. Complete the checks in `docs/FINAL-RELEASE.md` before customer launch.
