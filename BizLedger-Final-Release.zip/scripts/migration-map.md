# Legacy → BizLedger migration map

| Legacy source | New destination |
|---|---|
| `CFG.contacts` | `contacts` |
| `CFG.products` | `products` |
| `DATA.sales` | `sales` + `sale_lines` |
| `DATA.purchases` | `purchases` + `purchase_lines` |
| `DATA.expenses` | `expenses` |
| `DATA.cashbook` | `payments` and/or `financial_transactions` after validation |
| `DATA.inventory` | `inventory_movements` after validation |
| `DATA.production` | `production_batches` + `production_lines` |
| `DATA.loans` | `loans` |
| `DATA.loanpay` | `loan_payments` |
| `DATA.wht` | `withholding_received` |
| `DATA.whc` | `withholding_collected` |
| withholding remittance data | `withholding_remittances` |
| legacy debtor/creditor arrays | **do not migrate as duplicate tables**; derive balances from documents/payments |
| `CFG.roles` | `roles` + `role_permissions` |
| `CFG.settings` | `organization_settings` |

Exact field-level transformations must be implemented after the legacy parser is written and tested against real exported data.
