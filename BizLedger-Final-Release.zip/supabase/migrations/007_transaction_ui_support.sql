-- BizLedger Phase 2C: transaction UI support
-- Keep source documents as drafts until explicitly posted. UI writes are tenant-scoped by RLS.
create index if not exists idx_contacts_org_name on public.contacts(organization_id,name);
create index if not exists idx_products_org_name on public.products(organization_id,name);
create index if not exists idx_sales_org_date on public.sales(organization_id,sale_date desc);
create index if not exists idx_purchases_org_date on public.purchases(organization_id,purchase_date desc);
create index if not exists idx_expenses_org_date on public.expenses(organization_id,expense_date desc);
create index if not exists idx_inventory_org_date on public.inventory_movements(organization_id,movement_date desc);
create index if not exists idx_payments_org_date on public.payments(organization_id,payment_date desc);

-- Resolve organization automatically for the authenticated member. This avoids trusting a
-- browser-provided organization id for payment recording while preserving the existing RPC API.
create or replace function public.record_payment_for_source(
  p_source_type text,
  p_source_id uuid,
  p_direction public.payment_direction,
  p_date date,
  p_account_id uuid,
  p_contact_id uuid,
  p_amount numeric,
  p_reference text default null,
  p_notes text default null
)
returns uuid
language plpgsql security definer set search_path=public
as $$
declare
  v_org uuid;
begin
  if p_source_type='SALE' then select organization_id into v_org from public.sales where id=p_source_id;
  elsif p_source_type='PURCHASE' then select organization_id into v_org from public.purchases where id=p_source_id;
  else raise exception 'Unsupported payment source'; end if;
  if v_org is null then raise exception 'Source document not found'; end if;
  return public.record_payment(v_org,p_direction,p_date,p_account_id,p_contact_id,p_source_type,p_source_id,p_amount,p_reference,p_notes);
end;
$$;

grant execute on function public.record_payment_for_source(text,uuid,public.payment_direction,date,uuid,uuid,numeric,text,text) to authenticated;
