-- BizLedger Phase 20: commercial production enforcement
-- Provider-neutral subscription enforcement at the database boundary.

create or replace function public.subscription_snapshot(p_org uuid)
returns jsonb
language plpgsql
security definer
set search_path=public
as $$
declare
  v jsonb;
begin
  if not public.is_org_member(p_org) then raise exception 'Not authorized'; end if;

  -- Organizations created before the subscription foundation get Free automatically.
  insert into public.organization_subscriptions(organization_id,plan_id,status,trial_ends_at,current_period_start,current_period_end)
  select p_org,p.id,'TRIALING',now()+interval '14 days',now(),now()+interval '14 days'
  from public.subscription_plans p
  where p.code='FREE' and p.active=true
    and not exists(select 1 from public.organization_subscriptions s where s.organization_id=p_org)
  on conflict (organization_id) do nothing;

  select jsonb_build_object(
    'organization_id',os.organization_id,
    'subscription_id',os.id,
    'plan_code',sp.code,
    'plan_name',sp.name,
    'status',case
      when os.status='TRIALING' and os.trial_ends_at is not null and os.trial_ends_at < now()
        then case when sp.code='FREE' then 'ACTIVE' else 'EXPIRED' end
      else os.status::text
    end,
    'effective_active',case
      when os.status in ('ACTIVE','TRIALING') and (os.status='ACTIVE' or os.trial_ends_at is null or os.trial_ends_at >= now()) then true
      when os.status='TRIALING' and sp.code='FREE' then true
      else false
    end,
    'max_members',sp.max_members,
    'max_products',sp.max_products,
    'max_monthly_invoices',sp.max_monthly_invoices,
    'features',sp.features,
    'trial_ends_at',os.trial_ends_at,
    'current_period_end',os.current_period_end,
    'cancel_at_period_end',os.cancel_at_period_end
  ) into v
  from public.organization_subscriptions os
  join public.subscription_plans sp on sp.id=os.plan_id
  where os.organization_id=p_org;

  return coalesce(v,'{}'::jsonb);
end;
$$;

create or replace function public.subscription_allows(p_org uuid, p_feature text)
returns boolean
language plpgsql
security definer
set search_path=public
as $$
declare
  v jsonb;
begin
  v:=public.subscription_snapshot(p_org);
  if coalesce((v->>'effective_active')::boolean,false)=false then return false; end if;
  return coalesce((v->'features'->>p_feature)::boolean,false);
end;
$$;

create or replace function public.assert_subscription_feature(p_org uuid, p_feature text)
returns void
language plpgsql
security definer
set search_path=public
as $$
begin
  if not public.subscription_allows(p_org,p_feature) then
    raise exception 'Your current BizLedger plan does not include the % feature. Open Subscription to change plans.', p_feature
      using errcode='P0001';
  end if;
end;
$$;

create or replace function public.assert_subscription_capacity(p_org uuid, p_resource text)
returns void
language plpgsql
security definer
set search_path=public
as $$
declare
  v jsonb;
  v_count bigint;
  v_limit integer;
begin
  v:=public.subscription_snapshot(p_org);
  if not coalesce((v->>'effective_active')::boolean,false) then
    raise exception 'Your BizLedger subscription is not active. Open Subscription to renew or change plans.';
  end if;

  if p_resource='members' then
    v_limit:=coalesce((v->>'max_members')::integer,0);
    select count(*) into v_count from public.organization_members where organization_id=p_org and status='ACTIVE';
  elsif p_resource='products' then
    v_limit:=coalesce((v->>'max_products')::integer,0);
    select count(*) into v_count from public.products where organization_id=p_org and active=true;
  elsif p_resource='monthly_invoices' then
    v_limit:=coalesce((v->>'max_monthly_invoices')::integer,0);
    select count(*) into v_count from public.sales where organization_id=p_org
      and sale_date >= date_trunc('month',current_date)::date
      and sale_date < (date_trunc('month',current_date)+interval '1 month')::date
      and status <> 'VOIDED';
  else
    raise exception 'Unknown subscription resource: %',p_resource;
  end if;

  if v_count >= v_limit then
    raise exception 'The % limit for your current BizLedger plan has been reached (% of %). Open Subscription to change plans.', p_resource,v_count,v_limit;
  end if;
end;
$$;

-- Keep the public subscription view aligned with effective commercial status.
drop view if exists public.v_current_subscription;
create view public.v_current_subscription as
select os.organization_id, os.id subscription_id, sp.code plan_code, sp.name plan_name,
       sp.description, sp.monthly_price, sp.yearly_price, sp.max_members, sp.max_products,
       sp.max_monthly_invoices, sp.features,
       case
         when os.status='TRIALING' and os.trial_ends_at is not null and os.trial_ends_at < now()
           then case when sp.code='FREE' then 'ACTIVE' else 'EXPIRED' end
         else os.status::text
       end as status,
       os.trial_ends_at, os.current_period_start, os.current_period_end, os.cancel_at_period_end
from public.organization_subscriptions os
join public.subscription_plans sp on sp.id=os.plan_id;

-- Capacity checks.
create or replace function public.trg_subscription_member_limit()
returns trigger language plpgsql security definer set search_path=public as $$
begin
  if new.status='ACTIVE' and (tg_op='INSERT' or old.status<>'ACTIVE') then
    perform public.assert_subscription_capacity(new.organization_id,'members');
  end if;
  return new;
end; $$;

drop trigger if exists trg_subscription_member_limit on public.organization_members;
create trigger trg_subscription_member_limit before insert or update of status on public.organization_members
for each row execute function public.trg_subscription_member_limit();

create or replace function public.trg_subscription_product_limit()
returns trigger language plpgsql security definer set search_path=public as $$
begin
  if new.active=true and (tg_op='INSERT' or old.active=false) then
    perform public.assert_subscription_capacity(new.organization_id,'products');
  end if;
  return new;
end; $$;

drop trigger if exists trg_subscription_product_limit on public.products;
create trigger trg_subscription_product_limit before insert or update of active on public.products
for each row execute function public.trg_subscription_product_limit();

create or replace function public.trg_subscription_invoice_limit()
returns trigger language plpgsql security definer set search_path=public as $$
begin
  if new.status<>'VOIDED' and (tg_op='INSERT' or old.status='VOIDED') then
    perform public.assert_subscription_capacity(new.organization_id,'monthly_invoices');
  end if;
  return new;
end; $$;

drop trigger if exists trg_subscription_invoice_limit on public.sales;
create trigger trg_subscription_invoice_limit before insert or update of status on public.sales
for each row execute function public.trg_subscription_invoice_limit();

-- Feature gates for premium operational modules.
create or replace function public.trg_subscription_production_feature()
returns trigger language plpgsql security definer set search_path=public as $$
begin perform public.assert_subscription_feature(new.organization_id,'production'); return new; end; $$;
drop trigger if exists trg_subscription_production_feature on public.production_batches;
create trigger trg_subscription_production_feature before insert or update on public.production_batches
for each row execute function public.trg_subscription_production_feature();

create or replace function public.trg_subscription_loan_feature()
returns trigger language plpgsql security definer set search_path=public as $$
begin perform public.assert_subscription_feature(new.organization_id,'loans'); return new; end; $$;
drop trigger if exists trg_subscription_loan_feature on public.loans;
create trigger trg_subscription_loan_feature before insert or update on public.loans
for each row execute function public.trg_subscription_loan_feature();

create or replace function public.trg_subscription_loan_payment_feature()
returns trigger language plpgsql security definer set search_path=public as $$
declare v_org uuid; begin select organization_id into v_org from public.loans where id=new.loan_id; perform public.assert_subscription_feature(coalesce(v_org,new.organization_id),'loans'); return new; end; $$;
drop trigger if exists trg_subscription_loan_payment_feature on public.loan_payments;
create trigger trg_subscription_loan_payment_feature before insert or update on public.loan_payments
for each row execute function public.trg_subscription_loan_payment_feature();

create or replace function public.trg_subscription_withholding_received_feature()
returns trigger language plpgsql security definer set search_path=public as $$
begin perform public.assert_subscription_feature(new.organization_id,'withholding'); return new; end; $$;
drop trigger if exists trg_subscription_withholding_received_feature on public.withholding_received;
create trigger trg_subscription_withholding_received_feature before insert or update on public.withholding_received
for each row execute function public.trg_subscription_withholding_received_feature();

create or replace function public.trg_subscription_withholding_collected_feature()
returns trigger language plpgsql security definer set search_path=public as $$
begin perform public.assert_subscription_feature(new.organization_id,'withholding'); return new; end; $$;
drop trigger if exists trg_subscription_withholding_collected_feature on public.withholding_collected;
create trigger trg_subscription_withholding_collected_feature before insert or update on public.withholding_collected
for each row execute function public.trg_subscription_withholding_collected_feature();

create or replace function public.trg_subscription_withholding_remittance_feature()
returns trigger language plpgsql security definer set search_path=public as $$
begin perform public.assert_subscription_feature(new.organization_id,'withholding'); return new; end; $$;
drop trigger if exists trg_subscription_withholding_remittance_feature on public.withholding_remittances;
create trigger trg_subscription_withholding_remittance_feature before insert or update on public.withholding_remittances
for each row execute function public.trg_subscription_withholding_remittance_feature();

revoke all on function public.subscription_snapshot(uuid) from public;
revoke all on function public.subscription_allows(uuid,text) from public;
revoke all on function public.assert_subscription_feature(uuid,text) from public;
revoke all on function public.assert_subscription_capacity(uuid,text) from public;
grant execute on function public.subscription_snapshot(uuid) to authenticated;

drop function if exists public.get_commercial_status(uuid);
create function public.get_commercial_status(p_org uuid)
returns jsonb language plpgsql security definer set search_path=public as $$
declare v jsonb; begin
  if not public.is_org_member(p_org) then raise exception 'Not authorized'; end if;
  v:=public.subscription_snapshot(p_org);
  return v || jsonb_build_object(
    'usage',jsonb_build_object(
      'members',(select count(*) from public.organization_members where organization_id=p_org and status='ACTIVE'),
      'products',(select count(*) from public.products where organization_id=p_org and active=true),
      'monthly_invoices',(select count(*) from public.sales where organization_id=p_org and sale_date>=date_trunc('month',current_date)::date and sale_date<(date_trunc('month',current_date)+interval '1 month')::date and status<>'VOIDED')
    )
  );
end; $$;
revoke all on function public.get_commercial_status(uuid) from public;
grant execute on function public.get_commercial_status(uuid) to authenticated;

insert into public.audit_logs(organization_id,actor_user_id,action,entity_type,metadata)
select os.organization_id,auth.uid(),'COMMERCIAL_ENFORCEMENT_ENABLED','subscription',jsonb_build_object('phase',20)
from public.organization_subscriptions os
where false;

-- Recreate onboarding after the member-limit trigger so a brand-new organization
-- receives its Free subscription before the first ACTIVE member is inserted.
create or replace function public.create_organization(
  p_name text,
  p_legal_name text default null,
  p_tin text default null,
  p_trade_license text default null,
  p_phone text default null,
  p_email text default null,
  p_address text default null
)
returns uuid
language plpgsql security definer set search_path=public as $$
declare v_org uuid; v_role uuid; v_plan uuid;
begin
  if auth.uid() is null then raise exception 'Authentication required'; end if;
  if nullif(trim(p_name),'') is null then raise exception 'Business name is required'; end if;
  insert into public.organizations(name,legal_name,tin,trade_license,phone,email,address)
  values(trim(p_name),nullif(trim(p_legal_name),''),nullif(trim(p_tin),''),nullif(trim(p_trade_license),''),nullif(trim(p_phone),''),nullif(trim(p_email),''),nullif(trim(p_address),''))
  returning id into v_org;
  insert into public.profiles(id) values(auth.uid()) on conflict (id) do nothing;
  insert into public.roles(organization_id,name,description,is_system)
  values(v_org,'Owner','Full access to the organization',true) returning id into v_role;
  insert into public.role_permissions(role_id,permission_id) select v_role,id from public.permissions;
  select id into v_plan from public.subscription_plans where code='FREE' and active=true;
  insert into public.organization_subscriptions(organization_id,plan_id,status,trial_ends_at,current_period_start,current_period_end)
  values(v_org,v_plan,'TRIALING',now()+interval '14 days',now(),now()+interval '14 days');
  insert into public.organization_members(organization_id,user_id,role_id,status)
  values(v_org,auth.uid(),v_role,'ACTIVE');
  insert into public.organization_settings(organization_id) values(v_org);
  return v_org;
end; $$;
grant execute on function public.create_organization(text,text,text,text,text,text,text) to authenticated;
