-- BizLedger Phase 7: secure invitation acceptance flow
-- The invitation token is never stored in plaintext. It is returned only once
-- to the authorized inviter so an email delivery service can send the link.

create or replace function public.create_invitation(
  p_org uuid,
  p_email text,
  p_role_id uuid,
  p_expires_days integer default 7
) returns jsonb
language plpgsql
security definer
set search_path=public
as $$
declare
  v_id uuid;
  v_token text;
  v_hash text;
  v_email text;
  v_expires timestamptz;
begin
  if not public.has_permission(p_org,'members.manage') then
    raise exception 'Not authorized';
  end if;

  v_email := lower(trim(p_email));
  if v_email is null or position('@' in v_email)=0 then
    raise exception 'Valid email is required';
  end if;

  if not exists(select 1 from public.roles r where r.id=p_role_id and r.organization_id=p_org) then
    raise exception 'Role does not belong to organization';
  end if;

  if exists(
    select 1 from public.organization_members m
    join auth.users u on u.id=m.user_id
    where m.organization_id=p_org
      and lower(coalesce(u.email,''))=v_email
      and m.status <> 'REMOVED'
  ) then
    raise exception 'This email already belongs to an organization member';
  end if;

  v_token := encode(gen_random_bytes(24),'hex');
  v_hash := encode(digest(v_token,'sha256'),'hex');
  v_expires := now()+make_interval(days=>greatest(1,least(coalesce(p_expires_days,7),30)));

  -- Expire older unused invitations for the same organization/email.
  update public.organization_invitations
  set expires_at=least(expires_at,now())
  where organization_id=p_org
    and lower(email)=v_email
    and accepted_at is null
    and expires_at>now();

  insert into public.organization_invitations(organization_id,email,role_id,token_hash,expires_at,created_by)
  values(p_org,v_email,p_role_id,v_hash,v_expires,auth.uid())
  returning id into v_id;

  insert into public.audit_logs(organization_id,actor_user_id,action,entity_type,entity_id,metadata)
  values(p_org,auth.uid(),'INVITE_CREATED','organization_invitation',v_id,
         jsonb_build_object('email',v_email,'role_id',p_role_id,'expires_at',v_expires));

  return jsonb_build_object('id',v_id,'token',v_token,'expires_at',v_expires);
end;
$$;

create or replace function public.redeem_invitation(p_token text)
returns jsonb
language plpgsql
security definer
set search_path=public
as $$
declare
  v_hash text;
  v_inv public.organization_invitations%rowtype;
  v_user_email text;
  v_member uuid;
begin
  if auth.uid() is null then raise exception 'You must be signed in'; end if;
  if p_token is null or length(trim(p_token)) < 20 then raise exception 'Invalid invitation'; end if;

  v_hash := encode(digest(trim(p_token),'sha256'),'hex');
  select * into v_inv
  from public.organization_invitations
  where token_hash=v_hash
  limit 1;

  if not found then raise exception 'Invitation not found or invalid'; end if;
  if v_inv.accepted_at is not null then raise exception 'Invitation has already been accepted'; end if;
  if v_inv.expires_at <= now() then raise exception 'Invitation has expired'; end if;

  select lower(email) into v_user_email from auth.users where id=auth.uid();
  if v_user_email is null or v_user_email <> lower(v_inv.email) then
    raise exception 'Signed-in email does not match the invitation email';
  end if;

  if not exists(select 1 from public.roles r where r.id=v_inv.role_id and r.organization_id=v_inv.organization_id) then
    raise exception 'Invitation role is no longer available';
  end if;

  insert into public.organization_members(organization_id,user_id,role_id,status)
  values(v_inv.organization_id,auth.uid(),v_inv.role_id,'ACTIVE')
  on conflict (organization_id,user_id) do update
    set role_id=excluded.role_id,status='ACTIVE';

  update public.organization_invitations
  set accepted_at=now()
  where id=v_inv.id and accepted_at is null;

  insert into public.audit_logs(organization_id,actor_user_id,action,entity_type,entity_id,metadata)
  values(v_inv.organization_id,auth.uid(),'INVITE_ACCEPTED','organization_invitation',v_inv.id,
         jsonb_build_object('email',v_inv.email));

  select id into v_member from public.organization_members
  where organization_id=v_inv.organization_id and user_id=auth.uid();

  return jsonb_build_object('organization_id',v_inv.organization_id,'member_id',v_member);
end;
$$;

revoke all on function public.create_invitation(uuid,text,uuid,integer) from public;
grant execute on function public.create_invitation(uuid,text,uuid,integer) to authenticated;
revoke all on function public.redeem_invitation(text) from public;
grant execute on function public.redeem_invitation(text) to authenticated;
