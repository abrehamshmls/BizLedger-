-- BizLedger Phase 24: accounting workflow hardening.
-- Adds database-level validation and diagnostic RPCs without changing historical data.

create or replace function public.assert_account_in_org(p_org uuid,p_account uuid,p_allowed_types text[] default null)
returns void language plpgsql security definer set search_path=public as $$
declare v_type text;
begin
  if p_account is null then raise exception 'Account is required'; end if;
  select type into v_type from public.accounts where id=p_account and organization_id=p_org and active=true;
  if v_type is null then raise exception 'Account does not belong to this organization or is inactive'; end if;
  if p_allowed_types is not null and not (v_type = any(p_allowed_types)) then
    raise exception 'Account type % is not allowed for this operation',v_type;
  end if;
end; $$;
grant execute on function public.assert_account_in_org(uuid,uuid,text[]) to authenticated;

-- Strengthen the journal boundary: every account must belong to the same tenant and
-- each line must contain a non-negative amount. Existing posted journals are untouched.
create or replace function public.post_journal(
  p_org uuid,p_date date,p_reference text,p_description text,
  p_source_type text,p_source_id uuid,p_lines jsonb
) returns uuid language plpgsql security definer set search_path=public as $$
declare
  v_tx uuid; v_total_debit numeric(18,2); v_total_credit numeric(18,2); v_line jsonb;
  v_account uuid; v_debit numeric(18,2); v_credit numeric(18,2); v_count int:=0;
begin
  if not public.is_org_member(p_org) then raise exception 'Not a member of this organization'; end if;
  if p_date is null then raise exception 'Transaction date is required'; end if;
  if p_lines is null or jsonb_typeof(p_lines) <> 'array' or jsonb_array_length(p_lines)=0 then raise exception 'Journal needs at least one line'; end if;
  select coalesce(sum(coalesce((x->>'debit')::numeric,0)),0), coalesce(sum(coalesce((x->>'credit')::numeric,0)),0)
    into v_total_debit,v_total_credit from jsonb_array_elements(p_lines) x;
  if v_total_debit <= 0 or round(v_total_debit,2) <> round(v_total_credit,2) then raise exception 'Journal is not balanced'; end if;
  for v_line in select * from jsonb_array_elements(p_lines) loop
    v_count:=v_count+1; v_account:=(v_line->>'account_id')::uuid;
    v_debit:=coalesce((v_line->>'debit')::numeric,0); v_credit:=coalesce((v_line->>'credit')::numeric,0);
    if v_debit < 0 or v_credit < 0 or (v_debit > 0 and v_credit > 0) or (v_debit=0 and v_credit=0) then
      raise exception 'Invalid journal line %',v_count;
    end if;
    perform public.assert_account_in_org(p_org,v_account,null);
  end loop;
  insert into public.financial_transactions(organization_id,transaction_date,reference,description,source_type,source_id,posted,created_by)
  values(p_org,p_date,p_reference,p_description,p_source_type,p_source_id,true,auth.uid()) returning id into v_tx;
  for v_line in select * from jsonb_array_elements(p_lines) loop
    insert into public.financial_transaction_lines(transaction_id,account_id,debit,credit,description)
    values(v_tx,(v_line->>'account_id')::uuid,coalesce((v_line->>'debit')::numeric,0),coalesce((v_line->>'credit')::numeric,0),v_line->>'description');
  end loop;
  return v_tx;
end; $$;
grant execute on function public.post_journal(uuid,date,text,text,text,uuid,jsonb) to authenticated;

create or replace function public.accounting_workflow_diagnostics(p_org uuid)
returns table(
  check_code text, severity text, issue_count bigint, details jsonb
) language plpgsql security definer set search_path=public as $$
begin
  if not public.is_org_member(p_org) then raise exception 'Not authorized'; end if;
  return query
  select 'UNBALANCED_POSTED_JOURNALS','ERROR',count(*),jsonb_build_object('transactions',coalesce(jsonb_agg(x.id) filter(where x.id is not null),'[]'::jsonb))
  from (
    select t.id
    from public.financial_transactions t join public.financial_transaction_lines l on l.transaction_id=t.id
    where t.organization_id=p_org and t.posted=true group by t.id
    having round(sum(l.debit),2)<>round(sum(l.credit),2)
  ) x;
  return query
  select 'ORPHAN_POSTED_JOURNALS','ERROR',count(*),jsonb_build_object('transactions',coalesce(jsonb_agg(t.id) filter(where t.id is not null),'[]'::jsonb))
  from public.financial_transactions t
  left join public.financial_transaction_lines l on l.transaction_id=t.id
  where t.organization_id=p_org and t.posted=true and l.id is null;
  return query
  select 'CROSS_ORG_JOURNAL_LINES','ERROR',count(*),jsonb_build_object('lines',coalesce(jsonb_agg(l.id) filter(where l.id is not null),'[]'::jsonb))
  from public.financial_transaction_lines l
  join public.financial_transactions t on t.id=l.transaction_id
  left join public.accounts a on a.id=l.account_id
  where t.organization_id=p_org and (a.id is null or a.organization_id<>p_org);
  return query
  select 'NEGATIVE_INVENTORY','ERROR',count(*),jsonb_build_object('products',coalesce(jsonb_agg(x.product_id),'[]'::jsonb))
  from (select product_id from public.inventory_movements where organization_id=p_org group by product_id having sum(quantity)<0) x;
  return query
  select 'POSTED_DOCUMENT_WITHOUT_JOURNAL','ERROR',count(*),jsonb_build_object('documents',coalesce(jsonb_agg(x.id),'[]'::jsonb))
  from (
    select s.id from public.sales s where s.organization_id=p_org and s.status in ('POSTED','PARTIALLY_PAID','PAID')
      and not exists(select 1 from public.financial_transactions t where t.organization_id=p_org and t.source_type='SALE' and t.source_id=s.id and t.posted=true)
    union all
    select p.id from public.purchases p where p.organization_id=p_org and p.status in ('POSTED','PARTIALLY_PAID','PAID')
      and not exists(select 1 from public.financial_transactions t where t.organization_id=p_org and t.source_type='PURCHASE' and t.source_id=p.id and t.posted=true)
    union all
    select e.id from public.expenses e where e.organization_id=p_org and e.status in ('POSTED','PARTIALLY_PAID','PAID')
      and not exists(select 1 from public.financial_transactions t where t.organization_id=p_org and t.source_type='EXPENSE' and t.source_id=e.id and t.posted=true)
  ) x;
  return query
  select 'DRAFT_DOCUMENTS_WITH_JOURNAL','WARNING',count(*),jsonb_build_object('documents',coalesce(jsonb_agg(x.id),'[]'::jsonb))
  from (
    select s.id from public.sales s where s.organization_id=p_org and s.status='DRAFT' and exists(select 1 from public.financial_transactions t where t.organization_id=p_org and t.source_type='SALE' and t.source_id=s.id and t.posted=true)
    union all select p.id from public.purchases p where p.organization_id=p_org and p.status='DRAFT' and exists(select 1 from public.financial_transactions t where t.organization_id=p_org and t.source_type='PURCHASE' and t.source_id=p.id and t.posted=true)
    union all select e.id from public.expenses e where e.organization_id=p_org and e.status='DRAFT' and exists(select 1 from public.financial_transactions t where t.organization_id=p_org and t.source_type='EXPENSE' and t.source_id=e.id and t.posted=true)
  ) x;
end; $$;
grant execute on function public.accounting_workflow_diagnostics(uuid) to authenticated;

create index if not exists idx_financial_transactions_org_source on public.financial_transactions(organization_id,source_type,source_id,posted);
create index if not exists idx_financial_transaction_lines_tx_account on public.financial_transaction_lines(transaction_id,account_id);
