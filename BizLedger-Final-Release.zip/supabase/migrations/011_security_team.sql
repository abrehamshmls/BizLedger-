-- BizLedger Phase 6: production hardening, team administration and audit helpers

create index if not exists idx_members_org_status on public.organization_members(organization_id,status);
create index if not exists idx_members_org_role on public.organization_members(organization_id,role_id);
create index if not exists idx_audit_org_created on public.audit_logs(organization_id,created_at desc);
create index if not exists idx_sales_org_date_status on public.sales(organization_id,sale_date,status);
create index if not exists idx_purchases_org_date_status on public.purchases(organization_id,purchase_date,status);

create or replace function public.has_permission(target_org uuid, permission_key text)
returns boolean language sql stable security definer set search_path=public as $$
  select exists (
    select 1 from public.organization_members m
    join public.role_permissions rp on rp.role_id=m.role_id
    where m.organization_id=target_org and m.user_id=auth.uid()
      and m.status='ACTIVE' and rp.permission_id=permission_key
  );
$$;

create or replace function public.invite_member(
  p_org uuid, p_email text, p_role_id uuid, p_expires_days integer default 7
) returns uuid language plpgsql security definer set search_path=public as $$
declare v_id uuid; v_token text; v_hash text;
begin
  if not public.has_permission(p_org,'members.manage') then raise exception 'Not authorized'; end if;
  if p_email is null or position('@' in trim(p_email))=0 then raise exception 'Valid email is required'; end if;
  if not exists(select 1 from public.roles r where r.id=p_role_id and r.organization_id=p_org) then raise exception 'Role does not belong to organization'; end if;
  v_token:=encode(gen_random_bytes(24),'hex');
  v_hash:=encode(digest(v_token,'sha256'),'hex');
  insert into public.organization_invitations(organization_id,email,role_id,token_hash,expires_at,created_by)
  values(p_org,lower(trim(p_email)),p_role_id,v_hash,now()+make_interval(days=>greatest(1,least(p_expires_days,30))),auth.uid())
  returning id into v_id;
  insert into public.audit_logs(organization_id,actor_user_id,action,entity_type,entity_id,metadata)
  values(p_org,auth.uid(),'INVITE_CREATED','organization_invitation',v_id,jsonb_build_object('email',lower(trim(p_email)),'role_id',p_role_id));
  return v_id;
end;
$$;

create or replace function public.set_member_status(p_org uuid,p_member uuid,p_status public.member_status)
returns void language plpgsql security definer set search_path=public as $$
declare v_user uuid;
begin
  if not public.has_permission(p_org,'members.manage') then raise exception 'Not authorized'; end if;
  select user_id into v_user from public.organization_members where id=p_member and organization_id=p_org;
  if v_user is null then raise exception 'Member not found'; end if;
  if v_user=auth.uid() and p_status <> 'ACTIVE' then raise exception 'You cannot suspend or remove yourself'; end if;
  update public.organization_members set status=p_status where id=p_member and organization_id=p_org;
  insert into public.audit_logs(organization_id,actor_user_id,action,entity_type,entity_id,metadata)
  values(p_org,auth.uid(),'MEMBER_STATUS_CHANGED','organization_member',p_member,jsonb_build_object('status',p_status));
end;
$$;

create or replace function public.change_member_role(p_org uuid,p_member uuid,p_role uuid)
returns void language plpgsql security definer set search_path=public as $$
begin
  if not public.has_permission(p_org,'roles.manage') then raise exception 'Not authorized'; end if;
  if not exists(select 1 from public.organization_members where id=p_member and organization_id=p_org) then raise exception 'Member not found'; end if;
  if not exists(select 1 from public.roles where id=p_role and organization_id=p_org) then raise exception 'Role does not belong to organization'; end if;
  update public.organization_members set role_id=p_role where id=p_member and organization_id=p_org;
  insert into public.audit_logs(organization_id,actor_user_id,action,entity_type,entity_id,metadata)
  values(p_org,auth.uid(),'MEMBER_ROLE_CHANGED','organization_member',p_member,jsonb_build_object('role_id',p_role));
end;
$$;

create or replace function public.create_audit_event(p_org uuid,p_action text,p_entity_type text,p_entity_id uuid,p_details jsonb default '{}'::jsonb)
returns uuid language plpgsql security definer set search_path=public as $$
declare v_id uuid;
begin
  if not public.is_org_member(p_org) then raise exception 'Not authorized'; end if;
  insert into public.audit_logs(organization_id,actor_user_id,action,entity_type,entity_id,metadata)
  values(p_org,auth.uid(),p_action,p_entity_type,p_entity_id,coalesce(p_details,'{}'::jsonb)) returning id into v_id;
  return v_id;
end;
$$;

-- Invitation rows are only visible to authorized administrators.
drop policy if exists invitations_access on public.organization_invitations;
create policy invitations_admin_read on public.organization_invitations for select
using (public.has_permission(organization_id,'members.manage'));

-- Members remain readable to members, but writes must go through controlled RPCs.
drop policy if exists member_self_or_org on public.organization_members;
create policy member_read_self_or_org on public.organization_members for select
using (user_id=auth.uid() or public.is_org_member(organization_id));

revoke all on function public.invite_member(uuid,text,uuid,integer) from public;
grant execute on function public.invite_member(uuid,text,uuid,integer) to authenticated;
revoke all on function public.set_member_status(uuid,uuid,public.member_status) from public;
grant execute on function public.set_member_status(uuid,uuid,public.member_status) to authenticated;
revoke all on function public.change_member_role(uuid,uuid,uuid) from public;
grant execute on function public.change_member_role(uuid,uuid,uuid) to authenticated;
revoke all on function public.create_audit_event(uuid,text,text,uuid,jsonb) from public;
grant execute on function public.create_audit_event(uuid,text,text,uuid,jsonb) to authenticated;
