-- BizLedger Phase 9: controlled legacy migration staging
-- Staging is deliberately separate from production accounting tables.
-- Nothing in this migration posts journals, inventory movements, payments, or documents.

create table if not exists public.migration_batches (
  id uuid primary key default gen_random_uuid(),
  organization_id uuid not null references public.organizations(id) on delete cascade,
  source_name text not null,
  source_sha256 text,
  status text not null default 'STAGED' check (status in ('STAGED','VALIDATED','IMPORTED','CANCELLED')),
  summary jsonb not null default '{}'::jsonb,
  config jsonb not null default '{}'::jsonb,
  created_by uuid not null references auth.users(id),
  created_at timestamptz not null default now(),
  validated_at timestamptz,
  imported_at timestamptz
);

create table if not exists public.migration_rows (
  id uuid primary key default gen_random_uuid(),
  batch_id uuid not null references public.migration_batches(id) on delete cascade,
  module text not null,
  row_number integer not null,
  raw_data jsonb not null,
  status text not null default 'PENDING' check (status in ('PENDING','READY','REVIEW','ERROR','IMPORTED')),
  issues jsonb not null default '[]'::jsonb,
  created_at timestamptz not null default now(),
  unique(batch_id,module,row_number)
);

create index if not exists idx_migration_batches_org_created
  on public.migration_batches(organization_id,created_at desc);
create index if not exists idx_migration_rows_batch_module
  on public.migration_rows(batch_id,module,row_number);

alter table public.migration_batches enable row level security;
alter table public.migration_rows enable row level security;

drop policy if exists migration_batches_admin on public.migration_batches;
create policy migration_batches_admin on public.migration_batches for all
using (public.has_permission(organization_id,'members.manage'))
with check (public.has_permission(organization_id,'members.manage'));

drop policy if exists migration_rows_admin on public.migration_rows;
create policy migration_rows_admin on public.migration_rows for all
using (exists (
  select 1 from public.migration_batches b
  where b.id=batch_id and public.has_permission(b.organization_id,'members.manage')
))
with check (exists (
  select 1 from public.migration_batches b
  where b.id=batch_id and public.has_permission(b.organization_id,'members.manage')
));

create or replace function public.create_migration_batch(
  p_org uuid,
  p_source_name text,
  p_source_sha256 text,
  p_summary jsonb,
  p_config jsonb default '{}'::jsonb
) returns uuid
language plpgsql security definer set search_path=public as $$
declare v_id uuid;
begin
  if not public.has_permission(p_org,'members.manage') then raise exception 'Not authorized'; end if;
  if nullif(trim(p_source_name),'') is null then raise exception 'Source file name is required'; end if;
  insert into public.migration_batches(organization_id,source_name,source_sha256,summary,config,created_by)
  values(p_org,trim(p_source_name),nullif(trim(p_source_sha256),''),coalesce(p_summary,'{}'::jsonb),coalesce(p_config,'{}'::jsonb),auth.uid())
  returning id into v_id;
  insert into public.audit_logs(organization_id,actor_user_id,action,entity_type,entity_id,metadata)
  values(p_org,auth.uid(),'MIGRATION_BATCH_CREATED','migration_batch',v_id,
         jsonb_build_object('source_name',p_source_name,'source_sha256',p_source_sha256));
  return v_id;
end;
$$;

create or replace function public.mark_migration_batch_validated(p_batch uuid)
returns void language plpgsql security definer set search_path=public as $$
declare v_org uuid; v_errors integer; v_review integer;
begin
  select organization_id into v_org from public.migration_batches where id=p_batch;
  if v_org is null then raise exception 'Migration batch not found'; end if;
  if not public.has_permission(v_org,'members.manage') then raise exception 'Not authorized'; end if;
  select count(*) filter (where status='ERROR'), count(*) filter (where status='REVIEW')
    into v_errors,v_review from public.migration_rows where batch_id=p_batch;
  if v_errors > 0 then raise exception 'Migration batch has % error rows',v_errors; end if;
  update public.migration_batches
    set status='VALIDATED',validated_at=now()
    where id=p_batch;
  insert into public.audit_logs(organization_id,actor_user_id,action,entity_type,entity_id,metadata)
  values(v_org,auth.uid(),'MIGRATION_BATCH_VALIDATED','migration_batch',p_batch,
         jsonb_build_object('review_rows',v_review));
end;
$$;

revoke all on function public.create_migration_batch(uuid,text,text,jsonb,jsonb) from public;
grant execute on function public.create_migration_batch(uuid,text,text,jsonb,jsonb) to authenticated;
revoke all on function public.mark_migration_batch_validated(uuid) from public;
grant execute on function public.mark_migration_batch_validated(uuid) to authenticated;
