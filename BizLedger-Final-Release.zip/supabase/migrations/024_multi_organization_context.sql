-- BizLedger Phase 22: multi-organization UX support
-- The browser stores the selected membership, while all organization-scoped
-- writes below explicitly carry organization_id. RLS remains the security boundary.
create index if not exists idx_organization_members_user_status_org
  on public.organization_members(user_id, status, organization_id);

create or replace function public.user_has_active_membership(p_org uuid)
returns boolean
language sql
stable
security definer
set search_path = public
as $$
  select exists (
    select 1 from public.organization_members om
    where om.organization_id = p_org
      and om.user_id = auth.uid()
      and om.status = 'ACTIVE'
  );
$$;

revoke all on function public.user_has_active_membership(uuid) from public;
grant execute on function public.user_has_active_membership(uuid) to authenticated;
