-- BizLedger Phase 1C: permission vocabulary
insert into public.permissions (id, description) values
('dashboard.view','View dashboard'),
('contacts.view','View contacts'),('contacts.manage','Create/update contacts'),
('products.view','View products'),('products.manage','Create/update products'),
('sales.view','View sales'),('sales.manage','Create/update sales'),('sales.post','Post/void sales'),
('purchases.view','View purchases'),('purchases.manage','Create/update purchases'),('purchases.post','Post/void purchases'),
('expenses.view','View expenses'),('expenses.manage','Create/update expenses'),('expenses.post','Post/void expenses'),
('payments.view','View payments'),('payments.manage','Create/update payments'),
('inventory.view','View inventory'),('inventory.manage','Create inventory adjustments'),
('production.view','View production'),('production.manage','Create/update production'),
('loans.view','View loans'),('loans.manage','Create/update loans'),
('withholding.view','View withholding'),('withholding.manage','Create/update withholding'),
('reports.view','View reports'),('settings.manage','Manage organization settings'),
('members.manage','Manage members and invitations'),('roles.manage','Manage roles and permissions'),
('audit.view','View audit log')
on conflict (id) do update set description = excluded.description;
