-- BizLedger Phase 12: controlled core financial import
-- Imports sales, purchases, expenses and legacy transaction payments only.
-- Inventory, loans and withholding remain separate controlled stages.

create table if not exists public.migration_import_runs (
  id uuid primary key default gen_random_uuid(),
  batch_id uuid not null references public.migration_batches(id) on delete cascade,
  organization_id uuid not null references public.organizations(id) on delete cascade,
  stage text not null default 'CORE_FINANCIAL',
  status text not null default 'STARTED' check (status in ('STARTED','COMPLETED','FAILED')),
  dry_run boolean not null default false,
  result jsonb not null default '{}'::jsonb,
  created_by uuid references auth.users(id) on delete set null,
  created_at timestamptz not null default now(),
  completed_at timestamptz
);

create index if not exists idx_migration_import_runs_batch on public.migration_import_runs(batch_id, created_at desc);
alter table public.migration_import_runs enable row level security;
drop policy if exists migration_import_runs_admin on public.migration_import_runs;
create policy migration_import_runs_admin on public.migration_import_runs for all
using (public.has_permission(organization_id,'members.manage'))
with check (public.has_permission(organization_id,'members.manage'));

create or replace function public.migration_core_financial_preflight(p_batch uuid)
returns jsonb
language plpgsql security definer set search_path=public as $$
declare
  b public.migration_batches%rowtype;
  v_errors integer;
  v_missing_products integer;
  v_missing_contacts integer;
  v_duplicate_docs integer;
  v_total integer;
  v_result jsonb;
begin
  select * into b from public.migration_batches where id=p_batch;
  if not found then raise exception 'Migration batch not found'; end if;
  if not public.has_permission(b.organization_id,'members.manage') then raise exception 'Not authorized'; end if;
  if b.status <> 'VALIDATED' then raise exception 'Migration batch must be VALIDATED'; end if;

  select count(*) into v_errors from public.migration_financial_rows where batch_id=p_batch and status='ERROR';
  select count(*) into v_total from public.migration_financial_rows where batch_id=p_batch and module in ('sales','purchases','expenses','txpay');

  select count(*) into v_missing_products
  from public.migration_financial_rows f
  where f.batch_id=p_batch and f.module in ('sales','purchases') and f.status in ('READY','REVIEW')
    and not exists (
      select 1 from public.migration_rows mr
      join public.migration_mappings mm on mm.batch_id=p_batch and mm.migration_row_id=mr.id and mm.module='products'
      where mr.batch_id=p_batch and mr.module='products'
        and mr.raw_data->>'id' = coalesce(f.raw_data->>'productId',f.raw_data->>'product_id')
    )
    and not exists (
      select 1 from public.products p
      where p.organization_id=b.organization_id
        and lower(trim(p.name))=lower(trim(coalesce(f.raw_data->>'product',f.raw_data->>'productName','')))
    );

  select count(*) into v_missing_contacts
  from public.migration_financial_rows f
  where f.batch_id=p_batch and f.module in ('sales','purchases') and f.status in ('READY','REVIEW')
    and nullif(trim(coalesce(f.raw_data->>'buyer',f.raw_data->>'supplier',f.raw_data->>'customer','')),'') is not null
    and not exists (
      select 1 from public.migration_rows mr
      join public.migration_mappings mm on mm.batch_id=p_batch and mm.migration_row_id=mr.id and mm.module='contacts'
      where mr.batch_id=p_batch and mr.module='contacts'
        and mr.raw_data->>'id' = coalesce(f.raw_data->>'buyerContactId',f.raw_data->>'supplierContactId',f.raw_data->>'contactId')
    )
    and not exists (
      select 1 from public.contacts c
      where c.organization_id=b.organization_id
        and lower(trim(c.name))=lower(trim(coalesce(f.raw_data->>'buyer',f.raw_data->>'supplier',f.raw_data->>'customer','')))
    );

  select count(*) into v_duplicate_docs
  from public.migration_financial_rows f
  where f.batch_id=p_batch and f.module in ('sales','purchases')
    and exists (
      select 1 from public.sales s where f.module='sales' and s.organization_id=b.organization_id and s.invoice_number=coalesce(f.raw_data->>'invoice',f.raw_data->>'voucher','')
      union all
      select 1 from public.purchases p where f.module='purchases' and p.organization_id=b.organization_id and p.invoice_number=coalesce(f.raw_data->>'invoice',f.raw_data->>'voucher','')
    );

  v_result=jsonb_build_object(
    'batch_id',p_batch,'status',case when v_errors=0 and v_missing_products=0 and v_missing_contacts=0 and v_duplicate_docs=0 then 'READY' else 'BLOCKED' end,
    'rows',v_total,'errors',v_errors,'missing_products',v_missing_products,'missing_contacts',v_missing_contacts,'duplicate_documents',v_duplicate_docs,
    'allowed_modules',jsonb_build_array('sales','purchases','expenses','txpay')
  );
  return v_result;
end;
$$;

create or replace function public.import_migration_core_financial(p_batch uuid, p_confirm boolean default false)
returns jsonb
language plpgsql security definer set search_path=public as $$
declare
  b public.migration_batches%rowtype;
  pre jsonb;
  run_id uuid;
  f record;
  l_date date;
  v_contact uuid;
  v_product uuid;
  v_source uuid;
  v_new uuid;
  v_invoice text;
  v_amount numeric(18,2);
  v_qty numeric(18,6);
  v_price numeric(18,6);
  v_due date;
  v_count_sales integer:=0; v_count_purchases integer:=0; v_count_expenses integer:=0; v_count_payments integer:=0;
  v_payment_account uuid;
  v_result jsonb;
begin
  select * into b from public.migration_batches where id=p_batch for update;
  if not found then raise exception 'Migration batch not found'; end if;
  if not public.has_permission(b.organization_id,'members.manage') then raise exception 'Not authorized'; end if;
  if b.status <> 'VALIDATED' then raise exception 'Migration batch must be VALIDATED'; end if;

  pre:=public.migration_core_financial_preflight(p_batch);
  if pre->>'status' <> 'READY' then raise exception 'Core financial migration is blocked: %',pre; end if;
  if not p_confirm then return pre || jsonb_build_object('confirmation_required',true); end if;

  select id into v_payment_account from public.organization_settings where organization_id=b.organization_id;
  -- organization_settings stores no account object in most installations; use configured account only if valid, else cash.
  v_payment_account:=coalesce((select default_payment_account from public.organization_settings where organization_id=b.organization_id), public.account_id_by_code(b.organization_id,'1000'));
  if v_payment_account is null then raise exception 'No default payment account available'; end if;

  insert into public.migration_import_runs(batch_id,organization_id,status,dry_run,created_by)
  values(p_batch,b.organization_id,'STARTED',false,auth.uid()) returning id into run_id;

  -- Sales and purchases are imported as drafts, then posted through the same accounting functions used by the live app.
  for f in select * from public.migration_financial_rows where batch_id=p_batch and module in ('sales','purchases') and status in ('READY','REVIEW') order by module,row_number loop
    l_date:=coalesce(nullif(f.raw_data->>'dateISO','')::date,nullif(f.raw_data->>'date','')::date);
    v_qty:=coalesce(nullif(f.raw_data->>'qty','')::numeric,nullif(f.raw_data->>'quantity','')::numeric,0);
    v_price:=coalesce(nullif(f.raw_data->>'price','')::numeric,0);
    v_invoice:=coalesce(nullif(trim(f.raw_data->>'invoice'),''),nullif(trim(f.raw_data->>'voucher'),''),format('MIG-%s-%s',f.module,f.row_number));
    v_due:=coalesce(nullif(f.raw_data->>'dueDateISO','')::date,nullif(f.raw_data->>'dueDate','')::date);
    v_contact:=null; v_product:=null;

    select mm.target_id into v_product from public.migration_rows mr join public.migration_mappings mm on mm.batch_id=p_batch and mm.migration_row_id=mr.id and mm.module='products'
      where mr.batch_id=p_batch and mr.module='products' and mr.raw_data->>'id'=coalesce(f.raw_data->>'productId',f.raw_data->>'product_id') limit 1;
    if v_product is null then select id into v_product from public.products where organization_id=b.organization_id and lower(trim(name))=lower(trim(coalesce(f.raw_data->>'product',f.raw_data->>'productName',''))) limit 1; end if;
    if v_product is null then raise exception 'Product mapping missing for % row %',f.module,f.row_number; end if;

    select mm.target_id into v_contact from public.migration_rows mr join public.migration_mappings mm on mm.batch_id=p_batch and mm.migration_row_id=mr.id and mm.module='contacts'
      where mr.batch_id=p_batch and mr.module='contacts' and mr.raw_data->>'id'=coalesce(f.raw_data->>'buyerContactId',f.raw_data->>'supplierContactId',f.raw_data->>'contactId') limit 1;
    if v_contact is null then select id into v_contact from public.contacts where organization_id=b.organization_id and lower(trim(name))=lower(trim(coalesce(f.raw_data->>'buyer',f.raw_data->>'supplier',f.raw_data->>'customer',''))) limit 1; end if;

    if f.module='sales' then
      insert into public.sales(organization_id,invoice_number,sale_date,customer_id,status,due_date,subtotal,total_amount,created_by,notes)
      values(b.organization_id,v_invoice,l_date,v_contact,'DRAFT',v_due,round((v_qty*v_price)::numeric,2),round((v_qty*v_price)::numeric,2),auth.uid(),'Imported from legacy BizLedger') returning id into v_new;
      insert into public.sale_lines(sale_id,product_id,description,quantity,unit_price,line_total)
      values(v_new,v_product,nullif(f.raw_data->>'product',''),v_qty,v_price,round((v_qty*v_price)::numeric,2));
      perform public.post_sale(v_new); v_count_sales:=v_count_sales+1;
    else
      insert into public.purchases(organization_id,invoice_number,purchase_date,supplier_id,status,due_date,subtotal,total_amount,created_by,notes)
      values(b.organization_id,v_invoice,l_date,v_contact,'DRAFT',v_due,round((v_qty*v_price)::numeric,2),round((v_qty*v_price)::numeric,2),auth.uid(),'Imported from legacy BizLedger') returning id into v_new;
      insert into public.purchase_lines(purchase_id,product_id,description,quantity,unit_price,line_total)
      values(v_new,v_product,nullif(f.raw_data->>'product',''),v_qty,v_price,round((v_qty*v_price)::numeric,2));
      perform public.post_purchase(v_new); v_count_purchases:=v_count_purchases+1;
    end if;
    update public.migration_financial_rows set proposed_source_id=v_new,status='IMPORTED' where id=f.id;
  end loop;

  -- Expenses use the production posting function; vendor/contact is optional.
  for f in select * from public.migration_financial_rows where batch_id=p_batch and module='expenses' and status in ('READY','REVIEW') order by row_number loop
    l_date:=coalesce(nullif(f.raw_data->>'dateISO','')::date,nullif(f.raw_data->>'date','')::date);
    v_amount:=coalesce(nullif(f.raw_data->>'amount','')::numeric,0);
    select mm.target_id into v_contact from public.migration_rows mr join public.migration_mappings mm on mm.batch_id=p_batch and mm.migration_row_id=mr.id and mm.module='contacts'
      where mr.batch_id=p_batch and mr.module='contacts' and mr.raw_data->>'id'=f.raw_data->>'contactId' limit 1;
    insert into public.expenses(organization_id,expense_date,reference,vendor_id,status,category,amount,notes,created_by)
    values(b.organization_id,l_date,nullif(f.raw_data->>'voucher',''),v_contact,'DRAFT',nullif(f.raw_data->>'cat',''),v_amount,nullif(f.raw_data->>'desc',''),auth.uid()) returning id into v_new;
    perform public.post_expense(v_new); v_count_expenses:=v_count_expenses+1;
    update public.migration_financial_rows set proposed_source_id=v_new,status='IMPORTED' where id=f.id;
  end loop;

  -- Legacy txpay rows are matched to the imported source by the legacy sourceId.
  for f in select * from public.migration_financial_rows where batch_id=p_batch and module='txpay' and status in ('READY','REVIEW') order by row_number loop
    l_date:=coalesce(nullif(f.raw_data->>'dateISO','')::date,nullif(f.raw_data->>'date','')::date);
    v_amount:=coalesce(nullif(f.raw_data->>'amount','')::numeric,0);
    v_source:=null;
    if f.raw_data->>'sourceKind'='sales' then
      select mf.proposed_source_id into v_source from public.migration_financial_rows mf where mf.batch_id=p_batch and mf.module='sales' and mf.raw_data->>'id'=f.raw_data->>'sourceId' and mf.status='IMPORTED' limit 1;
    elsif f.raw_data->>'sourceKind'='purchases' then
      select mf.proposed_source_id into v_source from public.migration_financial_rows mf where mf.batch_id=p_batch and mf.module='purchases' and mf.raw_data->>'id'=f.raw_data->>'sourceId' and mf.status='IMPORTED' limit 1;
    end if;
    if v_source is null then raise exception 'Payment source mapping missing for txpay row %',f.row_number; end if;
    perform public.record_payment(b.organization_id,case when f.raw_data->>'sourceKind'='sales' then 'SALE' else 'PURCHASE' end,v_source,v_payment_account,l_date,v_amount,null,null);
    update public.migration_financial_rows set proposed_source_id=v_source,status='IMPORTED' where id=f.id;
    v_count_payments:=v_count_payments+1;
  end loop;

  update public.migration_batches set status='IMPORTED',imported_at=now(),summary=summary||jsonb_build_object('core_financial_import',jsonb_build_object('run_id',run_id,'sales',v_count_sales,'purchases',v_count_purchases,'expenses',v_count_expenses,'payments',v_count_payments)) where id=p_batch;
  update public.migration_import_runs set status='COMPLETED',completed_at=now(),result=jsonb_build_object('sales',v_count_sales,'purchases',v_count_purchases,'expenses',v_count_expenses,'payments',v_count_payments) where id=run_id;
  insert into public.audit_logs(organization_id,actor_user_id,action,entity_type,entity_id,metadata)
  values(b.organization_id,auth.uid(),'MIGRATION_CORE_FINANCIAL_IMPORTED','migration_batch',p_batch,jsonb_build_object('run_id',run_id,'sales',v_count_sales,'purchases',v_count_purchases,'expenses',v_count_expenses,'payments',v_count_payments));

  v_result=jsonb_build_object('status','COMPLETED','run_id',run_id,'sales',v_count_sales,'purchases',v_count_purchases,'expenses',v_count_expenses,'payments',v_count_payments);
  return v_result;
exception when others then
  if run_id is not null then update public.migration_import_runs set status='FAILED',completed_at=now(),result=jsonb_build_object('error',sqlerrm) where id=run_id; end if;
  raise;
end;
$$;

revoke all on function public.migration_core_financial_preflight(uuid) from public;
grant execute on function public.migration_core_financial_preflight(uuid) to authenticated;
revoke all on function public.import_migration_core_financial(uuid,boolean) from public;
grant execute on function public.import_migration_core_financial(uuid,boolean) to authenticated;
