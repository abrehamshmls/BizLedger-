-- BizLedger Phase 1D: secure organization onboarding
create or replace function public.create_organization(
  p_name text,
  p_legal_name text default null,
  p_tin text default null,
  p_trade_license text default null,
  p_phone text default null,
  p_email text default null,
  p_address text default null
)
returns uuid
language plpgsql
security definer
set search_path = public
as $$
declare
  v_org uuid;
  v_role uuid;
begin
  if auth.uid() is null then
    raise exception 'Authentication required';
  end if;
  if nullif(trim(p_name), '') is null then
    raise exception 'Business name is required';
  end if;

  insert into public.organizations(name, legal_name, tin, trade_license, phone, email, address)
  values (trim(p_name), nullif(trim(p_legal_name), ''), nullif(trim(p_tin), ''),
          nullif(trim(p_trade_license), ''), nullif(trim(p_phone), ''),
          nullif(trim(p_email), ''), nullif(trim(p_address), ''))
  returning id into v_org;

  insert into public.profiles(id)
  values (auth.uid())
  on conflict (id) do nothing;

  insert into public.roles(organization_id, name, description, is_system)
  values (v_org, 'Owner', 'Full access to the organization', true)
  returning id into v_role;

  insert into public.role_permissions(role_id, permission_id)
  select v_role, id from public.permissions;

  insert into public.organization_members(organization_id, user_id, role_id, status)
  values (v_org, auth.uid(), v_role, 'ACTIVE');

  insert into public.organization_settings(organization_id)
  values (v_org);

  return v_org;
end;
$$;

grant execute on function public.create_organization(text,text,text,text,text,text,text) to authenticated;
