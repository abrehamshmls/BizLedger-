-- BizLedger Phase 19: production observability, recovery checks and release safeguards

create table if not exists public.recovery_check_runs (
  id uuid primary key default gen_random_uuid(),
  organization_id uuid not null references public.organizations(id) on delete cascade,
  check_type text not null,
  status text not null check (status in ('PASS','WARN','FAIL')),
  details jsonb not null default '{}'::jsonb,
  checked_by uuid references auth.users(id),
  created_at timestamptz not null default now()
);
create index if not exists idx_recovery_check_runs_org_created
  on public.recovery_check_runs(organization_id, created_at desc);
alter table public.recovery_check_runs enable row level security;
drop policy if exists recovery_check_runs_read on public.recovery_check_runs;
create policy recovery_check_runs_read on public.recovery_check_runs for select
using (public.is_org_member(organization_id) and public.has_permission(organization_id,'audit.view'));

create or replace function public.run_production_recovery_checks(p_org uuid)
returns jsonb
language plpgsql security definer set search_path=public as $$
declare
  v_unbalanced bigint := 0;
  v_stale bigint := 0;
  v_unresolved bigint := 0;
  v_result jsonb;
begin
  if not public.is_org_member(p_org) then raise exception 'Not authorized'; end if;
  if not public.has_permission(p_org,'audit.view') then raise exception 'Audit permission required'; end if;

  select count(*) into v_unbalanced
  from public.journal_entries j
  where j.organization_id=p_org and j.status='POSTED'
    and abs(coalesce((select sum(l.debit) from public.journal_lines l where l.journal_entry_id=j.id),0)
          -coalesce((select sum(l.credit) from public.journal_lines l where l.journal_entry_id=j.id),0)) > 0.005;

  select count(*) into v_stale
  from public.financial_operation_keys
  where organization_id=p_org and result_id is null and created_at < now() - interval '30 minutes';

  select count(*) into v_unresolved
  from public.migration_financial_rows
  where organization_id=p_org and status in ('ERROR','REVIEW');

  v_result := jsonb_build_object(
    'ready', v_unbalanced=0 and v_stale=0,
    'unbalanced_posted_entries',v_unbalanced,
    'stale_financial_operations',v_stale,
    'unresolved_migration_rows',v_unresolved,
    'checked_at',now()
  );

  insert into public.recovery_check_runs(organization_id,check_type,status,details,checked_by)
  values(p_org,'PRODUCTION_RECOVERY',
    case when v_unbalanced=0 and v_stale=0 then 'PASS' else 'FAIL' end,
    v_result,auth.uid());
  return v_result;
end; $$;
revoke all on function public.run_production_recovery_checks(uuid) from public;
grant execute on function public.run_production_recovery_checks(uuid) to authenticated;

create or replace function public.get_production_release_report(p_org uuid)
returns jsonb
language plpgsql security definer set search_path=public as $$
declare
  v_result jsonb;
begin
  if not public.is_org_member(p_org) then raise exception 'Not authorized'; end if;
  if not public.has_permission(p_org,'audit.view') then raise exception 'Audit permission required'; end if;
  select jsonb_build_object(
    'cutover_locked', coalesce(public.is_cutover_locked(p_org),false),
    'recent_error_events', (select count(*) from public.application_error_events where organization_id=p_org and created_at >= now()-interval '24 hours'),
    'active_operations', (select count(*) from public.financial_operation_keys where organization_id=p_org and result_id is null),
    'stale_operations', (select count(*) from public.financial_operation_keys where organization_id=p_org and result_id is null and created_at < now()-interval '30 minutes'),
    'last_recovery_check', (select jsonb_build_object('status',status,'created_at',created_at,'details',details) from public.recovery_check_runs where organization_id=p_org order by created_at desc limit 1)
  ) into v_result;
  return v_result;
end; $$;
revoke all on function public.get_production_release_report(uuid) from public;
grant execute on function public.get_production_release_report(uuid) to authenticated;
