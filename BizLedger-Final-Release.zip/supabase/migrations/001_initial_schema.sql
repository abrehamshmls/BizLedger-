-- BizLedger Phase 1C: initial PostgreSQL schema
create extension if not exists pgcrypto;

create type public.member_status as enum ('INVITED','ACTIVE','SUSPENDED','REMOVED');
create type public.document_status as enum ('DRAFT','POSTED','PARTIALLY_PAID','PAID','VOIDED');
create type public.contact_kind as enum ('CUSTOMER','SUPPLIER','OTHER');
create type public.product_type as enum ('PRODUCT','SERVICE','RAW_MATERIAL','FINISHED_GOOD','OTHER');
create type public.inventory_movement_type as enum ('PURCHASE','SALE','PRODUCTION_INPUT','PRODUCTION_OUTPUT','ADJUSTMENT','OPENING');
create type public.payment_direction as enum ('IN','OUT');
create type public.account_type as enum ('CASH','BANK','RECEIVABLE','PAYABLE','INCOME','EXPENSE','INVENTORY','ASSET','LIABILITY','EQUITY','OTHER');

create table public.organizations (
  id uuid primary key default gen_random_uuid(),
  name text not null,
  legal_name text,
  tin text,
  trade_license text,
  phone text,
  email text,
  address text,
  country_code text not null default 'ET',
  base_currency text not null default 'ETB',
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now()
);

create table public.profiles (
  id uuid primary key references auth.users(id) on delete cascade,
  full_name text,
  phone text,
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now()
);

create table public.roles (
  id uuid primary key default gen_random_uuid(),
  organization_id uuid not null references public.organizations(id) on delete cascade,
  name text not null,
  description text,
  is_system boolean not null default false,
  created_at timestamptz not null default now(),
  unique (organization_id, name)
);

create table public.permissions (
  id text primary key,
  description text not null
);

create table public.role_permissions (
  role_id uuid not null references public.roles(id) on delete cascade,
  permission_id text not null references public.permissions(id) on delete cascade,
  primary key (role_id, permission_id)
);

create table public.organization_members (
  id uuid primary key default gen_random_uuid(),
  organization_id uuid not null references public.organizations(id) on delete cascade,
  user_id uuid not null references auth.users(id) on delete cascade,
  role_id uuid references public.roles(id) on delete set null,
  status public.member_status not null default 'ACTIVE',
  joined_at timestamptz not null default now(),
  unique (organization_id, user_id)
);

create table public.organization_invitations (
  id uuid primary key default gen_random_uuid(),
  organization_id uuid not null references public.organizations(id) on delete cascade,
  email text not null,
  role_id uuid references public.roles(id) on delete set null,
  token_hash text not null,
  expires_at timestamptz not null,
  accepted_at timestamptz,
  created_by uuid references auth.users(id) on delete set null,
  created_at timestamptz not null default now()
);

create table public.organization_settings (
  organization_id uuid primary key references public.organizations(id) on delete cascade,
  fiscal_year_start_month smallint not null default 7 check (fiscal_year_start_month between 1 and 12),
  default_payment_account uuid,
  date_format text not null default 'DD/MM/YYYY',
  ethiopian_calendar_enabled boolean not null default true,
  tax_settings jsonb not null default '{}'::jsonb,
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now()
);

create table public.contacts (
  id uuid primary key default gen_random_uuid(),
  organization_id uuid not null references public.organizations(id) on delete cascade,
  name text not null,
  kind public.contact_kind not null default 'OTHER',
  is_customer boolean not null default false,
  is_supplier boolean not null default false,
  tin text,
  trade_license text,
  phone text,
  email text,
  address text,
  notes text,
  active boolean not null default true,
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now()
);

create table public.products (
  id uuid primary key default gen_random_uuid(),
  organization_id uuid not null references public.organizations(id) on delete cascade,
  sku text,
  name text not null,
  product_type public.product_type not null default 'PRODUCT',
  unit text not null default 'pcs',
  purchase_price numeric(18,6) not null default 0,
  sales_price numeric(18,6) not null default 0,
  track_inventory boolean not null default true,
  can_purchase boolean not null default true,
  can_sell boolean not null default true,
  can_be_production_input boolean not null default false,
  can_be_production_output boolean not null default false,
  active boolean not null default true,
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now(),
  unique (organization_id, sku)
);

create table public.accounts (
  id uuid primary key default gen_random_uuid(),
  organization_id uuid not null references public.organizations(id) on delete cascade,
  code text,
  name text not null,
  type public.account_type not null,
  active boolean not null default true,
  created_at timestamptz not null default now(),
  unique (organization_id, code)
);

create table public.sales (
  id uuid primary key default gen_random_uuid(),
  organization_id uuid not null references public.organizations(id) on delete cascade,
  invoice_number text not null,
  sale_date date not null,
  customer_id uuid references public.contacts(id) on delete restrict,
  status public.document_status not null default 'DRAFT',
  fiscal_year integer,
  fiscal_month smallint check (fiscal_month between 1 and 12),
  due_date date,
  subtotal numeric(18,2) not null default 0,
  tax_amount numeric(18,2) not null default 0,
  withholding_amount numeric(18,2) not null default 0,
  total_amount numeric(18,2) not null default 0,
  notes text,
  created_by uuid references auth.users(id) on delete set null,
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now(),
  unique (organization_id, invoice_number)
);

create table public.sale_lines (
  id uuid primary key default gen_random_uuid(),
  sale_id uuid not null references public.sales(id) on delete cascade,
  product_id uuid references public.products(id) on delete restrict,
  description text,
  quantity numeric(18,6) not null default 1 check (quantity > 0),
  unit_price numeric(18,6) not null default 0,
  tax_rate numeric(8,4) not null default 0,
  line_total numeric(18,2) not null default 0
);

create table public.purchases (
  id uuid primary key default gen_random_uuid(),
  organization_id uuid not null references public.organizations(id) on delete cascade,
  invoice_number text not null,
  purchase_date date not null,
  supplier_id uuid references public.contacts(id) on delete restrict,
  status public.document_status not null default 'DRAFT',
  fiscal_year integer,
  fiscal_month smallint check (fiscal_month between 1 and 12),
  due_date date,
  subtotal numeric(18,2) not null default 0,
  tax_amount numeric(18,2) not null default 0,
  withholding_amount numeric(18,2) not null default 0,
  total_amount numeric(18,2) not null default 0,
  notes text,
  created_by uuid references auth.users(id) on delete set null,
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now(),
  unique (organization_id, invoice_number)
);

create table public.purchase_lines (
  id uuid primary key default gen_random_uuid(),
  purchase_id uuid not null references public.purchases(id) on delete cascade,
  product_id uuid references public.products(id) on delete restrict,
  description text,
  quantity numeric(18,6) not null default 1 check (quantity > 0),
  unit_price numeric(18,6) not null default 0,
  tax_rate numeric(8,4) not null default 0,
  line_total numeric(18,2) not null default 0
);

create table public.expenses (
  id uuid primary key default gen_random_uuid(),
  organization_id uuid not null references public.organizations(id) on delete cascade,
  expense_date date not null,
  reference text,
  vendor_id uuid references public.contacts(id) on delete set null,
  status public.document_status not null default 'DRAFT',
  category text,
  amount numeric(18,2) not null default 0,
  tax_amount numeric(18,2) not null default 0,
  withholding_amount numeric(18,2) not null default 0,
  notes text,
  created_by uuid references auth.users(id) on delete set null,
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now()
);

create table public.payments (
  id uuid primary key default gen_random_uuid(),
  organization_id uuid not null references public.organizations(id) on delete cascade,
  direction public.payment_direction not null,
  payment_date date not null,
  account_id uuid references public.accounts(id) on delete restrict,
  contact_id uuid references public.contacts(id) on delete set null,
  source_type text not null,
  source_id uuid,
  amount numeric(18,2) not null check (amount > 0),
  reference text,
  notes text,
  created_by uuid references auth.users(id) on delete set null,
  created_at timestamptz not null default now()
);

create table public.inventory_movements (
  id uuid primary key default gen_random_uuid(),
  organization_id uuid not null references public.organizations(id) on delete cascade,
  product_id uuid not null references public.products(id) on delete restrict,
  movement_date date not null,
  movement_type public.inventory_movement_type not null,
  quantity numeric(18,6) not null,
  unit_cost numeric(18,6) not null default 0,
  source_type text,
  source_id uuid,
  notes text,
  created_at timestamptz not null default now()
);

create table public.production_batches (
  id uuid primary key default gen_random_uuid(),
  organization_id uuid not null references public.organizations(id) on delete cascade,
  batch_number text not null,
  production_date date not null,
  status public.document_status not null default 'DRAFT',
  notes text,
  created_by uuid references auth.users(id) on delete set null,
  created_at timestamptz not null default now(),
  unique (organization_id, batch_number)
);

create table public.production_lines (
  id uuid primary key default gen_random_uuid(),
  batch_id uuid not null references public.production_batches(id) on delete cascade,
  product_id uuid not null references public.products(id) on delete restrict,
  line_type text not null check (line_type in ('INPUT','OUTPUT')),
  quantity numeric(18,6) not null check (quantity > 0),
  unit_cost numeric(18,6) not null default 0,
  notes text
);

create table public.loans (
  id uuid primary key default gen_random_uuid(),
  organization_id uuid not null references public.organizations(id) on delete cascade,
  lender_id uuid references public.contacts(id) on delete set null,
  loan_number text not null,
  start_date date not null,
  principal_amount numeric(18,2) not null check (principal_amount >= 0),
  interest_rate numeric(10,6) not null default 0,
  status text not null default 'ACTIVE' check (status in ('DRAFT','ACTIVE','CLOSED','VOIDED')),
  notes text,
  created_by uuid references auth.users(id) on delete set null,
  created_at timestamptz not null default now(),
  unique (organization_id, loan_number)
);

create table public.loan_payments (
  id uuid primary key default gen_random_uuid(),
  organization_id uuid not null references public.organizations(id) on delete cascade,
  loan_id uuid not null references public.loans(id) on delete cascade,
  payment_date date not null,
  principal_amount numeric(18,2) not null default 0,
  interest_amount numeric(18,2) not null default 0,
  total_amount numeric(18,2) generated always as (principal_amount + interest_amount) stored,
  reference text,
  notes text,
  created_by uuid references auth.users(id) on delete set null,
  created_at timestamptz not null default now(),
  check (principal_amount >= 0 and interest_amount >= 0 and (principal_amount + interest_amount) > 0)
);

create table public.withholding_received (
  id uuid primary key default gen_random_uuid(),
  organization_id uuid not null references public.organizations(id) on delete cascade,
  contact_id uuid references public.contacts(id) on delete set null,
  receipt_date date not null,
  agent_name text,
  agent_tin text,
  gross_amount numeric(18,2) not null default 0,
  rate numeric(8,4) not null default 0,
  withheld_amount numeric(18,2) not null default 0,
  net_amount numeric(18,2) not null default 0,
  reference text,
  certificate_number text,
  notes text,
  created_at timestamptz not null default now()
);

create table public.withholding_collected (
  id uuid primary key default gen_random_uuid(),
  organization_id uuid not null references public.organizations(id) on delete cascade,
  contact_id uuid references public.contacts(id) on delete set null,
  collection_date date not null,
  gross_amount numeric(18,2) not null default 0,
  rate numeric(8,4) not null default 0,
  withheld_amount numeric(18,2) not null default 0,
  reference text,
  notes text,
  created_at timestamptz not null default now()
);

create table public.withholding_remittances (
  id uuid primary key default gen_random_uuid(),
  organization_id uuid not null references public.organizations(id) on delete cascade,
  remittance_date date not null,
  amount numeric(18,2) not null check (amount > 0),
  reference text,
  notes text,
  created_at timestamptz not null default now()
);

create table public.financial_transactions (
  id uuid primary key default gen_random_uuid(),
  organization_id uuid not null references public.organizations(id) on delete cascade,
  transaction_date date not null,
  reference text,
  description text,
  source_type text,
  source_id uuid,
  posted boolean not null default false,
  created_by uuid references auth.users(id) on delete set null,
  created_at timestamptz not null default now()
);

create table public.financial_transaction_lines (
  id uuid primary key default gen_random_uuid(),
  transaction_id uuid not null references public.financial_transactions(id) on delete cascade,
  account_id uuid not null references public.accounts(id) on delete restrict,
  debit numeric(18,2) not null default 0,
  credit numeric(18,2) not null default 0,
  description text,
  check ((debit = 0 and credit > 0) or (credit = 0 and debit > 0))
);

create table public.audit_logs (
  id uuid primary key default gen_random_uuid(),
  organization_id uuid not null references public.organizations(id) on delete cascade,
  actor_user_id uuid references auth.users(id) on delete set null,
  action text not null,
  entity_type text,
  entity_id uuid,
  before_data jsonb,
  after_data jsonb,
  metadata jsonb not null default '{}'::jsonb,
  created_at timestamptz not null default now()
);

create index idx_members_user on public.organization_members(user_id);
create index idx_contacts_org on public.contacts(organization_id);
create index idx_products_org on public.products(organization_id);
create index idx_sales_org_date on public.sales(organization_id, sale_date);
create index idx_sales_org_customer on public.sales(organization_id, customer_id);
create index idx_sales_org_status on public.sales(organization_id, status);
create index idx_purchases_org_date on public.purchases(organization_id, purchase_date);
create index idx_purchases_org_supplier on public.purchases(organization_id, supplier_id);
create index idx_purchases_org_status on public.purchases(organization_id, status);
create index idx_expenses_org_date on public.expenses(organization_id, expense_date);
create index idx_payments_org_date on public.payments(organization_id, payment_date);
create index idx_payments_source on public.payments(source_type, source_id);
create index idx_inventory_org_product_date on public.inventory_movements(organization_id, product_id, movement_date);
create index idx_production_org_date on public.production_batches(organization_id, production_date);
create index idx_loans_org on public.loans(organization_id);
create index idx_withholding_received_org_date on public.withholding_received(organization_id, receipt_date);
create index idx_withholding_collected_org_date on public.withholding_collected(organization_id, collection_date);
create index idx_audit_org_created on public.audit_logs(organization_id, created_at desc);
