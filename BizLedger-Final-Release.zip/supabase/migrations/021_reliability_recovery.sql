-- BizLedger Phase 18: reliability, idempotency and application error reporting

create table if not exists public.financial_operation_keys (
  id uuid primary key default gen_random_uuid(),
  organization_id uuid not null references public.organizations(id) on delete cascade,
  operation_key text not null,
  operation_type text not null,
  result_id uuid,
  created_by uuid references auth.users(id),
  created_at timestamptz not null default now(),
  unique (organization_id, operation_key)
);
create index if not exists idx_financial_operation_keys_org_created
  on public.financial_operation_keys(organization_id, created_at desc);
alter table public.financial_operation_keys enable row level security;
drop policy if exists financial_operation_keys_read on public.financial_operation_keys;
create policy financial_operation_keys_read on public.financial_operation_keys for select
using (public.is_org_member(organization_id));

create table if not exists public.application_error_events (
  id uuid primary key default gen_random_uuid(),
  organization_id uuid references public.organizations(id) on delete set null,
  user_id uuid references auth.users(id) on delete set null,
  error_code text,
  message text not null,
  route text,
  operation text,
  metadata jsonb not null default '{}'::jsonb,
  created_at timestamptz not null default now()
);
create index if not exists idx_application_error_events_org_created
  on public.application_error_events(organization_id, created_at desc);
alter table public.application_error_events enable row level security;
drop policy if exists application_error_events_read on public.application_error_events;
create policy application_error_events_read on public.application_error_events for select
using (organization_id is not null and public.is_org_member(organization_id) and public.has_permission(organization_id,'audit.view'));

create or replace function public.report_application_error(
  p_org uuid,
  p_error_code text,
  p_message text,
  p_route text default null,
  p_operation text default null,
  p_metadata jsonb default '{}'::jsonb
) returns uuid
language plpgsql security definer set search_path=public as $$
declare v_id uuid;
begin
  if p_org is not null and not public.is_org_member(p_org) then raise exception 'Not authorized'; end if;
  insert into public.application_error_events(organization_id,user_id,error_code,message,route,operation,metadata)
  values(p_org,auth.uid(),left(p_error_code,120),left(p_message,2000),left(p_route,500),left(p_operation,200),coalesce(p_metadata,'{}'::jsonb))
  returning id into v_id;
  return v_id;
end; $$;
revoke all on function public.report_application_error(uuid,text,text,text,text,jsonb) from public;
grant execute on function public.report_application_error(uuid,text,text,text,text,jsonb) to authenticated;

create or replace function public.claim_financial_operation(
  p_org uuid,
  p_operation_key text,
  p_operation_type text
) returns uuid
language plpgsql security definer set search_path=public as $$
declare v_id uuid;
begin
  if not public.is_org_member(p_org) then raise exception 'Not authorized'; end if;
  if p_operation_key is null or length(trim(p_operation_key)) < 8 then raise exception 'A valid idempotency key is required'; end if;
  insert into public.financial_operation_keys(organization_id,operation_key,operation_type,created_by)
  values(p_org,trim(p_operation_key),trim(p_operation_type),auth.uid())
  on conflict (organization_id,operation_key) do nothing;
  select result_id into v_id from public.financial_operation_keys
    where organization_id=p_org and operation_key=trim(p_operation_key);
  return v_id;
end; $$;
revoke all on function public.claim_financial_operation(uuid,text,text) from public;
grant execute on function public.claim_financial_operation(uuid,text,text) to authenticated;

create or replace function public.complete_financial_operation(
  p_org uuid, p_operation_key text, p_result_id uuid
) returns void
language plpgsql security definer set search_path=public as $$
begin
  if not public.is_org_member(p_org) then raise exception 'Not authorized'; end if;
  update public.financial_operation_keys
    set result_id=p_result_id
    where organization_id=p_org and operation_key=trim(p_operation_key) and result_id is null;
end; $$;
revoke all on function public.complete_financial_operation(uuid,text,uuid) from public;
grant execute on function public.complete_financial_operation(uuid,text,uuid) to authenticated;

create or replace function public.post_sale_idempotent(p_sale_id uuid,p_operation_key text)
returns uuid language plpgsql security definer set search_path=public as $$
declare v_org uuid; v_existing uuid; v_result uuid;
begin
  select organization_id into v_org from public.sales where id=p_sale_id;
  if v_org is null or not public.is_org_member(v_org) then raise exception 'Sale not found or unauthorized'; end if;
  select result_id into v_existing from public.financial_operation_keys where organization_id=v_org and operation_key=trim(p_operation_key);
  if v_existing is not null then return v_existing; end if;
  perform public.claim_financial_operation(v_org,p_operation_key,'POST_SALE');
  select result_id into v_existing from public.financial_operation_keys where organization_id=v_org and operation_key=trim(p_operation_key);
  if v_existing is not null then return v_existing; end if;
  v_result:=public.post_sale(p_sale_id);
  perform public.complete_financial_operation(v_org,p_operation_key,v_result);
  return v_result;
end; $$;
grant execute on function public.post_sale_idempotent(uuid,text) to authenticated;

create or replace function public.post_purchase_idempotent(p_purchase_id uuid,p_operation_key text)
returns uuid language plpgsql security definer set search_path=public as $$
declare v_org uuid; v_existing uuid; v_result uuid;
begin
  select organization_id into v_org from public.purchases where id=p_purchase_id;
  if v_org is null or not public.is_org_member(v_org) then raise exception 'Purchase not found or unauthorized'; end if;
  select result_id into v_existing from public.financial_operation_keys where organization_id=v_org and operation_key=trim(p_operation_key);
  if v_existing is not null then return v_existing; end if;
  perform public.claim_financial_operation(v_org,p_operation_key,'POST_PURCHASE');
  select result_id into v_existing from public.financial_operation_keys where organization_id=v_org and operation_key=trim(p_operation_key);
  if v_existing is not null then return v_existing; end if;
  v_result:=public.post_purchase(p_purchase_id);
  perform public.complete_financial_operation(v_org,p_operation_key,v_result);
  return v_result;
end; $$;
grant execute on function public.post_purchase_idempotent(uuid,text) to authenticated;

create or replace function public.post_expense_idempotent(p_expense_id uuid,p_operation_key text)
returns uuid language plpgsql security definer set search_path=public as $$
declare v_org uuid; v_existing uuid; v_result uuid;
begin
  select organization_id into v_org from public.expenses where id=p_expense_id;
  if v_org is null or not public.is_org_member(v_org) then raise exception 'Expense not found or unauthorized'; end if;
  select result_id into v_existing from public.financial_operation_keys where organization_id=v_org and operation_key=trim(p_operation_key);
  if v_existing is not null then return v_existing; end if;
  perform public.claim_financial_operation(v_org,p_operation_key,'POST_EXPENSE');
  select result_id into v_existing from public.financial_operation_keys where organization_id=v_org and operation_key=trim(p_operation_key);
  if v_existing is not null then return v_existing; end if;
  v_result:=public.post_expense(p_expense_id);
  perform public.complete_financial_operation(v_org,p_operation_key,v_result);
  return v_result;
end; $$;
grant execute on function public.post_expense_idempotent(uuid,text) to authenticated;

create or replace function public.record_payment_idempotent(
  p_org uuid,p_direction public.payment_direction,p_date date,p_account_id uuid,p_contact_id uuid,
  p_source_type text,p_source_id uuid,p_amount numeric,p_operation_key text,p_reference text default null,p_notes text default null
) returns uuid language plpgsql security definer set search_path=public as $$
declare v_existing uuid; v_result uuid;
begin
  if not public.is_org_member(p_org) then raise exception 'Not authorized'; end if;
  select result_id into v_existing from public.financial_operation_keys where organization_id=p_org and operation_key=trim(p_operation_key);
  if v_existing is not null then return v_existing; end if;
  perform public.claim_financial_operation(p_org,p_operation_key,'RECORD_PAYMENT');
  select result_id into v_existing from public.financial_operation_keys where organization_id=p_org and operation_key=trim(p_operation_key);
  if v_existing is not null then return v_existing; end if;
  v_result:=public.record_payment(p_org,p_direction,p_date,p_account_id,p_contact_id,p_source_type,p_source_id,p_amount,p_reference,p_notes);
  perform public.complete_financial_operation(p_org,p_operation_key,v_result);
  return v_result;
end; $$;
grant execute on function public.record_payment_idempotent(uuid,public.payment_direction,date,uuid,uuid,text,uuid,numeric,text,text,text) to authenticated;

create or replace function public.record_loan_payment_idempotent(
  p_loan_id uuid,p_account_id uuid,p_date date,p_principal numeric,p_interest numeric,p_operation_key text,p_reference text default null,p_notes text default null
) returns uuid language plpgsql security definer set search_path=public as $$
declare v_org uuid; v_existing uuid; v_result uuid;
begin
  select organization_id into v_org from public.loans where id=p_loan_id;
  if v_org is null or not public.is_org_member(v_org) then raise exception 'Loan not found or unauthorized'; end if;
  select result_id into v_existing from public.financial_operation_keys where organization_id=v_org and operation_key=trim(p_operation_key);
  if v_existing is not null then return v_existing; end if;
  perform public.claim_financial_operation(v_org,p_operation_key,'RECORD_LOAN_PAYMENT');
  select result_id into v_existing from public.financial_operation_keys where organization_id=v_org and operation_key=trim(p_operation_key);
  if v_existing is not null then return v_existing; end if;
  v_result:=public.record_loan_payment(p_loan_id,p_account_id,p_date,p_principal,p_interest,p_reference,p_notes);
  perform public.complete_financial_operation(v_org,p_operation_key,v_result);
  return v_result;
end; $$;
grant execute on function public.record_loan_payment_idempotent(uuid,uuid,date,numeric,numeric,text,text,text) to authenticated;

create or replace function public.record_withholding_remittance_idempotent(
  p_org uuid,p_date date,p_amount numeric,p_account_id uuid,p_operation_key text,p_reference text default null,p_notes text default null
) returns uuid language plpgsql security definer set search_path=public as $$
declare v_existing uuid; v_result uuid;
begin
  if not public.is_org_member(p_org) then raise exception 'Not authorized'; end if;
  select result_id into v_existing from public.financial_operation_keys where organization_id=p_org and operation_key=trim(p_operation_key);
  if v_existing is not null then return v_existing; end if;
  perform public.claim_financial_operation(p_org,p_operation_key,'WITHHOLDING_REMITTANCE');
  select result_id into v_existing from public.financial_operation_keys where organization_id=p_org and operation_key=trim(p_operation_key);
  if v_existing is not null then return v_existing; end if;
  v_result:=public.record_withholding_remittance(p_org,p_date,p_amount,p_account_id,p_reference,p_notes);
  perform public.complete_financial_operation(p_org,p_operation_key,v_result);
  return v_result;
end; $$;
grant execute on function public.record_withholding_remittance_idempotent(uuid,date,numeric,uuid,text,text,text) to authenticated;

create or replace function public.get_reliability_report(p_org uuid)
returns jsonb language plpgsql security definer set search_path=public as $$
declare v_recent_errors bigint; v_ops bigint; v_completed bigint; v_stale bigint;
begin
  if not public.is_org_member(p_org) then raise exception 'Not authorized'; end if;
  select count(*) into v_recent_errors from public.application_error_events where organization_id=p_org and created_at >= now()-interval '24 hours';
  select count(*) into v_ops from public.financial_operation_keys where organization_id=p_org;
  select count(*) into v_completed from public.financial_operation_keys where organization_id=p_org and result_id is not null;
  select count(*) into v_stale from public.financial_operation_keys where organization_id=p_org and result_id is null and created_at < now()-interval '15 minutes';
  return jsonb_build_object(
    'generated_at',now(),
    'recent_errors_24h',v_recent_errors,
    'idempotent_operations',v_ops,
    'completed_operations',v_completed,
    'incomplete_operations',v_ops-v_completed,
    'stale_operations',v_stale,
    'ready',v_stale=0
  );
end; $$;
grant execute on function public.get_reliability_report(uuid) to authenticated;
