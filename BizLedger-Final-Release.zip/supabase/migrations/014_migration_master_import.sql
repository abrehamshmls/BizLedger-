-- BizLedger Phase 10: controlled master-data import
-- Imports only contacts and products from a VALIDATED migration batch.
-- Transactional and auditable; documents/payments remain for the next controlled stage.

create table if not exists public.migration_mappings (
  id uuid primary key default gen_random_uuid(),
  batch_id uuid not null references public.migration_batches(id) on delete cascade,
  module text not null check (module in ('contacts','products')),
  migration_row_id uuid not null references public.migration_rows(id) on delete cascade,
  target_id uuid not null,
  match_type text not null check (match_type in ('CREATED','EXACT_MATCH','SKU_MATCH','NAME_TIN_MATCH')),
  created_at timestamptz not null default now(),
  unique(batch_id,migration_row_id)
);

create index if not exists idx_migration_mappings_batch_module
  on public.migration_mappings(batch_id,module);

alter table public.migration_mappings enable row level security;
drop policy if exists migration_mappings_admin on public.migration_mappings;
create policy migration_mappings_admin on public.migration_mappings for all
using (exists(select 1 from public.migration_batches b where b.id=batch_id and public.has_permission(b.organization_id,'members.manage')))
with check (exists(select 1 from public.migration_batches b where b.id=batch_id and public.has_permission(b.organization_id,'members.manage')));

create or replace function public.import_migration_master_data(p_batch uuid, p_confirm boolean default false)
returns jsonb
language plpgsql security definer set search_path=public as $$
declare
  b public.migration_batches%rowtype;
  r record;
  v_id uuid;
  v_name text;
  v_sku text;
  v_tin text;
  v_match text;
  v_contacts integer := 0;
  v_products integer := 0;
  v_created integer := 0;
  v_matched integer := 0;
begin
  select * into b from public.migration_batches where id=p_batch for update;
  if not found then raise exception 'Migration batch not found'; end if;
  if not public.has_permission(b.organization_id,'members.manage') then raise exception 'Not authorized'; end if;
  if b.status <> 'VALIDATED' then raise exception 'Only VALIDATED migration batches can be imported'; end if;
  if not p_confirm then
    return jsonb_build_object('ready',true,'message','Explicit confirmation is required to import master data.');
  end if;

  -- Contacts: prefer exact name+TIN match, otherwise create.
  for r in select * from public.migration_rows where batch_id=p_batch and module='contacts' and status='READY' order by row_number loop
    v_name := nullif(trim(coalesce(r.raw_data->>'name',r.raw_data->>'contactName','')),'');
    v_tin := nullif(trim(coalesce(r.raw_data->>'tin',r.raw_data->>'TIN','')),'');
    if v_name is null then continue; end if;
    select c.id into v_id from public.contacts c
      where c.organization_id=b.organization_id
        and lower(trim(c.name))=lower(v_name)
        and coalesce(nullif(trim(c.tin),''),'')=coalesce(v_tin,'')
      order by c.created_at limit 1;
    if v_id is not null then v_match:='NAME_TIN_MATCH'; v_matched:=v_matched+1;
    else
      insert into public.contacts(organization_id,name,kind,is_customer,is_supplier,tin,trade_license,phone,email,address,notes)
      values(
        b.organization_id,v_name,
        case when coalesce((r.raw_data->>'isCustomer')::boolean,false) and coalesce((r.raw_data->>'isSupplier')::boolean,false) then 'OTHER'
             when coalesce((r.raw_data->>'isCustomer')::boolean,false) then 'CUSTOMER'
             when coalesce((r.raw_data->>'isSupplier')::boolean,false) then 'SUPPLIER' else 'OTHER' end,
        coalesce((r.raw_data->>'isCustomer')::boolean,false),
        coalesce((r.raw_data->>'isSupplier')::boolean,false),
        v_tin,
        nullif(trim(coalesce(r.raw_data->>'tradeLicense',r.raw_data->>'trade_license','')),''),
        nullif(trim(coalesce(r.raw_data->>'phone','')),''),
        nullif(trim(coalesce(r.raw_data->>'email','')),''),
        nullif(trim(coalesce(r.raw_data->>'address','')),''),
        nullif(trim(coalesce(r.raw_data->>'notes','')),'')
      ) returning id into v_id;
      v_match:='CREATED'; v_created:=v_created+1;
    end if;
    insert into public.migration_mappings(batch_id,module,migration_row_id,target_id,match_type)
    values(p_batch,'contacts',r.id,v_id,v_match) on conflict (batch_id,migration_row_id) do nothing;
    v_contacts:=v_contacts+1;
  end loop;

  -- Products: prefer SKU match, otherwise exact name match, otherwise create.
  for r in select * from public.migration_rows where batch_id=p_batch and module='products' and status='READY' order by row_number loop
    v_name := nullif(trim(coalesce(r.raw_data->>'name',r.raw_data->>'productName','')),'');
    if v_name is null then continue; end if;
    v_sku := nullif(trim(coalesce(r.raw_data->>'sku',r.raw_data->>'code','')),'');
    v_id := null;
    if v_sku is not null then
      select p.id into v_id from public.products p where p.organization_id=b.organization_id and p.sku=v_sku limit 1;
      if v_id is not null then v_match:='SKU_MATCH'; v_matched:=v_matched+1; end if;
    end if;
    if v_id is null then
      select p.id into v_id from public.products p where p.organization_id=b.organization_id and lower(trim(p.name))=lower(v_name) order by p.created_at limit 1;
      if v_id is not null then v_match:='EXACT_MATCH'; v_matched:=v_matched+1; end if;
    end if;
    if v_id is null then
      insert into public.products(organization_id,sku,name,product_type,unit,purchase_price,sales_price,track_inventory,can_purchase,can_sell)
      values(
        b.organization_id,v_sku,v_name,
        case upper(coalesce(r.raw_data->>'product_type','PRODUCT')) when 'SERVICE' then 'SERVICE' when 'RAW_MATERIAL' then 'RAW_MATERIAL' when 'FINISHED_GOOD' then 'FINISHED_GOOD' else 'PRODUCT' end,
        coalesce(nullif(trim(r.raw_data->>'unit'),''),'pcs'),
        case when coalesce(r.raw_data->>'purchase_price','') ~ '^-?[0-9]+(\.[0-9]+)?$' then greatest((r.raw_data->>'purchase_price')::numeric,0) else 0 end,
        case when coalesce(r.raw_data->>'sales_price','') ~ '^-?[0-9]+(\.[0-9]+)?$' then greatest((r.raw_data->>'sales_price')::numeric,0) else 0 end,
        coalesce((r.raw_data->>'track_inventory')::boolean,true),
        coalesce((r.raw_data->>'can_purchase')::boolean,true),
        coalesce((r.raw_data->>'can_sell')::boolean,true)
      ) returning id into v_id;
      v_match:='CREATED'; v_created:=v_created+1;
    end if;
    insert into public.migration_mappings(batch_id,module,migration_row_id,target_id,match_type)
    values(p_batch,'products',r.id,v_id,v_match) on conflict (batch_id,migration_row_id) do nothing;
    v_products:=v_products+1;
  end loop;

  update public.migration_batches set summary = summary || jsonb_build_object('master_data_imported_at',now(),'master_contacts',v_contacts,'master_products',v_products), imported_at=now() where id=p_batch;
  insert into public.audit_logs(organization_id,actor_user_id,action,entity_type,entity_id,metadata)
  values(b.organization_id,auth.uid(),'MIGRATION_MASTER_DATA_IMPORTED','migration_batch',p_batch,jsonb_build_object('contacts',v_contacts,'products',v_products,'created',v_created,'matched',v_matched));

  return jsonb_build_object('ready',false,'contacts',v_contacts,'products',v_products,'created',v_created,'matched',v_matched);
end;
$$;

revoke all on function public.import_migration_master_data(uuid,boolean) from public;
grant execute on function public.import_migration_master_data(uuid,boolean) to authenticated;
