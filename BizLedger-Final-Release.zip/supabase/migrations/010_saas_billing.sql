-- BizLedger Phase 5: SaaS subscription foundation
create type public.subscription_status as enum ('TRIALING','ACTIVE','PAST_DUE','CANCELED','EXPIRED');
create type public.plan_code as enum ('FREE','STARTER','BUSINESS','PRO');

create table public.subscription_plans (
  id uuid primary key default gen_random_uuid(),
  code public.plan_code not null unique,
  name text not null,
  description text,
  monthly_price numeric(18,2) not null default 0 check (monthly_price >= 0),
  yearly_price numeric(18,2) not null default 0 check (yearly_price >= 0),
  max_members integer not null default 1 check (max_members > 0),
  max_products integer not null default 100 check (max_products > 0),
  max_monthly_invoices integer not null default 100 check (max_monthly_invoices > 0),
  features jsonb not null default '{}'::jsonb,
  active boolean not null default true,
  created_at timestamptz not null default now()
);

create table public.organization_subscriptions (
  id uuid primary key default gen_random_uuid(),
  organization_id uuid not null unique references public.organizations(id) on delete cascade,
  plan_id uuid not null references public.subscription_plans(id),
  status public.subscription_status not null default 'TRIALING',
  trial_ends_at timestamptz,
  current_period_start timestamptz,
  current_period_end timestamptz,
  provider text,
  provider_customer_id text,
  provider_subscription_id text,
  cancel_at_period_end boolean not null default false,
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now()
);

create table public.subscription_events (
  id uuid primary key default gen_random_uuid(),
  organization_id uuid not null references public.organizations(id) on delete cascade,
  subscription_id uuid references public.organization_subscriptions(id) on delete set null,
  event_type text not null,
  provider text,
  provider_event_id text,
  payload jsonb not null default '{}'::jsonb,
  created_at timestamptz not null default now(),
  unique(provider, provider_event_id)
);

insert into public.subscription_plans (code,name,description,monthly_price,yearly_price,max_members,max_products,max_monthly_invoices,features)
values
('FREE','Free','For very small businesses getting started',0,0,1,100,100,'{"reports":true,"documents":true,"ethiopian_calendar":true}'::jsonb),
('STARTER','Starter','Core business management for growing businesses',499,4990,3,500,500,'{"reports":true,"documents":true,"ethiopian_calendar":true,"inventory":true}'::jsonb),
('BUSINESS','Business','Full operational accounting and team workflows',999,9990,10,2000,2000,'{"reports":true,"documents":true,"ethiopian_calendar":true,"inventory":true,"production":true,"loans":true,"withholding":true}'::jsonb),
('PRO','Pro','Larger teams and higher operating limits',1999,19990,25,10000,10000,'{"reports":true,"documents":true,"ethiopian_calendar":true,"inventory":true,"production":true,"loans":true,"withholding":true,"advanced_permissions":true}'::jsonb)
on conflict (code) do nothing;

create or replace function public.ensure_free_subscription(p_org uuid)
returns uuid
language plpgsql security invoker as $$
declare v_sub uuid; v_plan uuid;
begin
  if not public.is_org_member(p_org) then raise exception 'Not authorized'; end if;
  select id into v_plan from public.subscription_plans where code='FREE' and active=true;
  insert into public.organization_subscriptions(organization_id,plan_id,status,trial_ends_at,current_period_start,current_period_end)
  values(p_org,v_plan,'TRIALING',now()+interval '14 days',now(),now()+interval '14 days')
  on conflict (organization_id) do nothing
  returning id into v_sub;
  if v_sub is null then select id into v_sub from public.organization_subscriptions where organization_id=p_org; end if;
  return v_sub;
end;
$$;

create or replace view public.v_current_subscription as
select os.organization_id, os.id subscription_id, sp.code plan_code, sp.name plan_name,
       sp.description, sp.monthly_price, sp.yearly_price, sp.max_members, sp.max_products,
       sp.max_monthly_invoices, sp.features, os.status, os.trial_ends_at,
       os.current_period_start, os.current_period_end, os.cancel_at_period_end
from public.organization_subscriptions os
join public.subscription_plans sp on sp.id=os.plan_id;

alter table public.subscription_plans enable row level security;
alter table public.organization_subscriptions enable row level security;
alter table public.subscription_events enable row level security;

create policy "plans readable to authenticated users" on public.subscription_plans for select to authenticated using (active=true);
create policy "members read own subscription" on public.organization_subscriptions for select to authenticated using (public.is_org_member(organization_id));
create policy "members read own subscription events" on public.subscription_events for select to authenticated using (public.is_org_member(organization_id));

create index idx_subscription_events_org_created on public.subscription_events(organization_id,created_at desc);

-- Seed every existing organization with the Free plan without changing accounting data.
insert into public.organization_subscriptions(organization_id,plan_id,status,trial_ends_at,current_period_start,current_period_end)
select o.id,p.id,'TRIALING',o.created_at+interval '14 days',o.created_at,o.created_at+interval '14 days'
from public.organizations o cross join public.subscription_plans p
where p.code='FREE'
on conflict (organization_id) do nothing;
