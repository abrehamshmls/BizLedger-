-- BizLedger Phase 4: reporting foundation
create or replace function public.report_account_balances(
  p_org uuid,
  p_start date,
  p_end date
)
returns table(
  account_id uuid,
  code text,
  name text,
  type public.account_type,
  debits numeric(18,2),
  credits numeric(18,2),
  balance numeric(18,2)
)
language sql
stable
security invoker
as $$
  select a.id,a.code,a.name,a.type,
    coalesce(sum(l.debit),0)::numeric(18,2),
    coalesce(sum(l.credit),0)::numeric(18,2),
    case when a.type in ('LIABILITY','EQUITY','INCOME','PAYABLE')
      then coalesce(sum(l.credit-l.debit),0)
      else coalesce(sum(l.debit-l.credit),0)
    end::numeric(18,2)
  from public.accounts a
  left join public.financial_transaction_lines l on l.account_id=a.id
  left join public.financial_transactions t on t.id=l.transaction_id
    and t.organization_id=p_org and t.posted=true
    and t.transaction_date between p_start and p_end
  where a.organization_id=p_org and public.is_org_member(p_org)
  group by a.id,a.code,a.name,a.type
  order by a.code nulls last,a.name;
$$;

create or replace function public.report_sales_summary(p_org uuid,p_start date,p_end date)
returns table(sales_count bigint, subtotal numeric(18,2), tax numeric(18,2), withholding numeric(18,2), total numeric(18,2))
language sql stable security invoker as $$
 select count(*)::bigint,
   coalesce(sum(subtotal),0)::numeric(18,2),
   coalesce(sum(tax_amount),0)::numeric(18,2),
   coalesce(sum(withholding_amount),0)::numeric(18,2),
   coalesce(sum(total_amount),0)::numeric(18,2)
 from public.sales
 where organization_id=p_org and public.is_org_member(p_org)
   and sale_date between p_start and p_end
   and status in ('POSTED','PARTIALLY_PAID','PAID');
$$;

create or replace function public.report_expense_summary(p_org uuid,p_start date,p_end date)
returns table(expense_count bigint, amount numeric(18,2), tax numeric(18,2), withholding numeric(18,2), total numeric(18,2))
language sql stable security invoker as $$
 select count(*)::bigint,
   coalesce(sum(amount),0)::numeric(18,2),
   coalesce(sum(tax_amount),0)::numeric(18,2),
   coalesce(sum(withholding_amount),0)::numeric(18,2),
   coalesce(sum(amount+tax_amount),0)::numeric(18,2)
 from public.expenses
 where organization_id=p_org and public.is_org_member(p_org)
   and expense_date between p_start and p_end and status in ('POSTED','PAID');
$$;
