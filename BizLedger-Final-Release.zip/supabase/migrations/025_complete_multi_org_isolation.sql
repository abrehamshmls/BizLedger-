-- BizLedger Phase 23: complete multi-organization isolation support
-- UI context is explicit; RLS remains the security boundary.

create or replace function public.assert_active_organization(p_org uuid)
returns void
language plpgsql
stable
security definer
set search_path = public
as $$
begin
  if p_org is null or not public.user_has_active_membership(p_org) then
    raise exception 'Organization access denied';
  end if;
end;
$$;

revoke all on function public.assert_active_organization(uuid) from public;
grant execute on function public.assert_active_organization(uuid) to authenticated;

-- Diagnostic helper used by the application to verify that the selected
-- organization is one of the current user's active memberships.
create or replace function public.organization_context_status(p_org uuid)
returns table(allowed boolean, organization_id uuid, organization_name text)
language sql
stable
security definer
set search_path = public
as $$
  select
    public.user_has_active_membership(p_org),
    o.id,
    o.name
  from public.organizations o
  where o.id = p_org;
$$;

revoke all on function public.organization_context_status(uuid) from public;
grant execute on function public.organization_context_status(uuid) to authenticated;
