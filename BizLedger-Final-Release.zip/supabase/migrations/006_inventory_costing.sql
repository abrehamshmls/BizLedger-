-- BizLedger Phase 2B: inventory, average-cost valuation and COGS
-- Inventory movements are the source of stock quantity and cost. Outbound movements
-- are always assigned the weighted-average cost immediately before the movement.

create index if not exists idx_inventory_org_product_date_id
  on public.inventory_movements(organization_id, product_id, movement_date, id);

create or replace function public.inventory_quantity(p_org uuid, p_product uuid, p_as_of date default null)
returns numeric(18,6)
language sql stable security definer set search_path = public
as $$
  select coalesce(sum(quantity),0)::numeric(18,6)
  from public.inventory_movements
  where organization_id = p_org
    and product_id = p_product
    and (p_as_of is null or movement_date <= p_as_of);
$$;

create or replace function public.inventory_average_cost(p_org uuid, p_product uuid, p_as_of date default null)
returns numeric(18,6)
language plpgsql stable security definer set search_path = public
as $$
declare
  v_qty numeric(18,6);
  v_value numeric(24,6);
begin
  select coalesce(sum(quantity),0), coalesce(sum(quantity * unit_cost),0)
    into v_qty, v_value
  from public.inventory_movements
  where organization_id = p_org
    and product_id = p_product
    and (p_as_of is null or movement_date <= p_as_of);

  if v_qty <= 0 then
    return 0;
  end if;
  return round((v_value / v_qty)::numeric, 6);
end;
$$;

create or replace function public.inventory_value(p_org uuid, p_as_of date default null)
returns numeric(18,2)
language sql stable security definer set search_path = public
as $$
  select coalesce(sum(x.qty * x.avg_cost),0)::numeric(18,2)
  from (
    select p.id,
           public.inventory_quantity(p_org,p.id,p_as_of) qty,
           public.inventory_average_cost(p_org,p.id,p_as_of) avg_cost
    from public.products p
    where p.organization_id = p_org and p.track_inventory = true and p.active = true
  ) x
  where x.qty <> 0;
$$;

create or replace function public.add_inventory_movement(
  p_org uuid,
  p_product uuid,
  p_date date,
  p_type public.inventory_movement_type,
  p_quantity numeric,
  p_unit_cost numeric default 0,
  p_source_type text default null,
  p_source_id uuid default null,
  p_notes text default null
)
returns uuid
language plpgsql security definer set search_path = public
as $$
declare
  v_id uuid;
  v_available numeric(18,6);
  v_cost numeric(18,6);
begin
  if not public.is_org_member(p_org) then raise exception 'Not authorized'; end if;
  if not exists(select 1 from public.products where id=p_product and organization_id=p_org and active=true) then
    raise exception 'Invalid product';
  end if;
  if p_quantity = 0 then raise exception 'Inventory quantity cannot be zero'; end if;

  if p_quantity < 0 then
    v_available := public.inventory_quantity(p_org,p_product,p_date);
    if v_available + p_quantity < 0 then
      raise exception 'Insufficient stock for product %: available %, requested %', p_product, v_available, abs(p_quantity);
    end if;
    v_cost := public.inventory_average_cost(p_org,p_product,p_date);
    insert into public.inventory_movements
      (organization_id,product_id,movement_date,movement_type,quantity,unit_cost,source_type,source_id,notes)
    values
      (p_org,p_product,p_date,p_type,p_quantity,v_cost,p_source_type,p_source_id,p_notes)
    returning id into v_id;
  else
    if p_unit_cost < 0 then raise exception 'Unit cost cannot be negative'; end if;
    insert into public.inventory_movements
      (organization_id,product_id,movement_date,movement_type,quantity,unit_cost,source_type,source_id,notes)
    values
      (p_org,p_product,p_date,p_type,p_quantity,p_unit_cost,p_source_type,p_source_id,p_notes)
    returning id into v_id;
  end if;
  return v_id;
end;
$$;

create or replace function public.post_purchase(p_purchase_id uuid)
returns uuid
language plpgsql security definer set search_path = public
as $$
declare
  p public.purchases%rowtype;
  l record;
  v_inventory uuid; v_tax uuid; v_ap uuid; v_wht uuid; v_expense uuid; v_tx uuid;
  v_inventory_subtotal numeric(18,2) := 0;
  v_expense_subtotal numeric(18,2) := 0;
  v_net_ap numeric(18,2);
  v_lines jsonb := '[]'::jsonb;
begin
  select * into p from public.purchases where id=p_purchase_id for update;
  if not found then raise exception 'Purchase not found'; end if;
  if not public.is_org_member(p.organization_id) then raise exception 'Not authorized'; end if;
  if p.status <> 'DRAFT' then raise exception 'Only draft purchases can be posted'; end if;

  v_inventory := public.account_id_by_code(p.organization_id,'1200');
  v_tax := public.account_id_by_code(p.organization_id,'1310');
  v_ap := public.account_id_by_code(p.organization_id,'2000');
  v_wht := public.account_id_by_code(p.organization_id,'2200');
  v_expense := public.account_id_by_code(p.organization_id,'6000');

  for l in
    select pl.*, pr.track_inventory
    from public.purchase_lines pl
    left join public.products pr on pr.id=pl.product_id
    where pl.purchase_id=p.id
    order by pl.id
  loop
    if l.product_id is not null and coalesce(l.track_inventory,false) then
      v_inventory_subtotal := v_inventory_subtotal + l.line_total;
    else
      v_expense_subtotal := v_expense_subtotal + l.line_total;
    end if;
  end loop;

  if v_inventory is null or v_ap is null or (v_expense_subtotal > 0 and v_expense is null) then
    raise exception 'Default accounts are missing';
  end if;

  v_net_ap := p.total_amount - p.withholding_amount;
  if v_net_ap < 0 then raise exception 'Withholding cannot exceed invoice total'; end if;

  if v_inventory_subtotal > 0 then
    v_lines := v_lines || jsonb_build_array(jsonb_build_object('account_id',v_inventory,'debit',v_inventory_subtotal,'credit',0,'description','Inventory purchase'));
  end if;
  if v_expense_subtotal > 0 then
    v_lines := v_lines || jsonb_build_array(jsonb_build_object('account_id',v_expense,'debit',v_expense_subtotal,'credit',0,'description','Non-inventory purchase expense'));
  end if;
  if p.tax_amount > 0 then
    v_lines := v_lines || jsonb_build_array(jsonb_build_object('account_id',v_tax,'debit',p.tax_amount,'credit',0,'description','Input tax'));
  end if;
  v_lines := v_lines || jsonb_build_array(jsonb_build_object('account_id',v_ap,'debit',0,'credit',v_net_ap,'description','Supplier payable'));
  if p.withholding_amount > 0 then
    v_lines := v_lines || jsonb_build_array(jsonb_build_object('account_id',v_wht,'debit',0,'credit',p.withholding_amount,'description','Withholding tax payable'));
  end if;

  v_tx := public.post_journal(p.organization_id,p.purchase_date,p.invoice_number,'Purchase '||p.invoice_number,'PURCHASE',p.id,v_lines);

  for l in
    select pl.*, pr.track_inventory
    from public.purchase_lines pl
    join public.products pr on pr.id=pl.product_id
    where pl.purchase_id=p.id and pr.track_inventory=true
    order by pl.id
  loop
    perform public.add_inventory_movement(p.organization_id,l.product_id,p.purchase_date,'PURCHASE',l.quantity,l.unit_price,'PURCHASE',p.id,'Purchase '||p.invoice_number);
  end loop;

  update public.purchases set status='POSTED', updated_at=now() where id=p.id;
  insert into public.audit_logs(organization_id,actor_user_id,action,entity_type,entity_id,after_data)
  values(p.organization_id,auth.uid(),'POST','PURCHASE',p.id,to_jsonb(p));
  return v_tx;
end;
$$;

create or replace function public.post_sale(p_sale_id uuid)
returns uuid
language plpgsql security definer set search_path = public
as $$
declare
  s public.sales%rowtype;
  l record;
  v_ar uuid; v_revenue uuid; v_tax uuid; v_wht uuid; v_cogs uuid; v_inventory uuid; v_tx uuid;
  v_net_ar numeric(18,2);
  v_cogs_total numeric(18,2) := 0;
  v_lines jsonb;
  v_cost numeric(18,6);
begin
  select * into s from public.sales where id=p_sale_id for update;
  if not found then raise exception 'Sale not found'; end if;
  if not public.is_org_member(s.organization_id) then raise exception 'Not authorized'; end if;
  if s.status <> 'DRAFT' then raise exception 'Only draft sales can be posted'; end if;

  v_ar := public.account_id_by_code(s.organization_id,'1100');
  v_revenue := public.account_id_by_code(s.organization_id,'4000');
  v_tax := public.account_id_by_code(s.organization_id,'2100');
  v_wht := public.account_id_by_code(s.organization_id,'1300');
  v_cogs := public.account_id_by_code(s.organization_id,'5000');
  v_inventory := public.account_id_by_code(s.organization_id,'1200');

  v_net_ar := s.total_amount - s.withholding_amount;
  if v_net_ar < 0 then raise exception 'Withholding cannot exceed invoice total'; end if;

  -- Calculate and write outbound inventory movements first. add_inventory_movement
  -- rejects negative stock and assigns the current weighted-average cost.
  for l in
    select sl.*, pr.track_inventory
    from public.sale_lines sl
    left join public.products pr on pr.id=sl.product_id
    where sl.sale_id=s.id
    order by sl.id
  loop
    if l.product_id is not null and coalesce(l.track_inventory,false) then
      v_cost := public.inventory_average_cost(s.organization_id,l.product_id,s.sale_date);
      perform public.add_inventory_movement(s.organization_id,l.product_id,s.sale_date,'SALE',-l.quantity,v_cost,'SALE',s.id,'Sale '||s.invoice_number);
      v_cogs_total := v_cogs_total + round((l.quantity * v_cost)::numeric,2);
    end if;
  end loop;

  v_lines := jsonb_build_array(
    jsonb_build_object('account_id',v_ar,'debit',v_net_ar,'credit',0,'description','Customer receivable'),
    jsonb_build_object('account_id',v_revenue,'debit',0,'credit',s.subtotal,'description','Sales revenue')
  );
  if s.tax_amount > 0 then
    v_lines := v_lines || jsonb_build_array(jsonb_build_object('account_id',v_tax,'debit',0,'credit',s.tax_amount,'description','Tax payable'));
  end if;
  if s.withholding_amount > 0 then
    v_lines := v_lines || jsonb_build_array(jsonb_build_object('account_id',v_wht,'debit',s.withholding_amount,'credit',0,'description','Withholding tax receivable'));
  end if;
  if v_cogs_total > 0 then
    v_lines := v_lines || jsonb_build_array(
      jsonb_build_object('account_id',v_cogs,'debit',v_cogs_total,'credit',0,'description','Cost of goods sold'),
      jsonb_build_object('account_id',v_inventory,'debit',0,'credit',v_cogs_total,'description','Inventory issued')
    );
  end if;

  v_tx := public.post_journal(s.organization_id,s.sale_date,s.invoice_number,'Sale '||s.invoice_number,'SALE',s.id,v_lines);
  update public.sales set status='POSTED', updated_at=now() where id=s.id;
  insert into public.audit_logs(organization_id,actor_user_id,action,entity_type,entity_id,after_data,metadata)
  values(s.organization_id,auth.uid(),'POST','SALE',s.id,to_jsonb(s),jsonb_build_object('cogs',v_cogs_total));
  return v_tx;
end;
$$;

create or replace function public.post_production(p_batch_id uuid)
returns uuid
language plpgsql security definer set search_path = public
as $$
declare
  b public.production_batches%rowtype;
  l record;
  v_inventory uuid;
  v_total_input_cost numeric(18,2) := 0;
  v_total_output_qty numeric(18,6) := 0;
  v_output_cost numeric(18,6);
  v_tx uuid;
  v_lines jsonb := '[]'::jsonb;
begin
  select * into b from public.production_batches where id=p_batch_id for update;
  if not found then raise exception 'Production batch not found'; end if;
  if not public.is_org_member(b.organization_id) then raise exception 'Not authorized'; end if;
  if b.status <> 'DRAFT' then raise exception 'Only draft production batches can be posted'; end if;

  v_inventory := public.account_id_by_code(b.organization_id,'1200');
  if v_inventory is null then raise exception 'Inventory account is missing'; end if;

  -- Inputs are issued at current average cost.
  for l in select pl.*, pr.track_inventory from public.production_lines pl join public.products pr on pr.id=pl.product_id where pl.batch_id=b.id and pl.line_type='INPUT' order by pl.id loop
    if not l.track_inventory then raise exception 'Production input % does not track inventory', l.product_id; end if;
    v_output_cost := public.inventory_average_cost(b.organization_id,l.product_id,b.production_date);
    perform public.add_inventory_movement(b.organization_id,l.product_id,b.production_date,'PRODUCTION_INPUT',-l.quantity,v_output_cost,'PRODUCTION',b.id,'Production input '||b.batch_number);
    v_total_input_cost := v_total_input_cost + round(l.quantity * v_output_cost,2);
  end loop;

  select coalesce(sum(quantity),0) into v_total_output_qty from public.production_lines where batch_id=b.id and line_type='OUTPUT';
  if v_total_output_qty <= 0 then raise exception 'Production batch needs at least one output'; end if;
  v_output_cost := round((v_total_input_cost / v_total_output_qty)::numeric,6);

  for l in select pl.*, pr.track_inventory from public.production_lines pl join public.products pr on pr.id=pl.product_id where pl.batch_id=b.id and pl.line_type='OUTPUT' order by pl.id loop
    if not l.track_inventory then raise exception 'Production output % does not track inventory', l.product_id; end if;
    perform public.add_inventory_movement(b.organization_id,l.product_id,b.production_date,'PRODUCTION_OUTPUT',l.quantity,v_output_cost,'PRODUCTION',b.id,'Production output '||b.batch_number);
  end loop;

  if v_total_input_cost > 0 then
    v_lines := jsonb_build_array(
      jsonb_build_object('account_id',v_inventory,'debit',v_total_input_cost,'credit',0,'description','Finished goods / production output'),
      jsonb_build_object('account_id',v_inventory,'debit',0,'credit',v_total_input_cost,'description','Raw materials / production input')
    );
    v_tx := public.post_journal(b.organization_id,b.production_date,b.batch_number,'Production '||b.batch_number,'PRODUCTION',b.id,v_lines);
  end if;

  update public.production_batches set status='POSTED', updated_at=now() where id=b.id;
  insert into public.audit_logs(organization_id,actor_user_id,action,entity_type,entity_id,after_data,metadata)
  values(b.organization_id,auth.uid(),'POST','PRODUCTION',b.id,to_jsonb(b),jsonb_build_object('input_cost',v_total_input_cost,'output_unit_cost',v_output_cost));
  return v_tx;
end;
$$;

create or replace function public.post_inventory_opening(
  p_org uuid, p_product uuid, p_date date, p_quantity numeric, p_unit_cost numeric, p_reference text default null
)
returns uuid
language plpgsql security definer set search_path = public
as $$
declare v_id uuid; v_equity uuid;
begin
  if not public.is_org_member(p_org) then raise exception 'Not authorized'; end if;
  if p_quantity <= 0 or p_unit_cost < 0 then raise exception 'Invalid opening inventory values'; end if;
  v_id := public.add_inventory_movement(p_org,p_product,p_date,'OPENING',p_quantity,p_unit_cost,'OPENING',null,p_reference);
  v_equity := public.account_id_by_code(p_org,'3000');
  perform public.post_journal(p_org,p_date,p_reference,'Opening inventory','OPENING',v_id,
    jsonb_build_array(
      jsonb_build_object('account_id',public.account_id_by_code(p_org,'1200'),'debit',round(p_quantity*p_unit_cost,2),'credit',0,'description','Opening inventory'),
      jsonb_build_object('account_id',v_equity,'debit',0,'credit',round(p_quantity*p_unit_cost,2),'description','Opening equity')
    ));
  return v_id;
end;
$$;

create or replace function public.post_inventory_adjustment(
  p_org uuid, p_product uuid, p_date date, p_new_quantity numeric, p_reference text default null
)
returns uuid
language plpgsql security definer set search_path = public
as $$
declare
  v_current numeric(18,6);
  v_delta numeric(18,6);
  v_cost numeric(18,6);
  v_id uuid;
  v_inventory uuid;
  v_expense uuid;
  v_value numeric(18,2);
begin
  if not public.is_org_member(p_org) then raise exception 'Not authorized'; end if;
  if p_new_quantity < 0 then raise exception 'Inventory quantity cannot be negative'; end if;
  v_current := public.inventory_quantity(p_org,p_product,p_date);
  v_delta := p_new_quantity - v_current;
  if v_delta = 0 then raise exception 'No inventory adjustment is required'; end if;
  v_cost := public.inventory_average_cost(p_org,p_product,p_date);
  v_id := public.add_inventory_movement(p_org,p_product,p_date,'ADJUSTMENT',v_delta,v_cost,'ADJUSTMENT',null,p_reference);
  v_inventory := public.account_id_by_code(p_org,'1200');
  v_expense := public.account_id_by_code(p_org,'6000');
  v_value := round(abs(v_delta*v_cost),2);
  if v_value > 0 then
    if v_delta > 0 then
      perform public.post_journal(p_org,p_date,p_reference,'Inventory increase','ADJUSTMENT',v_id,
        jsonb_build_array(jsonb_build_object('account_id',v_inventory,'debit',v_value,'credit',0,'description','Inventory adjustment'),jsonb_build_object('account_id',v_expense,'debit',0,'credit',v_value,'description','Inventory adjustment offset')));
    else
      perform public.post_journal(p_org,p_date,p_reference,'Inventory decrease','ADJUSTMENT',v_id,
        jsonb_build_array(jsonb_build_object('account_id',v_expense,'debit',v_value,'credit',0,'description','Inventory adjustment loss'),jsonb_build_object('account_id',v_inventory,'debit',0,'credit',v_value,'description','Inventory adjustment')));
    end if;
  end if;
  return v_id;
end;
$$;

create or replace view public.inventory_balances as
select
  p.organization_id,
  p.id as product_id,
  p.sku,
  p.name,
  p.unit,
  public.inventory_quantity(p.organization_id,p.id,null) as quantity_on_hand,
  public.inventory_average_cost(p.organization_id,p.id,null) as average_cost,
  round((public.inventory_quantity(p.organization_id,p.id,null) * public.inventory_average_cost(p.organization_id,p.id,null))::numeric,2) as inventory_value
from public.products p
where p.track_inventory=true;

create or replace function public.inventory_dashboard(p_org uuid)
returns table(product_count bigint, total_quantity numeric, total_value numeric)
language sql stable security definer set search_path = public
as $$
  select count(*)::bigint,
         coalesce(sum(quantity_on_hand),0),
         coalesce(sum(inventory_value),0)
  from public.inventory_balances
  where organization_id=p_org and quantity_on_hand <> 0;
$$;
