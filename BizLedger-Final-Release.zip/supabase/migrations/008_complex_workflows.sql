-- BizLedger Phase 2D: complex transaction workflows
-- Draft -> post -> payment -> paid/partial lifecycle, reversals, production, loans, withholding.

create index if not exists idx_payments_source on public.payments(organization_id, source_type, source_id);
create index if not exists idx_loan_payments_org_date on public.loan_payments(organization_id, payment_date desc);
create index if not exists idx_production_org_date on public.production_batches(organization_id, production_date desc);

create or replace function public.recalculate_document_status(p_source_type text, p_source_id uuid)
returns void language plpgsql security definer set search_path=public as $$
declare v_total numeric(18,2); v_paid numeric(18,2); v_status public.document_status;
begin
  if p_source_type='SALE' then
    select total_amount-withholding_amount into v_total from public.sales where id=p_source_id;
    select coalesce(sum(amount),0) into v_paid from public.payments where source_type='SALE' and source_id=p_source_id and direction='IN';
    v_status := case when v_paid >= v_total then 'PAID' when v_paid > 0 then 'PARTIALLY_PAID' else 'POSTED' end;
    update public.sales set status=v_status,updated_at=now() where id=p_source_id and status not in ('VOIDED','DRAFT');
  elsif p_source_type='PURCHASE' then
    select total_amount-withholding_amount into v_total from public.purchases where id=p_source_id;
    select coalesce(sum(amount),0) into v_paid from public.payments where source_type='PURCHASE' and source_id=p_source_id and direction='OUT';
    v_status := case when v_paid >= v_total then 'PAID' when v_paid > 0 then 'PARTIALLY_PAID' else 'POSTED' end;
    update public.purchases set status=v_status,updated_at=now() where id=p_source_id and status not in ('VOIDED','DRAFT');
  end if;
end; $$;

create or replace function public.record_payment(
  p_org uuid, p_direction public.payment_direction, p_date date, p_account_id uuid,
  p_contact_id uuid, p_source_type text, p_source_id uuid, p_amount numeric,
  p_reference text default null, p_notes text default null
) returns uuid language plpgsql security definer set search_path=public as $$
declare v_payment uuid; v_ar uuid; v_ap uuid; v_expense uuid; v_lines jsonb; v_tx uuid;
v_remaining numeric(18,2);
v_org uuid;
begin
  if not public.is_org_member(p_org) then raise exception 'Not authorized'; end if;
  if p_amount <= 0 then raise exception 'Payment amount must be positive'; end if;
  if not exists(select 1 from public.accounts where id=p_account_id and organization_id=p_org and active) then raise exception 'Invalid payment account'; end if;

  if p_source_type='SALE' then
    select organization_id,total_amount-withholding_amount into v_org,v_remaining from public.sales where id=p_source_id and status in ('POSTED','PARTIALLY_PAID','PAID');
    if v_org is null or v_org<>p_org then raise exception 'Sale not found or not posted'; end if;
    select v_remaining-coalesce(sum(amount),0) into v_remaining from public.payments where source_type='SALE' and source_id=p_source_id and direction='IN';
    if p_amount > v_remaining + 0.01 then raise exception 'Payment exceeds outstanding receivable'; end if;
  elsif p_source_type='PURCHASE' then
    select organization_id,total_amount-withholding_amount into v_org,v_remaining from public.purchases where id=p_source_id and status in ('POSTED','PARTIALLY_PAID','PAID');
    if v_org is null or v_org<>p_org then raise exception 'Purchase not found or not posted'; end if;
    select v_remaining-coalesce(sum(amount),0) into v_remaining from public.payments where source_type='PURCHASE' and source_id=p_source_id and direction='OUT';
    if p_amount > v_remaining + 0.01 then raise exception 'Payment exceeds outstanding payable'; end if;
  elsif p_source_type='EXPENSE' then
    select organization_id into v_org from public.expenses where id=p_source_id and status in ('POSTED','PARTIALLY_PAID','PAID');
    if v_org is null or v_org<>p_org then raise exception 'Expense not found or not posted'; end if;
  else
    raise exception 'Unsupported payment source';
  end if;

  v_ar := public.account_id_by_code(p_org,'1100');
  v_ap := public.account_id_by_code(p_org,'2000');
  v_expense := public.account_id_by_code(p_org,'6000');

  insert into public.payments(organization_id,direction,payment_date,account_id,contact_id,source_type,source_id,amount,reference,notes,created_by)
  values(p_org,p_direction,p_date,p_account_id,p_contact_id,p_source_type,p_source_id,p_amount,p_reference,p_notes,auth.uid()) returning id into v_payment;

  if p_source_type='SALE' then
    if p_direction<>'IN' then raise exception 'Sale payment must be incoming'; end if;
    v_lines := jsonb_build_array(
      jsonb_build_object('account_id',p_account_id,'debit',p_amount,'credit',0,'description','Customer payment'),
      jsonb_build_object('account_id',v_ar,'debit',0,'credit',p_amount,'description','Customer receivable settlement'));
  elsif p_source_type='PURCHASE' then
    if p_direction<>'OUT' then raise exception 'Purchase payment must be outgoing'; end if;
    v_lines := jsonb_build_array(
      jsonb_build_object('account_id',v_ap,'debit',p_amount,'credit',0,'description','Supplier payable settlement'),
      jsonb_build_object('account_id',p_account_id,'debit',0,'credit',p_amount,'description','Supplier payment'));
  else
    if p_direction<>'OUT' then raise exception 'Expense payment must be outgoing'; end if;
    v_lines := jsonb_build_array(
      jsonb_build_object('account_id',v_expense,'debit',p_amount,'credit',0,'description','Expense payment'),
      jsonb_build_object('account_id',p_account_id,'debit',0,'credit',p_amount,'description','Expense cash payment'));
  end if;
  v_tx := public.post_journal(p_org,p_date,p_reference,p_notes,'PAYMENT',v_payment,v_lines);
  if p_source_type in ('SALE','PURCHASE') then perform public.recalculate_document_status(p_source_type,p_source_id); end if;
  return v_payment;
end; $$;

create or replace function public.post_expense(p_expense_id uuid)
returns uuid language plpgsql security definer set search_path=public as $$
declare e public.expenses%rowtype; v_expense uuid; v_tax uuid; v_wht uuid; v_ap uuid; v_lines jsonb; v_tx uuid;
begin
  select * into e from public.expenses where id=p_expense_id for update;
  if not found then raise exception 'Expense not found'; end if;
  if not public.is_org_member(e.organization_id) then raise exception 'Not authorized'; end if;
  if e.status<>'DRAFT' then raise exception 'Only draft expenses can be posted'; end if;
  v_expense:=public.account_id_by_code(e.organization_id,'6000'); v_tax:=public.account_id_by_code(e.organization_id,'1310'); v_wht:=public.account_id_by_code(e.organization_id,'2200'); v_ap:=public.account_id_by_code(e.organization_id,'2000');
  v_lines:=jsonb_build_array(jsonb_build_object('account_id',v_expense,'debit',e.amount,'credit',0,'description','Operating expense'),jsonb_build_object('account_id',v_ap,'debit',0,'credit',e.amount,'description','Expense payable'));
  if e.tax_amount>0 then v_lines:=v_lines||jsonb_build_array(jsonb_build_object('account_id',v_tax,'debit',e.tax_amount,'credit',0,'description','Input tax')); end if;
  if e.withholding_amount>0 then v_lines:=v_lines||jsonb_build_array(jsonb_build_object('account_id',v_wht,'debit',0,'credit',e.withholding_amount,'description','Withholding payable'),jsonb_build_object('account_id',v_ap,'debit',e.withholding_amount,'credit',0,'description','Withholding reduces vendor payable')); end if;
  v_tx:=public.post_journal(e.organization_id,e.expense_date,e.reference,'Expense '||coalesce(e.reference,e.id::text),'EXPENSE',e.id,v_lines);
  update public.expenses set status='POSTED',updated_at=now() where id=e.id;
  insert into public.audit_logs(organization_id,actor_user_id,action,entity_type,entity_id,after_data) values(e.organization_id,auth.uid(),'POST','EXPENSE',e.id,to_jsonb(e));
  return v_tx;
end; $$;
grant execute on function public.post_expense(uuid) to authenticated;

create or replace function public.post_loan(p_loan_id uuid,p_account_id uuid)
returns uuid language plpgsql security definer set search_path=public as $$
declare l public.loans%rowtype; v_cash uuid; v_loan uuid; v_tx uuid;
begin
  select * into l from public.loans where id=p_loan_id for update;
  if not found then raise exception 'Loan not found'; end if;
  if not public.is_org_member(l.organization_id) then raise exception 'Not authorized'; end if;
  if l.status<>'DRAFT' then raise exception 'Only draft loans can be posted'; end if;
  if not exists(select 1 from public.accounts where id=p_account_id and organization_id=l.organization_id and active and type in ('CASH','BANK')) then raise exception 'Invalid cash/bank account'; end if;
  v_loan:=public.account_id_by_code(l.organization_id,'2000');
  v_tx:=public.post_journal(l.organization_id,l.start_date,l.loan_number,'Loan disbursement','LOAN',l.id,jsonb_build_array(jsonb_build_object('account_id',p_account_id,'debit',l.principal_amount,'credit',0,'description','Loan proceeds'),jsonb_build_object('account_id',v_loan,'debit',0,'credit',l.principal_amount,'description','Loan liability')));
  update public.loans set status='ACTIVE' where id=l.id;
  return v_tx;
end; $$;
grant execute on function public.post_loan(uuid,uuid) to authenticated;

create or replace function public.record_loan_payment(p_loan_id uuid,p_account_id uuid,p_date date,p_principal numeric,p_interest numeric,p_reference text default null,p_notes text default null)
returns uuid language plpgsql security definer set search_path=public as $$
declare l public.loans%rowtype; v_loan uuid; v_interest uuid; v_payment uuid; v_tx uuid; v_outstanding numeric;
begin
  select * into l from public.loans where id=p_loan_id for update;
  if not found or not public.is_org_member(l.organization_id) then raise exception 'Loan not found or unauthorized'; end if;
  if p_principal<0 or p_interest<0 or p_principal+p_interest<=0 then raise exception 'Invalid loan payment'; end if;
  if not exists(select 1 from public.accounts where id=p_account_id and organization_id=l.organization_id and active and type in ('CASH','BANK')) then raise exception 'Invalid cash/bank account'; end if;
  select l.principal_amount-coalesce(sum(principal_amount),0) into v_outstanding from public.loan_payments where loan_id=l.id;
  if p_principal>v_outstanding+0.01 then raise exception 'Principal payment exceeds outstanding loan balance'; end if;
  insert into public.loan_payments(organization_id,loan_id,payment_date,principal_amount,interest_amount,reference,notes,created_by) values(l.organization_id,l.id,p_date,p_principal,p_interest,p_reference,p_notes,auth.uid()) returning id into v_payment;
  v_loan:=public.account_id_by_code(l.organization_id,'2000'); v_interest:=public.account_id_by_code(l.organization_id,'6100');
  v_tx:=public.post_journal(l.organization_id,p_date,p_reference,'Loan repayment','LOAN_PAYMENT',v_payment,jsonb_build_array(jsonb_build_object('account_id',v_loan,'debit',p_principal,'credit',0,'description','Principal repayment'),jsonb_build_object('account_id',v_interest,'debit',p_interest,'credit',0,'description','Interest expense'),jsonb_build_object('account_id',p_account_id,'debit',0,'credit',p_principal+p_interest,'description','Loan payment')));
  if p_principal >= v_outstanding-0.01 then update public.loans set status='CLOSED' where id=l.id; end if;
  return v_payment;
end; $$;
grant execute on function public.record_loan_payment(uuid,uuid,date,numeric,numeric,text,text) to authenticated;

create or replace function public.post_production_batch(p_batch_id uuid,p_lines jsonb)
returns uuid language plpgsql security definer set search_path=public as $$
declare b public.production_batches%rowtype; x jsonb; v_count int;
begin
  select * into b from public.production_batches where id=p_batch_id for update;
  if not found or not public.is_org_member(b.organization_id) then raise exception 'Production batch not found or unauthorized'; end if;
  if b.status<>'DRAFT' then raise exception 'Only draft production batches can be posted'; end if;
  select count(*) into v_count from jsonb_array_elements(p_lines) x where x->>'line_type'='INPUT';
  if v_count<1 then raise exception 'At least one production input is required'; end if;
  select count(*) into v_count from jsonb_array_elements(p_lines) x where x->>'line_type'='OUTPUT';
  if v_count<1 then raise exception 'At least one production output is required'; end if;
  delete from public.production_lines where batch_id=b.id;
  for x in select * from jsonb_array_elements(p_lines) loop
    insert into public.production_lines(batch_id,product_id,line_type,quantity,unit_cost,notes) values(b.id,(x->>'product_id')::uuid,x->>'line_type',(x->>'quantity')::numeric,coalesce((x->>'unit_cost')::numeric,0),x->>'notes');
  end loop;
  return public.post_production(b.id);
end; $$;
grant execute on function public.post_production_batch(uuid,jsonb) to authenticated;

create or replace function public.record_withholding_remittance(p_org uuid,p_date date,p_amount numeric,p_account_id uuid,p_reference text default null,p_notes text default null)
returns uuid language plpgsql security definer set search_path=public as $$
declare v_pay uuid; v_wht uuid; v_tx uuid;
begin
  if not public.is_org_member(p_org) then raise exception 'Not authorized'; end if;
  if p_amount<=0 then raise exception 'Amount must be positive'; end if;
  if not exists(select 1 from public.accounts where id=p_account_id and organization_id=p_org and active and type in ('CASH','BANK')) then raise exception 'Invalid cash/bank account'; end if;
  v_wht:=public.account_id_by_code(p_org,'2200');
  insert into public.withholding_remittances(organization_id,remittance_date,amount,reference,notes) values(p_org,p_date,p_amount,p_reference,p_notes) returning id into v_pay;
  v_tx:=public.post_journal(p_org,p_date,p_reference,'Withholding remittance','WITHHOLDING_REMITTANCE',v_pay,jsonb_build_array(jsonb_build_object('account_id',v_wht,'debit',p_amount,'credit',0,'description','Withholding payable remitted'),jsonb_build_object('account_id',p_account_id,'debit',0,'credit',p_amount,'description','Tax remittance')));
  return v_pay;
end; $$;
grant execute on function public.record_withholding_remittance(uuid,date,numeric,uuid,text,text) to authenticated;

-- Void/reversal for posted source documents. Payments must be cleared first.
create or replace function public.void_source_document(p_source_type text,p_source_id uuid,p_reason text default null)
returns uuid language plpgsql security definer set search_path=public as $$
declare v_org uuid; v_status public.document_status; v_tx uuid; r record; v_lines jsonb:='[]'::jsonb; v_new uuid; v_date date; v_ref text; v_table text;
begin
  if p_source_type='SALE' then select organization_id,status,sale_date,invoice_number into v_org,v_status,v_date,v_ref from public.sales where id=p_source_id;
  elsif p_source_type='PURCHASE' then select organization_id,status,purchase_date,invoice_number into v_org,v_status,v_date,v_ref from public.purchases where id=p_source_id;
  elsif p_source_type='EXPENSE' then select organization_id,status,expense_date,reference into v_org,v_status,v_date,v_ref from public.expenses where id=p_source_id;
  else raise exception 'Unsupported source type'; end if;
  if v_org is null or not public.is_org_member(v_org) then raise exception 'Not found or unauthorized'; end if;
  if v_status not in ('POSTED','PARTIALLY_PAID','PAID') then raise exception 'Only posted documents can be voided'; end if;
  if exists(select 1 from public.payments where source_type=p_source_type and source_id=p_source_id) then raise exception 'Reverse or remove linked payments before voiding the document'; end if;
  for r in select l.account_id,l.debit,l.credit,l.description from public.financial_transaction_lines l join public.financial_transactions t on t.id=l.transaction_id where t.source_type=p_source_type and t.source_id=p_source_id and t.posted=true loop
    v_lines:=v_lines||jsonb_build_array(jsonb_build_object('account_id',r.account_id,'debit',r.credit,'credit',r.debit,'description','Reversal: '||coalesce(r.description,'')));
  end loop;
  if jsonb_array_length(v_lines)=0 then raise exception 'No posted journal found for document'; end if;
  v_tx:=public.post_journal(v_org,v_date,'VOID-'||coalesce(v_ref,p_source_id::text),'Void '||p_source_type||' '||coalesce(v_ref,p_source_id::text),'VOID_'||p_source_type,p_source_id,v_lines);
  if p_source_type='SALE' then
    for r in select * from public.inventory_movements where source_type='SALE' and source_id=p_source_id loop perform public.add_inventory_movement(v_org,r.product_id,v_date,'SALE',-r.quantity,r.unit_cost,'VOID_SALE',p_source_id,'Void sale'); end loop;
    update public.sales set status='VOIDED',updated_at=now() where id=p_source_id;
  elsif p_source_type='PURCHASE' then
    for r in select * from public.inventory_movements where source_type='PURCHASE' and source_id=p_source_id loop perform public.add_inventory_movement(v_org,r.product_id,v_date,'PURCHASE',-r.quantity,r.unit_cost,'VOID_PURCHASE',p_source_id,'Void purchase'); end loop;
    update public.purchases set status='VOIDED',updated_at=now() where id=p_source_id;
  else update public.expenses set status='VOIDED',updated_at=now() where id=p_source_id; end if;
  insert into public.audit_logs(organization_id,actor_user_id,action,entity_type,entity_id,after_data,metadata) values(v_org,auth.uid(),'VOID',p_source_type,p_source_id,jsonb_build_object('reason',p_reason),jsonb_build_object('reversal_transaction',v_tx));
  return v_tx;
end; $$;
grant execute on function public.void_source_document(text,uuid,text) to authenticated;
