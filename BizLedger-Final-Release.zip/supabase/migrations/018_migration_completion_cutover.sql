-- BizLedger Phase 15: remaining legacy modules, detailed reconciliation, and final cutover lock.
-- Production imports are transactional and source-row tracked. Inventory movement history without
-- reliable valuation is retained for reconciliation rather than silently inventing accounting values.

create table if not exists public.migration_cutover_state (
  organization_id uuid primary key references public.organizations(id) on delete cascade,
  batch_id uuid references public.migration_batches(id) on delete set null,
  locked boolean not null default false,
  locked_at timestamptz,
  locked_by uuid references auth.users(id) on delete set null,
  notes text,
  updated_at timestamptz not null default now()
);
alter table public.migration_cutover_state enable row level security;
drop policy if exists migration_cutover_admin on public.migration_cutover_state;
create policy migration_cutover_admin on public.migration_cutover_state for all
using (public.has_permission(organization_id,'members.manage'))
with check (public.has_permission(organization_id,'members.manage'));

create or replace function public.migration_cutover_is_locked(p_org uuid)
returns boolean language sql stable security definer set search_path=public as $$
  select coalesce((select locked from public.migration_cutover_state where organization_id=p_org),false);
$$;
grant execute on function public.migration_cutover_is_locked(uuid) to authenticated;

create or replace function public.assert_migration_cutover_open(p_org uuid)
returns void language plpgsql security definer set search_path=public as $$
begin
  if public.migration_cutover_is_locked(p_org) and coalesce(current_setting('bizledger.allow_cutover_write',true),'') <> 'on' then
    raise exception 'Organization is in final cutover read-only mode';
  end if;
end; $$;


-- Prevent normal application writes after final sign-off. SECURITY DEFINER migration functions can
-- explicitly opt in only if they are intentionally used before the lock is enabled.
create or replace function public.block_cutover_writes()
returns trigger language plpgsql security definer set search_path=public as $$
declare v_org uuid;
begin
  v_org := coalesce(NEW.organization_id,OLD.organization_id);
  perform public.assert_migration_cutover_open(v_org);
  if TG_OP='DELETE' then return OLD; else return NEW; end if;
end; $$;

drop trigger if exists trg_cutover_sales on public.sales;
create trigger trg_cutover_sales before insert or update or delete on public.sales for each row execute function public.block_cutover_writes();
drop trigger if exists trg_cutover_purchases on public.purchases;
create trigger trg_cutover_purchases before insert or update or delete on public.purchases for each row execute function public.block_cutover_writes();
drop trigger if exists trg_cutover_expenses on public.expenses;
create trigger trg_cutover_expenses before insert or update or delete on public.expenses for each row execute function public.block_cutover_writes();
drop trigger if exists trg_cutover_payments on public.payments;
create trigger trg_cutover_payments before insert or update or delete on public.payments for each row execute function public.block_cutover_writes();
drop trigger if exists trg_cutover_inventory on public.inventory_movements;
create trigger trg_cutover_inventory before insert or update or delete on public.inventory_movements for each row execute function public.block_cutover_writes();
drop trigger if exists trg_cutover_production on public.production_batches;
create trigger trg_cutover_production before insert or update or delete on public.production_batches for each row execute function public.block_cutover_writes();
drop trigger if exists trg_cutover_loans on public.loans;
create trigger trg_cutover_loans before insert or update or delete on public.loans for each row execute function public.block_cutover_writes();
drop trigger if exists trg_cutover_loan_payments on public.loan_payments;
create trigger trg_cutover_loan_payments before insert or update or delete on public.loan_payments for each row execute function public.block_cutover_writes();
drop trigger if exists trg_cutover_wht_received on public.withholding_received;
create trigger trg_cutover_wht_received before insert or update or delete on public.withholding_received for each row execute function public.block_cutover_writes();
drop trigger if exists trg_cutover_wht_collected on public.withholding_collected;
create trigger trg_cutover_wht_collected before insert or update or delete on public.withholding_collected for each row execute function public.block_cutover_writes();
drop trigger if exists trg_cutover_wht_remit on public.withholding_remittances;
create trigger trg_cutover_wht_remit before insert or update or delete on public.withholding_remittances for each row execute function public.block_cutover_writes();
drop trigger if exists trg_cutover_financial_transactions on public.financial_transactions;
create trigger trg_cutover_financial_transactions before insert or update or delete on public.financial_transactions for each row execute function public.block_cutover_writes();

create or replace function public.import_migration_remaining_modules(p_batch uuid,p_confirm boolean default false)
returns jsonb language plpgsql security definer set search_path=public as $$
declare
  b public.migration_batches%rowtype;
  r record; x jsonb; v_id uuid; v_product uuid; v_contact uuid; v_loan uuid; v_account uuid;
  v_opening int:=0; v_production int:=0; v_loans int:=0; v_loanpay int:=0; v_wht int:=0; v_whc int:=0; v_remit int:=0; v_inventory_review int:=0;
  v_batch_status text;
  v_key text; v_date date; v_qty numeric; v_cost numeric; v_amount numeric; v_principal numeric; v_interest numeric; v_rate numeric; v_gross numeric; v_withheld numeric;
begin
  select * into b from public.migration_batches where id=p_batch for update;
  if not found then raise exception 'Migration batch not found'; end if;
  if not public.has_permission(b.organization_id,'members.manage') then raise exception 'Not authorized'; end if;
  if b.status not in ('VALIDATED','IMPORTED') then raise exception 'Batch must be VALIDATED or IMPORTED'; end if;
  if public.migration_cutover_is_locked(b.organization_id) then raise exception 'Migration is already in final read-only mode'; end if;
  if not p_confirm then return jsonb_build_object('ready',true,'message','Explicit confirmation is required.'); end if;

  -- Opening inventory: only positive, cost-bearing source rows are imported. The legacy inventory
  -- table has no unit cost, so a product purchase price is used only as a declared migration rule.
  for r in select * from public.migration_financial_rows where batch_id=p_batch and module='inventory' and status in ('READY','REVIEW') order by row_number loop
    if lower(coalesce(r.raw_data->>'move','')) <> 'in' then
      update public.migration_financial_rows set status='REVIEW',issues=issues||jsonb_build_array('Legacy inventory movement retained for reconciliation; non-opening movement was not posted.') where id=r.id;
      v_inventory_review:=v_inventory_review+1; continue;
    end if;
    select mm.target_id into v_product from public.migration_mappings mm join public.migration_rows mr on mr.id=mm.migration_row_id where mm.batch_id=p_batch and mm.module='products' and mr.raw_data->>'id'=r.raw_data->>'productId' limit 1;
    if v_product is null then raise exception 'Missing product mapping for inventory row %',r.row_number; end if;
    v_qty:=abs(coalesce((r.raw_data->>'qty')::numeric,0));
    if v_qty<=0 then raise exception 'Invalid opening inventory quantity at row %',r.row_number; end if;
    select greatest(coalesce(p.purchase_price,0),0) into v_cost from public.products p where p.id=v_product;
    v_date:=coalesce(r.proposed_date,(r.raw_data->>'dateISO')::date); v_key:=coalesce(nullif(r.proposed_document_key,''),'Opening inventory');
    v_id:=public.post_inventory_opening(b.organization_id,v_product,v_date,v_qty,v_cost,v_key);
    update public.migration_financial_rows set status='IMPORTED',proposed_source_id=v_id,proposed_product_id=v_product where id=r.id;
    v_opening:=v_opening+1;
  end loop;

  -- Production: legacy supports one input and up to two outputs.
  for r in select * from public.migration_financial_rows where batch_id=p_batch and module='production' and status in ('READY','REVIEW') order by row_number loop
    select mm.target_id into v_product from public.migration_mappings mm join public.migration_rows mr on mr.id=mm.migration_row_id where mm.batch_id=p_batch and mm.module='products' and mr.raw_data->>'id'=r.raw_data->>'inprod' limit 1;
    if v_product is null then raise exception 'Missing production input mapping at row %',r.row_number; end if;
    v_date:=coalesce(r.proposed_date,(r.raw_data->>'dateISO')::date); v_key:=coalesce(nullif(r.raw_data->>'id',''),'LEGACY-PROD-'||r.row_number::text);
    insert into public.production_batches(organization_id,batch_number,production_date,status,notes,created_by) values(b.organization_id,v_key,v_date,'DRAFT',r.raw_data->>'notes',auth.uid()) returning id into v_id;
    x:='[]'::jsonb;
    -- Reuse x as a JSON line accumulator; output 1 is required by the legacy form.
    select mm.target_id into v_product from public.migration_mappings mm join public.migration_rows mr on mr.id=mm.migration_row_id where mm.batch_id=p_batch and mm.module='products' and mr.raw_data->>'id'=r.raw_data->>'outprod' limit 1;
    if v_product is null or coalesce((r.raw_data->>'outqty')::numeric,0)<=0 then raise exception 'Missing production output mapping/quantity at row %',r.row_number; end if;
    x:=jsonb_build_array(jsonb_build_object('product_id', (select mm.target_id from public.migration_mappings mm join public.migration_rows mr on mr.id=mm.migration_row_id where mm.batch_id=p_batch and mm.module='products' and mr.raw_data->>'id'=r.raw_data->>'inprod' limit 1),'line_type','INPUT','quantity',(r.raw_data->>'inqty')::numeric), jsonb_build_object('product_id',v_product,'line_type','OUTPUT','quantity',(r.raw_data->>'outqty')::numeric));
    if nullif(r.raw_data->>'outprod2','') is not null and coalesce((r.raw_data->>'outqty2')::numeric,0)>0 then
      select mm.target_id into v_product from public.migration_mappings mm join public.migration_rows mr on mr.id=mm.migration_row_id where mm.batch_id=p_batch and mm.module='products' and mr.raw_data->>'id'=r.raw_data->>'outprod2' limit 1;
      if v_product is null then raise exception 'Missing second production output mapping at row %',r.row_number; end if;
      x:=x||jsonb_build_array(jsonb_build_object('product_id',v_product,'line_type','OUTPUT','quantity',(r.raw_data->>'outqty2')::numeric));
    end if;
    perform public.post_production_batch(v_id,x);
    update public.migration_financial_rows set status='IMPORTED',proposed_source_id=v_id where id=r.id;
    v_production:=v_production+1;
  end loop;

  -- Loans and repayments.
  select id into v_account from public.accounts where organization_id=b.organization_id and code='1000' and active limit 1;
  if v_account is null then raise exception 'Cash account 1000 is missing'; end if;
  for r in select * from public.migration_financial_rows where batch_id=p_batch and module='loans' and status in ('READY','REVIEW') order by row_number loop
    v_key:=coalesce(nullif(r.raw_data->>'id',''),'LEGACY-LOAN-'||r.row_number::text); v_date:=coalesce(r.proposed_date,(r.raw_data->>'dateISO')::date); v_amount:=coalesce((r.raw_data->>'amount')::numeric,0);
    if v_amount<=0 then raise exception 'Invalid loan amount at row %',r.row_number; end if;
    insert into public.loans(organization_id,loan_number,start_date,principal_amount,interest_rate,status,notes,created_by) values(b.organization_id,v_key,v_date,v_amount,0,'DRAFT',concat_ws(' | ',r.raw_data->>'bank',r.raw_data->>'notes'),auth.uid()) returning id into v_id;
    perform public.post_loan(v_id,v_account);
    update public.migration_financial_rows set status='IMPORTED',proposed_source_id=v_id where id=r.id;
    v_loans:=v_loans+1;
  end loop;

  for r in select * from public.migration_financial_rows where batch_id=p_batch and module='loanpay' and status in ('READY','REVIEW') order by row_number loop
    select f.proposed_source_id into v_loan from public.migration_financial_rows f where f.batch_id=p_batch and f.module='loans' and f.raw_data->>'id'=r.raw_data->>'loanId' and f.status='IMPORTED' limit 1;
    if v_loan is null then raise exception 'Missing imported loan for repayment row %',r.row_number; end if;
    v_date:=coalesce(r.proposed_date,(r.raw_data->>'dateISO')::date); v_principal:=coalesce((r.raw_data->>'principal')::numeric,0); v_interest:=coalesce((r.raw_data->>'interest')::numeric,0);
    v_id:=public.record_loan_payment(v_loan,v_account,v_date,v_principal,v_interest,nullif(r.raw_data->>'reference',''),null);
    update public.migration_financial_rows set status='IMPORTED',proposed_source_id=v_id where id=r.id;
    v_loanpay:=v_loanpay+1;
  end loop;

  -- Withholding received/collected are direct master records in the current product; remittances use
  -- the normal posting workflow. Existing purchase/expense postings already carry withholding payable.
  for r in select * from public.migration_financial_rows where batch_id=p_batch and module='wht' and status in ('READY','REVIEW') order by row_number loop
    v_date:=coalesce(r.proposed_date,(r.raw_data->>'dateISO')::date); v_gross:=coalesce((r.raw_data->>'gross')::numeric,0); v_rate:=coalesce((r.raw_data->>'rate')::numeric,0); v_withheld:=coalesce((r.raw_data->>'withheld')::numeric,round(v_gross*v_rate/100,2));
    if v_gross<=0 or v_withheld<0 then raise exception 'Invalid withholding received row %',r.row_number; end if;
    select mm.target_id into v_contact from public.migration_mappings mm join public.migration_rows mr on mr.id=mm.migration_row_id where mm.batch_id=p_batch and mm.module='contacts' and mr.raw_data->>'id'=r.raw_data->>'agentContactId' limit 1;
    insert into public.withholding_received(organization_id,contact_id,receipt_date,agent_name,agent_tin,gross_amount,rate,withheld_amount,net_amount,reference,certificate_number,notes) values(b.organization_id,v_contact,v_date,r.raw_data->>'agent',r.raw_data->>'tin',v_gross,v_rate,v_withheld,coalesce((r.raw_data->>'net')::numeric,v_gross-v_withheld),r.raw_data->>'reference',r.raw_data->>'certificate',null) returning id into v_id;
    update public.migration_financial_rows set status='IMPORTED',proposed_source_id=v_id,proposed_contact_id=v_contact where id=r.id; v_wht:=v_wht+1;
  end loop;

  for r in select * from public.migration_financial_rows where batch_id=p_batch and module='whc' and status in ('READY','REVIEW') order by row_number loop
    v_date:=coalesce(r.proposed_date,(r.raw_data->>'dateISO')::date); v_gross:=coalesce((r.raw_data->>'gross')::numeric,0); v_rate:=coalesce((r.raw_data->>'rate')::numeric,0); v_withheld:=coalesce((r.raw_data->>'withheld')::numeric,round(v_gross*v_rate/100,2));
    if v_gross<=0 or v_withheld<0 then raise exception 'Invalid withholding collected row %',r.row_number; end if;
    select mm.target_id into v_contact from public.migration_mappings mm join public.migration_rows mr on mr.id=mm.migration_row_id where mm.batch_id=p_batch and mm.module='contacts' and mr.raw_data->>'id'=r.raw_data->>'contactId' limit 1;
    insert into public.withholding_collected(organization_id,contact_id,collection_date,gross_amount,rate,withheld_amount,reference,notes) values(b.organization_id,v_contact,v_date,v_gross,v_rate,v_withheld,r.raw_data->>'reference',null) returning id into v_id;
    update public.migration_financial_rows set status='IMPORTED',proposed_source_id=v_id,proposed_contact_id=v_contact where id=r.id; v_whc:=v_whc+1;
  end loop;

  for r in select * from public.migration_financial_rows where batch_id=p_batch and module='whremit' and status in ('READY','REVIEW') order by row_number loop
    v_date:=coalesce(r.proposed_date,(r.raw_data->>'dateISO')::date); v_amount:=coalesce((r.raw_data->>'amount')::numeric,0); if v_amount<=0 then raise exception 'Invalid withholding remittance row %',r.row_number; end if;
    v_id:=public.record_withholding_remittance(b.organization_id,v_date,v_amount,v_account,r.raw_data->>'reference',null);
    update public.migration_financial_rows set status='IMPORTED',proposed_source_id=v_id where id=r.id; v_remit:=v_remit+1;
  end loop;

  update public.migration_batches set summary=summary||jsonb_build_object('phase15_imported_at',now(),'opening_inventory',v_opening,'inventory_review',v_inventory_review,'production',v_production,'loans',v_loans,'loan_payments',v_loanpay,'withholding_received',v_wht,'withholding_collected',v_whc,'withholding_remittances',v_remit), imported_at=coalesce(imported_at,now()) where id=p_batch;
  insert into public.audit_logs(organization_id,actor_user_id,action,entity_type,entity_id,metadata) values(b.organization_id,auth.uid(),'MIGRATION_REMAINING_MODULES_IMPORTED','migration_batch',p_batch,jsonb_build_object('opening_inventory',v_opening,'inventory_review',v_inventory_review,'production',v_production,'loans',v_loans,'loan_payments',v_loanpay,'wht_received',v_wht,'wht_collected',v_whc,'wht_remittances',v_remit));
  return jsonb_build_object('ready',false,'opening_inventory',v_opening,'inventory_review',v_inventory_review,'production',v_production,'loans',v_loans,'loan_payments',v_loanpay,'withholding_received',v_wht,'withholding_collected',v_whc,'withholding_remittances',v_remit);
end; $$;
revoke all on function public.import_migration_remaining_modules(uuid,boolean) from public;
grant execute on function public.import_migration_remaining_modules(uuid,boolean) to authenticated;

create or replace function public.get_migration_completion_reconciliation(p_batch uuid)
returns jsonb language plpgsql security definer set search_path=public as $$
declare b public.migration_batches%rowtype; r record; v jsonb:='{}'::jsonb; v_inventory_legacy numeric:=0; v_inventory_imported numeric:=0; v_loan_legacy numeric:=0; v_loan_imported numeric:=0; v_loanpay_legacy numeric:=0; v_loanpay_imported numeric:=0; v_wht_legacy numeric:=0; v_wht_imported numeric:=0; v_whc_legacy numeric:=0; v_whc_imported numeric:=0; v_remit_legacy numeric:=0; v_remit_imported numeric:=0; v_unresolved int:=0; v_inventory_review int:=0;
begin
 select * into b from public.migration_batches where id=p_batch; if not found then raise exception 'Migration batch not found'; end if; if not public.has_permission(b.organization_id,'members.manage') then raise exception 'Not authorized'; end if;
 select coalesce(sum(proposed_quantity),0) into v_inventory_legacy from public.migration_financial_rows where batch_id=p_batch and module='inventory' and lower(coalesce(raw_data->>'move',''))='in';
 select coalesce(sum(im.quantity),0) into v_inventory_imported from public.inventory_movements im join public.migration_financial_rows f on f.proposed_source_id=im.id and f.batch_id=p_batch and f.module='inventory' and f.status='IMPORTED';
 select coalesce(sum(proposed_amount),0) into v_loan_legacy from public.migration_financial_rows where batch_id=p_batch and module='loans';
 select coalesce(sum(l.principal_amount),0) into v_loan_imported from public.loans l join public.migration_financial_rows f on f.proposed_source_id=l.id and f.batch_id=p_batch and f.module='loans' and f.status='IMPORTED';
 select coalesce(sum(coalesce((raw_data->>'principal')::numeric,0)+coalesce((raw_data->>'interest')::numeric,0)),0) into v_loanpay_legacy from public.migration_financial_rows where batch_id=p_batch and module='loanpay';
 select coalesce(sum(lp.total_amount),0) into v_loanpay_imported from public.loan_payments lp join public.migration_financial_rows f on f.proposed_source_id=lp.id and f.batch_id=p_batch and f.module='loanpay' and f.status='IMPORTED';
 select coalesce(sum(coalesce((raw_data->>'withheld')::numeric,0)),0) into v_wht_legacy from public.migration_financial_rows where batch_id=p_batch and module='wht';
 select coalesce(sum(w.withheld_amount),0) into v_wht_imported from public.withholding_received w join public.migration_financial_rows f on f.proposed_source_id=w.id and f.batch_id=p_batch and f.module='wht' and f.status='IMPORTED';
 select coalesce(sum(coalesce((raw_data->>'withheld')::numeric,0)),0) into v_whc_legacy from public.migration_financial_rows where batch_id=p_batch and module='whc';
 select coalesce(sum(w.withheld_amount),0) into v_whc_imported from public.withholding_collected w join public.migration_financial_rows f on f.proposed_source_id=w.id and f.batch_id=p_batch and f.module='whc' and f.status='IMPORTED';
 select coalesce(sum(proposed_amount),0) into v_remit_legacy from public.migration_financial_rows where batch_id=p_batch and module='whremit';
 select coalesce(sum(w.amount),0) into v_remit_imported from public.withholding_remittances w join public.migration_financial_rows f on f.proposed_source_id=w.id and f.batch_id=p_batch and f.module='whremit' and f.status='IMPORTED';
 select count(*) into v_unresolved from public.migration_financial_rows where batch_id=p_batch and status not in ('IMPORTED','SKIPPED');
 select count(*) into v_inventory_review from public.migration_financial_rows where batch_id=p_batch and module='inventory' and status='REVIEW';
 v:=jsonb_build_object('batch_id',p_batch,'batch_status',b.status,'inventory',jsonb_build_object('legacy_quantity',v_inventory_legacy,'imported_quantity',v_inventory_imported,'difference',v_inventory_imported-v_inventory_legacy,'review_rows',v_inventory_review),'loans',jsonb_build_object('legacy_principal',v_loan_legacy,'imported_principal',v_loan_imported,'difference',v_loan_imported-v_loan_legacy),'loan_payments',jsonb_build_object('legacy_total',v_loanpay_legacy,'imported_total',v_loanpay_imported,'difference',v_loanpay_imported-v_loanpay_legacy),'withholding_received',jsonb_build_object('legacy_withheld',v_wht_legacy,'imported_withheld',v_wht_imported,'difference',v_wht_imported-v_wht_legacy),'withholding_collected',jsonb_build_object('legacy_withheld',v_whc_legacy,'imported_withheld',v_whc_imported,'difference',v_whc_imported-v_whc_legacy),'withholding_remittances',jsonb_build_object('legacy_amount',v_remit_legacy,'imported_amount',v_remit_imported,'difference',v_remit_imported-v_remit_legacy),'unresolved_rows',v_unresolved,'cutover_locked',public.migration_cutover_is_locked(b.organization_id),'cutover_ready',(b.status='IMPORTED' and v_unresolved=0 and v_inventory_review=0 and abs(v_loan_legacy-v_loan_imported)<0.01 and abs(v_loanpay_legacy-v_loanpay_imported)<0.01 and abs(v_wht_legacy-v_wht_imported)<0.01 and abs(v_whc_legacy-v_whc_imported)<0.01 and abs(v_remit_legacy-v_remit_imported)<0.01));
 return v;
end; $$;
grant execute on function public.get_migration_completion_reconciliation(uuid) to authenticated;

create or replace function public.lock_migration_cutover(p_batch uuid,p_notes text default null)
returns jsonb language plpgsql security definer set search_path=public as $$
declare b public.migration_batches%rowtype; r jsonb; begin select * into b from public.migration_batches where id=p_batch; if not found then raise exception 'Migration batch not found'; end if; if not public.has_permission(b.organization_id,'members.manage') then raise exception 'Not authorized'; end if; r:=public.get_migration_completion_reconciliation(p_batch); if coalesce((r->>'cutover_ready')::boolean,false) is not true then raise exception 'Migration is not ready for final cutover'; end if; insert into public.migration_cutover_state(organization_id,batch_id,locked,locked_at,locked_by,notes) values(b.organization_id,p_batch,true,now(),auth.uid(),p_notes) on conflict (organization_id) do update set batch_id=excluded.batch_id,locked=true,locked_at=excluded.locked_at,locked_by=excluded.locked_by,notes=excluded.notes,updated_at=now(); insert into public.audit_logs(organization_id,actor_user_id,action,entity_type,entity_id,metadata) values(b.organization_id,auth.uid(),'MIGRATION_CUTOVER_LOCKED','migration_batch',p_batch,jsonb_build_object('notes',p_notes)); return r||jsonb_build_object('locked',true); end; $$;
grant execute on function public.lock_migration_cutover(uuid,text) to authenticated;

create or replace function public.unlock_migration_cutover(p_org uuid,p_reason text)
returns void language plpgsql security definer set search_path=public as $$ begin if not public.has_permission(p_org,'members.manage') then raise exception 'Not authorized'; end if; if nullif(trim(p_reason),'') is null then raise exception 'Reason is required'; end if; update public.migration_cutover_state set locked=false,updated_at=now(),notes=p_reason where organization_id=p_org; insert into public.audit_logs(organization_id,actor_user_id,action,entity_type,metadata) values(p_org,auth.uid(),'MIGRATION_CUTOVER_UNLOCKED','organization',jsonb_build_object('reason',p_reason)); end; $$;
grant execute on function public.unlock_migration_cutover(uuid,text) to authenticated;
