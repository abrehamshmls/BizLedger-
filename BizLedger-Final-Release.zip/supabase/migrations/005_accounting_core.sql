-- BizLedger Phase 2A: accounting core
-- Financial principle: posted source documents create balanced journal entries.

create unique index if not exists uq_accounts_org_code
  on public.accounts(organization_id, code)
  where code is not null;

create index if not exists idx_ft_org_date_posted
  on public.financial_transactions(organization_id, transaction_date, posted);

create index if not exists idx_ftl_account
  on public.financial_transaction_lines(account_id);

create or replace function public.is_org_member(p_org uuid)
returns boolean
language sql stable security definer set search_path = public
as $$
  select exists (
    select 1 from public.organization_members m
    where m.organization_id = p_org
      and m.user_id = auth.uid()
      and m.status = 'ACTIVE'
  );
$$;

create or replace function public.seed_default_accounts(p_org uuid)
returns void
language plpgsql security definer set search_path = public
as $$
begin
  insert into public.accounts (organization_id, code, name, type)
  values
    (p_org, '1000', 'Cash on Hand', 'CASH'),
    (p_org, '1010', 'Bank Account', 'BANK'),
    (p_org, '1100', 'Accounts Receivable', 'RECEIVABLE'),
    (p_org, '1200', 'Inventory', 'INVENTORY'),
    (p_org, '1300', 'Withholding Tax Receivable', 'ASSET'),
    (p_org, '1310', 'Input Tax Receivable', 'ASSET'),
    (p_org, '2000', 'Accounts Payable', 'PAYABLE'),
    (p_org, '2100', 'Tax Payable', 'LIABILITY'),
    (p_org, '2200', 'Withholding Tax Payable', 'LIABILITY'),
    (p_org, '3000', 'Owner Equity', 'EQUITY'),
    (p_org, '4000', 'Sales Revenue', 'INCOME'),
    (p_org, '5000', 'Cost of Goods Sold', 'EXPENSE'),
    (p_org, '6000', 'Operating Expenses', 'EXPENSE'),
    (p_org, '6100', 'Interest Expense', 'EXPENSE')
  on conflict (organization_id, code) do nothing;
end;
$$;

-- Seed accounts for existing and future organizations.
do $$
declare r record;
begin
  for r in select id from public.organizations loop
    perform public.seed_default_accounts(r.id);
  end loop;
end $$;

-- Ensure new organizations receive a usable chart of accounts.
create or replace function public.handle_organization_accounts()
returns trigger
language plpgsql security definer set search_path = public
as $$
begin
  perform public.seed_default_accounts(new.id);
  return new;
end;
$$;

drop trigger if exists trg_organization_accounts on public.organizations;
create trigger trg_organization_accounts
after insert on public.organizations
for each row execute function public.handle_organization_accounts();

create or replace function public.account_id_by_code(p_org uuid, p_code text)
returns uuid
language sql stable security definer set search_path = public
as $$
  select id from public.accounts
  where organization_id = p_org and code = p_code and active = true
  limit 1;
$$;

create or replace function public.post_journal(
  p_org uuid,
  p_date date,
  p_reference text,
  p_description text,
  p_source_type text,
  p_source_id uuid,
  p_lines jsonb
)
returns uuid
language plpgsql security definer set search_path = public
as $$
declare
  v_tx uuid;
  v_total_debit numeric(18,2);
  v_total_credit numeric(18,2);
  v_line jsonb;
begin
  if not public.is_org_member(p_org) then
    raise exception 'Not a member of this organization';
  end if;

  select coalesce(sum((x->>'debit')::numeric),0), coalesce(sum((x->>'credit')::numeric),0)
    into v_total_debit, v_total_credit
  from jsonb_array_elements(p_lines) x;

  if v_total_debit <= 0 or v_total_debit <> v_total_credit then
    raise exception 'Journal is not balanced';
  end if;

  insert into public.financial_transactions
    (organization_id, transaction_date, reference, description, source_type, source_id, posted, created_by)
  values
    (p_org, p_date, p_reference, p_description, p_source_type, p_source_id, true, auth.uid())
  returning id into v_tx;

  for v_line in select * from jsonb_array_elements(p_lines) loop
    insert into public.financial_transaction_lines
      (transaction_id, account_id, debit, credit, description)
    values
      (v_tx, (v_line->>'account_id')::uuid,
       coalesce((v_line->>'debit')::numeric,0),
       coalesce((v_line->>'credit')::numeric,0),
       v_line->>'description');
  end loop;

  return v_tx;
end;
$$;

create or replace function public.post_sale(p_sale_id uuid)
returns uuid
language plpgsql security definer set search_path = public
as $$
declare
  s public.sales%rowtype;
  v_ar uuid; v_revenue uuid; v_tax uuid; v_wht uuid; v_tx uuid;
  v_net_ar numeric(18,2);
  v_lines jsonb;
begin
  select * into s from public.sales where id = p_sale_id for update;
  if not found then raise exception 'Sale not found'; end if;
  if not public.is_org_member(s.organization_id) then raise exception 'Not authorized'; end if;
  if s.status <> 'DRAFT' then raise exception 'Only draft sales can be posted'; end if;

  v_ar := public.account_id_by_code(s.organization_id,'1100');
  v_revenue := public.account_id_by_code(s.organization_id,'4000');
  v_tax := public.account_id_by_code(s.organization_id,'2100');
  v_wht := public.account_id_by_code(s.organization_id,'1300');
  if v_ar is null or v_revenue is null then raise exception 'Default accounts are missing'; end if;

  v_net_ar := s.total_amount - s.withholding_amount;
  if v_net_ar < 0 then raise exception 'Withholding cannot exceed invoice total'; end if;

  v_lines := jsonb_build_array(
    jsonb_build_object('account_id',v_ar,'debit',v_net_ar,'credit',0,'description','Customer receivable'),
    jsonb_build_object('account_id',v_revenue,'debit',0,'credit',s.subtotal,'description','Sales revenue')
  );
  if s.tax_amount > 0 then
    v_lines := v_lines || jsonb_build_array(jsonb_build_object('account_id',v_tax,'debit',0,'credit',s.tax_amount,'description','Tax payable'));
  end if;
  if s.withholding_amount > 0 then
    v_lines := v_lines || jsonb_build_array(jsonb_build_object('account_id',v_wht,'debit',s.withholding_amount,'credit',0,'description','Withholding tax receivable'));
  end if;

  v_tx := public.post_journal(s.organization_id,s.sale_date,s.invoice_number,'Sale '||s.invoice_number,'SALE',s.id,v_lines);
  update public.sales set status='POSTED', updated_at=now() where id=s.id;
  insert into public.audit_logs(organization_id,actor_user_id,action,entity_type,entity_id,after_data)
  values(s.organization_id,auth.uid(),'POST','SALE',s.id,to_jsonb(s));
  return v_tx;
end;
$$;

create or replace function public.post_purchase(p_purchase_id uuid)
returns uuid
language plpgsql security definer set search_path = public
as $$
declare
  p public.purchases%rowtype;
  v_inventory uuid; v_tax uuid; v_ap uuid; v_wht uuid; v_tx uuid;
  v_net_ap numeric(18,2);
  v_lines jsonb;
begin
  select * into p from public.purchases where id=p_purchase_id for update;
  if not found then raise exception 'Purchase not found'; end if;
  if not public.is_org_member(p.organization_id) then raise exception 'Not authorized'; end if;
  if p.status <> 'DRAFT' then raise exception 'Only draft purchases can be posted'; end if;

  v_inventory := public.account_id_by_code(p.organization_id,'1200');
  v_tax := public.account_id_by_code(p.organization_id,'1310');
  v_ap := public.account_id_by_code(p.organization_id,'2000');
  v_wht := public.account_id_by_code(p.organization_id,'2200');
  if v_inventory is null or v_ap is null then raise exception 'Default accounts are missing'; end if;

  v_net_ap := p.total_amount - p.withholding_amount;
  if v_net_ap < 0 then raise exception 'Withholding cannot exceed invoice total'; end if;

  v_lines := jsonb_build_array(
    jsonb_build_object('account_id',v_inventory,'debit',p.subtotal,'credit',0,'description','Purchase / inventory'),
    jsonb_build_object('account_id',v_ap,'debit',0,'credit',v_net_ap,'description','Supplier payable')
  );
  if p.tax_amount > 0 then
    v_lines := v_lines || jsonb_build_array(jsonb_build_object('account_id',v_tax,'debit',p.tax_amount,'credit',0,'description','Tax receivable / credit'));
  end if;
  if p.withholding_amount > 0 then
    v_lines := v_lines || jsonb_build_array(jsonb_build_object('account_id',v_wht,'debit',0,'credit',p.withholding_amount,'description','Withholding tax payable'));
  end if;

  v_tx := public.post_journal(p.organization_id,p.purchase_date,p.invoice_number,'Purchase '||p.invoice_number,'PURCHASE',p.id,v_lines);
  update public.purchases set status='POSTED', updated_at=now() where id=p.id;
  insert into public.audit_logs(organization_id,actor_user_id,action,entity_type,entity_id,after_data)
  values(p.organization_id,auth.uid(),'POST','PURCHASE',p.id,to_jsonb(p));
  return v_tx;
end;
$$;

create or replace function public.record_payment(
  p_org uuid,
  p_direction public.payment_direction,
  p_date date,
  p_account_id uuid,
  p_contact_id uuid,
  p_source_type text,
  p_source_id uuid,
  p_amount numeric,
  p_reference text default null,
  p_notes text default null
)
returns uuid
language plpgsql security definer set search_path = public
as $$
declare
  v_payment uuid;
  v_ar uuid; v_ap uuid;
  v_lines jsonb;
  v_tx uuid;
begin
  if not public.is_org_member(p_org) then raise exception 'Not authorized'; end if;
  if p_amount <= 0 then raise exception 'Payment amount must be positive'; end if;
  if not exists(select 1 from public.accounts where id=p_account_id and organization_id=p_org and active) then raise exception 'Invalid payment account'; end if;

  v_ar := public.account_id_by_code(p_org,'1100');
  v_ap := public.account_id_by_code(p_org,'2000');

  insert into public.payments(organization_id,direction,payment_date,account_id,contact_id,source_type,source_id,amount,reference,notes,created_by)
  values(p_org,p_direction,p_date,p_account_id,p_contact_id,p_source_type,p_source_id,p_amount,p_reference,p_notes,auth.uid())
  returning id into v_payment;

  if p_direction='IN' then
    v_lines := jsonb_build_array(
      jsonb_build_object('account_id',p_account_id,'debit',p_amount,'credit',0,'description','Incoming payment'),
      jsonb_build_object('account_id',v_ar,'debit',0,'credit',p_amount,'description','Customer receivable settlement')
    );
  else
    v_lines := jsonb_build_array(
      jsonb_build_object('account_id',v_ap,'debit',p_amount,'credit',0,'description','Supplier payable settlement'),
      jsonb_build_object('account_id',p_account_id,'debit',0,'credit',p_amount,'description','Outgoing payment')
    );
  end if;

  v_tx := public.post_journal(p_org,p_date,p_reference,p_notes,'PAYMENT',v_payment,v_lines);
  return v_payment;
end;
$$;

create or replace view public.v_account_balances as
select
  a.organization_id,
  a.id as account_id,
  a.code,
  a.name,
  a.type,
  coalesce(sum(l.debit),0)::numeric(18,2) as debits,
  coalesce(sum(l.credit),0)::numeric(18,2) as credits,
  case when a.type in ('LIABILITY','EQUITY','INCOME','PAYABLE')
       then coalesce(sum(l.credit-l.debit),0)
       else coalesce(sum(l.debit-l.credit),0)
  end::numeric(18,2) as balance
from public.accounts a
left join public.financial_transaction_lines l on l.account_id=a.id
left join public.financial_transactions t on t.id=l.transaction_id and t.posted=true
where t.id is not null or l.id is null
group by a.organization_id,a.id,a.code,a.name,a.type;

create or replace view public.v_customer_balances as
with invoices as (
  select organization_id, customer_id as contact_id,
         sum(case when status in ('POSTED','PARTIALLY_PAID','PAID') then total_amount-withholding_amount else 0 end) as invoiced
  from public.sales
  group by organization_id, customer_id
), payments as (
  select organization_id, contact_id, sum(amount) as paid
  from public.payments
  where direction='IN' and source_type='SALE'
  group by organization_id, contact_id
)
select i.organization_id, i.contact_id, (i.invoiced-coalesce(p.paid,0))::numeric(18,2) as balance
from invoices i
left join payments p using (organization_id, contact_id);

create or replace view public.v_supplier_balances as
with bills as (
  select organization_id, supplier_id as contact_id,
         sum(case when status in ('POSTED','PARTIALLY_PAID','PAID') then total_amount-withholding_amount else 0 end) as billed
  from public.purchases
  group by organization_id, supplier_id
), payments as (
  select organization_id, contact_id, sum(amount) as paid
  from public.payments
  where direction='OUT' and source_type='PURCHASE'
  group by organization_id, contact_id
)
select b.organization_id, b.contact_id, (b.billed-coalesce(p.paid,0))::numeric(18,2) as balance
from bills b
left join payments p using (organization_id, contact_id);

create or replace view public.v_cash_balances as
select
  a.organization_id,
  a.id as account_id,
  a.code,
  a.name,
  coalesce(sum(case when t.posted then l.debit-l.credit else 0 end),0)::numeric(18,2) as balance
from public.accounts a
left join public.financial_transaction_lines l on l.account_id=a.id
left join public.financial_transactions t on t.id=l.transaction_id
where a.type in ('CASH','BANK')
group by a.organization_id,a.id,a.code,a.name;

-- Security: views execute with caller privileges by default; base tables remain protected by RLS.

alter view public.v_account_balances set (security_invoker = true);
alter view public.v_customer_balances set (security_invoker = true);
alter view public.v_supplier_balances set (security_invoker = true);
alter view public.v_cash_balances set (security_invoker = true);
