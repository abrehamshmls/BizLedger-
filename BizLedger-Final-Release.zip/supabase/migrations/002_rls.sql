-- BizLedger Phase 1C: RLS and helper functions

create or replace function public.is_org_member(target_org uuid)
returns boolean
language sql
stable
security definer
set search_path = public
as $$
  select exists (
    select 1 from public.organization_members m
    where m.organization_id = target_org
      and m.user_id = auth.uid()
      and m.status = 'ACTIVE'
  );
$$;

create or replace function public.has_permission(target_org uuid, permission_key text)
returns boolean
language sql
stable
security definer
set search_path = public
as $$
  select exists (
    select 1
    from public.organization_members m
    join public.role_permissions rp on rp.role_id = m.role_id
    where m.organization_id = target_org
      and m.user_id = auth.uid()
      and m.status = 'ACTIVE'
      and rp.permission_id = permission_key
  );
$$;

alter table public.organizations enable row level security;
alter table public.profiles enable row level security;
alter table public.roles enable row level security;
alter table public.permissions enable row level security;
alter table public.role_permissions enable row level security;
alter table public.organization_members enable row level security;
alter table public.organization_invitations enable row level security;
alter table public.organization_settings enable row level security;
alter table public.contacts enable row level security;
alter table public.products enable row level security;
alter table public.accounts enable row level security;
alter table public.sales enable row level security;
alter table public.sale_lines enable row level security;
alter table public.purchases enable row level security;
alter table public.purchase_lines enable row level security;
alter table public.expenses enable row level security;
alter table public.payments enable row level security;
alter table public.inventory_movements enable row level security;
alter table public.production_batches enable row level security;
alter table public.production_lines enable row level security;
alter table public.loans enable row level security;
alter table public.loan_payments enable row level security;
alter table public.withholding_received enable row level security;
alter table public.withholding_collected enable row level security;
alter table public.withholding_remittances enable row level security;
alter table public.financial_transactions enable row level security;
alter table public.financial_transaction_lines enable row level security;
alter table public.audit_logs enable row level security;

create policy profile_self on public.profiles for all using (id = auth.uid()) with check (id = auth.uid());
create policy org_member_access on public.organizations for select using (public.is_org_member(id));
create policy member_self_or_org on public.organization_members for select using (user_id = auth.uid() or public.is_org_member(organization_id));
create policy role_access on public.roles for select using (public.is_org_member(organization_id));
create policy permission_read on public.permissions for select using (auth.uid() is not null);
create policy role_permission_access on public.role_permissions for select using (
  exists (select 1 from public.roles r where r.id = role_id and public.is_org_member(r.organization_id))
);
create policy settings_access on public.organization_settings for all using (public.is_org_member(organization_id)) with check (public.is_org_member(organization_id));

create policy invitations_access on public.organization_invitations for select using (public.is_org_member(organization_id));

create policy contacts_access on public.contacts for all using (public.is_org_member(organization_id)) with check (public.is_org_member(organization_id));
create policy products_access on public.products for all using (public.is_org_member(organization_id)) with check (public.is_org_member(organization_id));
create policy accounts_access on public.accounts for all using (public.is_org_member(organization_id)) with check (public.is_org_member(organization_id));
create policy sales_access on public.sales for all using (public.is_org_member(organization_id)) with check (public.is_org_member(organization_id));
create policy purchases_access on public.purchases for all using (public.is_org_member(organization_id)) with check (public.is_org_member(organization_id));
create policy expenses_access on public.expenses for all using (public.is_org_member(organization_id)) with check (public.is_org_member(organization_id));
create policy payments_access on public.payments for all using (public.is_org_member(organization_id)) with check (public.is_org_member(organization_id));
create policy inventory_access on public.inventory_movements for all using (public.is_org_member(organization_id)) with check (public.is_org_member(organization_id));
create policy production_access on public.production_batches for all using (public.is_org_member(organization_id)) with check (public.is_org_member(organization_id));
create policy loans_access on public.loans for all using (public.is_org_member(organization_id)) with check (public.is_org_member(organization_id));
create policy loan_payments_access on public.loan_payments for all using (public.is_org_member(organization_id)) with check (public.is_org_member(organization_id));
create policy withholding_received_access on public.withholding_received for all using (public.is_org_member(organization_id)) with check (public.is_org_member(organization_id));
create policy withholding_collected_access on public.withholding_collected for all using (public.is_org_member(organization_id)) with check (public.is_org_member(organization_id));
create policy withholding_remittances_access on public.withholding_remittances for all using (public.is_org_member(organization_id)) with check (public.is_org_member(organization_id));
create policy financial_transactions_access on public.financial_transactions for all using (public.is_org_member(organization_id)) with check (public.is_org_member(organization_id));
create policy audit_read_access on public.audit_logs for select using (public.is_org_member(organization_id));

create policy sale_lines_access on public.sale_lines for all using (
  exists (select 1 from public.sales s where s.id = sale_id and public.is_org_member(s.organization_id))
) with check (
  exists (select 1 from public.sales s where s.id = sale_id and public.is_org_member(s.organization_id))
);
create policy purchase_lines_access on public.purchase_lines for all using (
  exists (select 1 from public.purchases p where p.id = purchase_id and public.is_org_member(p.organization_id))
) with check (
  exists (select 1 from public.purchases p where p.id = purchase_id and public.is_org_member(p.organization_id))
);
create policy production_lines_access on public.production_lines for all using (
  exists (select 1 from public.production_batches b where b.id = batch_id and public.is_org_member(b.organization_id))
) with check (
  exists (select 1 from public.production_batches b where b.id = batch_id and public.is_org_member(b.organization_id))
);
create policy financial_lines_access on public.financial_transaction_lines for all using (
  exists (select 1 from public.financial_transactions t where t.id = transaction_id and public.is_org_member(t.organization_id))
) with check (
  exists (select 1 from public.financial_transactions t where t.id = transaction_id and public.is_org_member(t.organization_id))
);
