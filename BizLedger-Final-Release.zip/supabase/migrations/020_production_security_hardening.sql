-- BizLedger Phase 17: production security hardening
-- Goal: prevent ordinary members from bypassing posting workflows by writing directly
-- to accounting/inventory tables through the browser API.

-- -----------------------------------------------------------------------------
-- Organizations: members can read; organization changes go through controlled RPCs.
-- -----------------------------------------------------------------------------
drop policy if exists org_member_access on public.organizations;
create policy organization_read on public.organizations for select
using (public.is_org_member(id));

-- -----------------------------------------------------------------------------
-- Master data: separate read and manage permissions.
-- -----------------------------------------------------------------------------
drop policy if exists contacts_access on public.contacts;
create policy contacts_read on public.contacts for select
using (public.is_org_member(organization_id) and public.has_permission(organization_id,'contacts.view'));
create policy contacts_insert on public.contacts for insert
with check (public.is_org_member(organization_id) and public.has_permission(organization_id,'contacts.manage'));
create policy contacts_update on public.contacts for update
using (public.is_org_member(organization_id) and public.has_permission(organization_id,'contacts.manage'))
with check (public.is_org_member(organization_id) and public.has_permission(organization_id,'contacts.manage'));


drop policy if exists products_access on public.products;
create policy products_read on public.products for select
using (public.is_org_member(organization_id) and public.has_permission(organization_id,'products.view'));
create policy products_insert on public.products for insert
with check (public.is_org_member(organization_id) and public.has_permission(organization_id,'products.manage'));
create policy products_update on public.products for update
using (public.is_org_member(organization_id) and public.has_permission(organization_id,'products.manage'))
with check (public.is_org_member(organization_id) and public.has_permission(organization_id,'products.manage'));

-- Accounts are reference data. Direct browser mutation is disabled; account setup
-- remains a controlled administrative/database workflow.
drop policy if exists accounts_access on public.accounts;
create policy accounts_read on public.accounts for select
using (public.is_org_member(organization_id));

-- -----------------------------------------------------------------------------
-- Sales and purchases: members may create/edit drafts; posting and voiding happen
-- only through the existing RPC workflow guarded by sales.post/purchases.post.
-- -----------------------------------------------------------------------------
drop policy if exists sales_access on public.sales;
create policy sales_read on public.sales for select
using (public.is_org_member(organization_id) and public.has_permission(organization_id,'sales.view'));
create policy sales_insert on public.sales for insert
with check (public.is_org_member(organization_id) and public.has_permission(organization_id,'sales.manage') and status='DRAFT');
create policy sales_update_draft on public.sales for update
using (public.is_org_member(organization_id) and public.has_permission(organization_id,'sales.manage') and status='DRAFT')
with check (public.is_org_member(organization_id) and public.has_permission(organization_id,'sales.manage') and status='DRAFT');
create policy sales_delete_draft on public.sales for delete
using (public.is_org_member(organization_id) and public.has_permission(organization_id,'sales.manage') and status='DRAFT');


drop policy if exists purchases_access on public.purchases;
create policy purchases_read on public.purchases for select
using (public.is_org_member(organization_id) and public.has_permission(organization_id,'purchases.view'));
create policy purchases_insert on public.purchases for insert
with check (public.is_org_member(organization_id) and public.has_permission(organization_id,'purchases.manage') and status='DRAFT');
create policy purchases_update_draft on public.purchases for update
using (public.is_org_member(organization_id) and public.has_permission(organization_id,'purchases.manage') and status='DRAFT')
with check (public.is_org_member(organization_id) and public.has_permission(organization_id,'purchases.manage') and status='DRAFT');
create policy purchases_delete_draft on public.purchases for delete
using (public.is_org_member(organization_id) and public.has_permission(organization_id,'purchases.manage') and status='DRAFT');

-- Lines follow their parent document. They can only be written while the parent
-- is still a draft.
drop policy if exists sale_lines_access on public.sale_lines;
create policy sale_lines_read on public.sale_lines for select
using (exists(select 1 from public.sales s where s.id=sale_id and public.is_org_member(s.organization_id) and public.has_permission(s.organization_id,'sales.view')));
create policy sale_lines_insert_draft on public.sale_lines for insert
with check (exists(select 1 from public.sales s where s.id=sale_id and s.status='DRAFT' and public.is_org_member(s.organization_id) and public.has_permission(s.organization_id,'sales.manage')));
create policy sale_lines_update_draft on public.sale_lines for update
using (exists(select 1 from public.sales s where s.id=sale_id and s.status='DRAFT' and public.is_org_member(s.organization_id) and public.has_permission(s.organization_id,'sales.manage')))
with check (exists(select 1 from public.sales s where s.id=sale_id and s.status='DRAFT' and public.is_org_member(s.organization_id) and public.has_permission(s.organization_id,'sales.manage')));
create policy sale_lines_delete_draft on public.sale_lines for delete
using (exists(select 1 from public.sales s where s.id=sale_id and s.status='DRAFT' and public.is_org_member(s.organization_id) and public.has_permission(s.organization_id,'sales.manage')));


drop policy if exists purchase_lines_access on public.purchase_lines;
create policy purchase_lines_read on public.purchase_lines for select
using (exists(select 1 from public.purchases p where p.id=purchase_id and public.is_org_member(p.organization_id) and public.has_permission(p.organization_id,'purchases.view')));
create policy purchase_lines_insert_draft on public.purchase_lines for insert
with check (exists(select 1 from public.purchases p where p.id=purchase_id and p.status='DRAFT' and public.is_org_member(p.organization_id) and public.has_permission(p.organization_id,'purchases.manage')));
create policy purchase_lines_update_draft on public.purchase_lines for update
using (exists(select 1 from public.purchases p where p.id=purchase_id and p.status='DRAFT' and public.is_org_member(p.organization_id) and public.has_permission(p.organization_id,'purchases.manage')))
with check (exists(select 1 from public.purchases p where p.id=purchase_id and p.status='DRAFT' and public.is_org_member(p.organization_id) and public.has_permission(p.organization_id,'purchases.manage')));
create policy purchase_lines_delete_draft on public.purchase_lines for delete
using (exists(select 1 from public.purchases p where p.id=purchase_id and p.status='DRAFT' and public.is_org_member(p.organization_id) and public.has_permission(p.organization_id,'purchases.manage')));

-- -----------------------------------------------------------------------------
-- Expenses: draft editing only. Posting/voiding is RPC-controlled.
-- -----------------------------------------------------------------------------
drop policy if exists expenses_access on public.expenses;
create policy expenses_read on public.expenses for select
using (public.is_org_member(organization_id) and public.has_permission(organization_id,'expenses.view'));
create policy expenses_insert on public.expenses for insert
with check (public.is_org_member(organization_id) and public.has_permission(organization_id,'expenses.manage') and status='DRAFT');
create policy expenses_update_draft on public.expenses for update
using (public.is_org_member(organization_id) and public.has_permission(organization_id,'expenses.manage') and status='DRAFT')
with check (public.is_org_member(organization_id) and public.has_permission(organization_id,'expenses.manage') and status='DRAFT');
create policy expenses_delete_draft on public.expenses for delete
using (public.is_org_member(organization_id) and public.has_permission(organization_id,'expenses.manage') and status='DRAFT');

-- -----------------------------------------------------------------------------
-- Payments: readable by payments.view; creation requires payments.manage. There
-- is deliberately no browser update/delete policy. Corrections use reversal/void
-- workflows rather than destructive edits.
-- -----------------------------------------------------------------------------
drop policy if exists payments_access on public.payments;
create policy payments_read on public.payments for select
using (public.is_org_member(organization_id) and public.has_permission(organization_id,'payments.view'));
create policy payments_insert on public.payments for insert
with check (public.is_org_member(organization_id) and public.has_permission(organization_id,'payments.manage'));

-- -----------------------------------------------------------------------------
-- Inventory, production, loans and withholding are accounting-affecting. Browser
-- writes are disabled; their existing posting/recording RPCs remain the write path.
-- -----------------------------------------------------------------------------
drop policy if exists inventory_access on public.inventory_movements;
create policy inventory_read on public.inventory_movements for select
using (public.is_org_member(organization_id) and public.has_permission(organization_id,'inventory.view'));


drop policy if exists production_access on public.production_batches;
create policy production_read on public.production_batches for select
using (public.is_org_member(organization_id) and public.has_permission(organization_id,'production.view'));


drop policy if exists production_lines_access on public.production_lines;
create policy production_lines_read on public.production_lines for select
using (exists(select 1 from public.production_batches b where b.id=batch_id and public.is_org_member(b.organization_id) and public.has_permission(b.organization_id,'production.view')));


drop policy if exists loans_access on public.loans;
create policy loans_read on public.loans for select
using (public.is_org_member(organization_id) and public.has_permission(organization_id,'loans.view'));


drop policy if exists loan_payments_access on public.loan_payments;
create policy loan_payments_read on public.loan_payments for select
using (public.is_org_member(organization_id) and public.has_permission(organization_id,'loans.view'));


drop policy if exists withholding_received_access on public.withholding_received;
create policy withholding_received_read on public.withholding_received for select
using (public.is_org_member(organization_id) and public.has_permission(organization_id,'withholding.view'));


drop policy if exists withholding_collected_access on public.withholding_collected;
create policy withholding_collected_read on public.withholding_collected for select
using (public.is_org_member(organization_id) and public.has_permission(organization_id,'withholding.view'));


drop policy if exists withholding_remittances_access on public.withholding_remittances;
create policy withholding_remittances_read on public.withholding_remittances for select
using (public.is_org_member(organization_id) and public.has_permission(organization_id,'withholding.view'));

-- Journal tables are never directly writable from the browser. Posting RPCs are
-- SECURITY DEFINER and perform the controlled accounting writes.
drop policy if exists financial_transactions_access on public.financial_transactions;
create policy financial_transactions_read on public.financial_transactions for select
using (public.is_org_member(organization_id));

drop policy if exists financial_lines_access on public.financial_transaction_lines;
create policy financial_lines_read on public.financial_transaction_lines for select
using (exists(select 1 from public.financial_transactions t where t.id=transaction_id and public.is_org_member(t.organization_id)));

-- Audit logs are append-only through controlled functions.
drop policy if exists audit_read_access on public.audit_logs;
create policy audit_read on public.audit_logs for select
using (public.is_org_member(organization_id) and public.has_permission(organization_id,'audit.view'));

-- -----------------------------------------------------------------------------
-- Protect system role/permission definitions from browser-side mutation.
-- -----------------------------------------------------------------------------
drop policy if exists role_access on public.roles;
create policy roles_read on public.roles for select
using (public.is_org_member(organization_id));

drop policy if exists permission_read on public.permissions;
create policy permissions_read on public.permissions for select
using (auth.uid() is not null);

drop policy if exists role_permission_access on public.role_permissions;
create policy role_permissions_read on public.role_permissions for select
using (exists(select 1 from public.roles r where r.id=role_id and public.is_org_member(r.organization_id)));

-- -----------------------------------------------------------------------------
-- Cutover lock helper: production writes are rejected once the organization has
-- been formally locked. The existing migration cutover RPC owns this state.
-- -----------------------------------------------------------------------------
create or replace function public.is_cutover_locked(p_org uuid)
returns boolean
language sql stable security definer set search_path=public
as $$
  select exists (
    select 1 from public.migration_cutover_signoffs
    where organization_id=p_org and status='LOCKED'
  );
$$;

revoke all on function public.is_cutover_locked(uuid) from public;
grant execute on function public.is_cutover_locked(uuid) to authenticated;

-- Defense-in-depth: application workflows can call this before beginning a
-- financial mutation. Migration RPCs remain responsible for their own validation.
comment on function public.is_cutover_locked(uuid) is
'Returns true after migration cutover is locked for an organization; financial workflows should reject new mutations while locked.';
