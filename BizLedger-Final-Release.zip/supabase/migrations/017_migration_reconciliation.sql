-- BizLedger Phase 14: migration reconciliation and controlled cutover
-- Read-only reconciliation plus explicit sign-off. No production records are created here.

create table if not exists public.migration_reconciliation_runs (
  id uuid primary key default gen_random_uuid(),
  batch_id uuid not null references public.migration_batches(id) on delete cascade,
  organization_id uuid not null references public.organizations(id) on delete cascade,
  status text not null default 'GENERATED' check (status in ('GENERATED','SIGNED_OFF','REJECTED')),
  result jsonb not null default '{}'::jsonb,
  created_by uuid references auth.users(id) on delete set null,
  created_at timestamptz not null default now(),
  signed_off_at timestamptz,
  signed_off_by uuid references auth.users(id) on delete set null,
  notes text
);
create index if not exists idx_migration_reconciliation_batch on public.migration_reconciliation_runs(batch_id,created_at desc);
alter table public.migration_reconciliation_runs enable row level security;
drop policy if exists migration_reconciliation_admin on public.migration_reconciliation_runs;
create policy migration_reconciliation_admin on public.migration_reconciliation_runs for all
using (public.has_permission(organization_id,'members.manage'))
with check (public.has_permission(organization_id,'members.manage'));

create or replace function public.get_migration_reconciliation(p_batch uuid)
returns jsonb
language plpgsql security definer set search_path=public as $$
declare
  b public.migration_batches%rowtype;
  v_core jsonb;
  v_modules jsonb;
  v_sales_legacy numeric(18,2);
  v_sales_new numeric(18,2);
  v_purchases_legacy numeric(18,2);
  v_purchases_new numeric(18,2);
  v_expenses_legacy numeric(18,2);
  v_expenses_new numeric(18,2);
  v_payment_legacy numeric(18,2);
  v_payment_new numeric(18,2);
  v_ar numeric(18,2);
  v_ap numeric(18,2);
  v_j_debit numeric(18,2);
  v_j_credit numeric(18,2);
  v_duplicate_keys integer;
  v_unimported integer;
  v_result jsonb;
begin
  select * into b from public.migration_batches where id=p_batch;
  if not found then raise exception 'Migration batch not found'; end if;
  if not public.has_permission(b.organization_id,'members.manage') then raise exception 'Not authorized'; end if;

  select
    coalesce(sum(proposed_amount) filter(where module='sales'),0),
    coalesce(sum(proposed_amount) filter(where module='purchases'),0),
    coalesce(sum(proposed_amount) filter(where module='expenses'),0),
    coalesce(sum(proposed_amount) filter(where module='txpay'),0),
    count(*) filter(where status not in ('IMPORTED','SKIPPED'))
  into v_sales_legacy,v_purchases_legacy,v_expenses_legacy,v_payment_legacy,v_unimported
  from public.migration_financial_rows where batch_id=p_batch;

  select coalesce(sum(s.total_amount),0) into v_sales_new
  from public.sales s join public.migration_financial_rows f on f.proposed_source_id=s.id and f.batch_id=p_batch and f.module='sales' and f.status='IMPORTED';
  select coalesce(sum(p.total_amount),0) into v_purchases_new
  from public.purchases p join public.migration_financial_rows f on f.proposed_source_id=p.id and f.batch_id=p_batch and f.module='purchases' and f.status='IMPORTED';
  select coalesce(sum(e.amount+e.tax_amount),0) into v_expenses_new
  from public.expenses e join public.migration_financial_rows f on f.proposed_source_id=e.id and f.batch_id=p_batch and f.module='expenses' and f.status='IMPORTED';
  select coalesce(sum(pay.amount),0) into v_payment_new
  from public.payments pay
  where pay.organization_id=b.organization_id
    and exists (select 1 from public.migration_financial_rows f where f.batch_id=p_batch and f.module='txpay' and f.status='IMPORTED' and f.proposed_source_id=pay.id);

  -- Current outstanding balances for imported documents.
  select coalesce(sum(s.total_amount-s.withholding_amount),0) - coalesce((select sum(p.amount) from public.payments p join public.migration_financial_rows f on f.proposed_source_id=p.id and f.batch_id=p_batch and f.module='txpay' and f.status='IMPORTED' where p.source_type='SALE'),0)
  into v_ar
  from public.sales s join public.migration_financial_rows f on f.proposed_source_id=s.id and f.batch_id=p_batch and f.module='sales' and f.status='IMPORTED'
  where s.status in ('POSTED','PARTIALLY_PAID','PAID');

  select coalesce(sum(p.total_amount-p.withholding_amount),0) - coalesce((select sum(x.amount) from public.payments x join public.migration_financial_rows f on f.proposed_source_id=x.id and f.batch_id=p_batch and f.module='txpay' and f.status='IMPORTED' where x.source_type='PURCHASE'),0)
  into v_ap
  from public.purchases p join public.migration_financial_rows f on f.proposed_source_id=p.id and f.batch_id=p_batch and f.module='purchases' and f.status='IMPORTED'
  where p.status in ('POSTED','PARTIALLY_PAID','PAID');

  select coalesce(sum(l.debit),0),coalesce(sum(l.credit),0)
  into v_j_debit,v_j_credit
  from public.financial_transaction_lines l
  join public.financial_transactions t on t.id=l.transaction_id
  where t.organization_id=b.organization_id and t.posted=true;

  select count(*) into v_duplicate_keys from (
    select module,coalesce(nullif(trim(proposed_document_key),''),'') key,count(*) n
    from public.migration_financial_rows where batch_id=p_batch and module in ('sales','purchases','expenses','txpay')
    group by module,coalesce(nullif(trim(proposed_document_key),''),'') having count(*)>1
  ) d;

  select coalesce(jsonb_object_agg(module, jsonb_build_object(
    'rows',count(*), 'imported',count(*) filter(where status='IMPORTED'),
    'review',count(*) filter(where status='REVIEW'), 'errors',count(*) filter(where status='ERROR'),
    'skipped',count(*) filter(where status='SKIPPED'), 'amount',coalesce(sum(proposed_amount),0)
  )),'{}'::jsonb) into v_modules
  from public.migration_financial_rows where batch_id=p_batch group by module;

  v_core:=jsonb_build_object(
    'sales',jsonb_build_object('legacy',v_sales_legacy,'new',v_sales_new,'difference',round(v_sales_new-v_sales_legacy,2)),
    'purchases',jsonb_build_object('legacy',v_purchases_legacy,'new',v_purchases_new,'difference',round(v_purchases_new-v_purchases_legacy,2)),
    'expenses',jsonb_build_object('legacy',v_expenses_legacy,'new',v_expenses_new,'difference',round(v_expenses_new-v_expenses_legacy,2)),
    'payments',jsonb_build_object('legacy',v_payment_legacy,'new',v_payment_new,'difference',round(v_payment_new-v_payment_legacy,2)),
    'receivables',round(coalesce(v_ar,0),2),'payables',round(coalesce(v_ap,0),2)
  );

  v_result:=jsonb_build_object(
    'batch_id',p_batch,
    'batch_status',b.status,
    'modules',coalesce(v_modules,'{}'::jsonb),
    'core',v_core,
    'journal',jsonb_build_object('debits',v_j_debit,'credits',v_j_credit,'difference',round(v_j_debit-v_j_credit,2),'balanced',abs(v_j_debit-v_j_credit)<0.01),
    'duplicate_staged_keys',v_duplicate_keys,
    'unimported_rows',v_unimported,
    'full_cutover_ready',(
      b.status='IMPORTED' and v_unimported=0 and v_duplicate_keys=0 and abs(v_j_debit-v_j_credit)<0.01
      and abs(v_sales_new-v_sales_legacy)<0.01 and abs(v_purchases_new-v_purchases_legacy)<0.01
      and abs(v_expenses_new-v_expenses_legacy)<0.01 and abs(v_payment_new-v_payment_legacy)<0.01
    )
  );
  return v_result;
end;
$$;
grant execute on function public.get_migration_reconciliation(uuid) to authenticated;

create or replace function public.sign_off_migration_reconciliation(p_batch uuid,p_notes text default null)
returns jsonb
language plpgsql security definer set search_path=public as $$
declare
  b public.migration_batches%rowtype;
  r jsonb;
  id uuid;
begin
  select * into b from public.migration_batches where id=p_batch;
  if not found then raise exception 'Migration batch not found'; end if;
  if not public.has_permission(b.organization_id,'members.manage') then raise exception 'Not authorized'; end if;
  r:=public.get_migration_reconciliation(p_batch);
  if coalesce((r->>'full_cutover_ready')::boolean,false) is not true then
    raise exception 'Migration is not ready for full cutover: %',r;
  end if;
  insert into public.migration_reconciliation_runs(batch_id,organization_id,status,result,created_by,signed_off_at,signed_off_by,notes)
  values(p_batch,b.organization_id,'SIGNED_OFF',r,auth.uid(),now(),auth.uid(),p_notes)
  returning id into id;
  insert into public.audit_logs(organization_id,actor_user_id,action,entity_type,entity_id,metadata)
  values(b.organization_id,auth.uid(),'MIGRATION_SIGNED_OFF','migration_batch',p_batch,jsonb_build_object('reconciliation_run',id,'notes',p_notes));
  return r || jsonb_build_object('signed_off',true,'reconciliation_run_id',id);
end;
$$;
grant execute on function public.sign_off_migration_reconciliation(uuid,text) to authenticated;
