-- BizLedger Phase 16: operational integrity diagnostics.
-- Read-only checks intended for production support and pre-release verification.

create or replace function public.get_operational_integrity_report(p_org uuid)
returns jsonb
language plpgsql
security definer
set search_path=public
as $$
declare
  v_result jsonb := '[]'::jsonb;
  v_count bigint;
  v_total bigint := 0;
  v_failed bigint := 0;
  v_locked boolean := false;
begin
  if not public.is_org_member(p_org) then raise exception 'Not authorized'; end if;

  select coalesce(locked,false) into v_locked from public.migration_cutover_state where organization_id=p_org;
  v_result := v_result || jsonb_build_array(jsonb_build_object('code','CUTOVER_STATE','label','Cutover state is explicit','ok',true,'count',case when v_locked then 1 else 0 end,'detail',case when v_locked then 'Organization is locked.' else 'Organization is not locked.' end));
  v_total:=v_total+1;

  select count(*) into v_count from (select ft.id from public.financial_transactions ft join public.financial_transaction_lines l on l.transaction_id=ft.id where ft.organization_id=p_org and ft.posted=true group by ft.id having round(sum(l.debit),2)<>round(sum(l.credit),2)) q;
  v_result:=v_result||jsonb_build_array(jsonb_build_object('code','UNBALANCED_JOURNALS','label','Posted journals are balanced','ok',v_count=0,'count',v_count,'detail','Posted journal entries whose debit and credit totals differ.')); v_total:=v_total+1; if v_count<>0 then v_failed:=v_failed+1; end if;

  select count(*) into v_count from public.sales s where s.organization_id=p_org and s.status in ('POSTED','PARTIALLY_PAID','PAID') and not exists(select 1 from public.financial_transactions ft where ft.organization_id=p_org and ft.source_type='SALE' and ft.source_id=s.id and ft.posted=true);
  v_result:=v_result||jsonb_build_array(jsonb_build_object('code','SALES_WITHOUT_JOURNAL','label','Posted sales have journal entries','ok',v_count=0,'count',v_count,'detail','Sales without a matching posted journal.')); v_total:=v_total+1; if v_count<>0 then v_failed:=v_failed+1; end if;

  select count(*) into v_count from public.purchases p where p.organization_id=p_org and p.status in ('POSTED','PARTIALLY_PAID','PAID') and not exists(select 1 from public.financial_transactions ft where ft.organization_id=p_org and ft.source_type='PURCHASE' and ft.source_id=p.id and ft.posted=true);
  v_result:=v_result||jsonb_build_array(jsonb_build_object('code','PURCHASES_WITHOUT_JOURNAL','label','Posted purchases have journal entries','ok',v_count=0,'count',v_count,'detail','Purchases without a matching posted journal.')); v_total:=v_total+1; if v_count<>0 then v_failed:=v_failed+1; end if;

  select count(*) into v_count from public.expenses e where e.organization_id=p_org and e.status in ('POSTED','PARTIALLY_PAID','PAID') and not exists(select 1 from public.financial_transactions ft where ft.organization_id=p_org and ft.source_type='EXPENSE' and ft.source_id=e.id and ft.posted=true);
  v_result:=v_result||jsonb_build_array(jsonb_build_object('code','EXPENSES_WITHOUT_JOURNAL','label','Posted expenses have journal entries','ok',v_count=0,'count',v_count,'detail','Expenses without a matching posted journal.')); v_total:=v_total+1; if v_count<>0 then v_failed:=v_failed+1; end if;

  select count(*) into v_count from public.payments p where p.organization_id=p_org and (p.account_id is null or not exists(select 1 from public.accounts a where a.id=p.account_id and a.organization_id=p_org));
  v_result:=v_result||jsonb_build_array(jsonb_build_object('code','PAYMENT_ACCOUNT_ORPHANS','label','Payments reference valid accounts','ok',v_count=0,'count',v_count,'detail','Payment rows whose account reference is missing or foreign.')); v_total:=v_total+1; if v_count<>0 then v_failed:=v_failed+1; end if;

  select count(*) into v_count from public.financial_transaction_lines l join public.financial_transactions ft on ft.id=l.transaction_id join public.accounts a on a.id=l.account_id where ft.organization_id=p_org and a.organization_id<>p_org;
  v_result:=v_result||jsonb_build_array(jsonb_build_object('code','JOURNAL_ACCOUNT_CROSS_ORG','label','Journal lines use same-organization accounts','ok',v_count=0,'count',v_count,'detail','Cross-organization account references in journal lines.')); v_total:=v_total+1; if v_count<>0 then v_failed:=v_failed+1; end if;

  select count(*) into v_count from public.sale_lines sl join public.sales s on s.id=sl.sale_id join public.products p on p.id=sl.product_id where s.organization_id=p_org and p.organization_id<>p_org;
  v_result:=v_result||jsonb_build_array(jsonb_build_object('code','SALE_PRODUCT_CROSS_ORG','label','Sale lines use same-organization products','ok',v_count=0,'count',v_count,'detail','Sale line product references crossing organization boundaries.')); v_total:=v_total+1; if v_count<>0 then v_failed:=v_failed+1; end if;

  select count(*) into v_count from public.purchase_lines pl join public.purchases pu on pu.id=pl.purchase_id join public.products p on p.id=pl.product_id where pu.organization_id=p_org and p.organization_id<>p_org;
  v_result:=v_result||jsonb_build_array(jsonb_build_object('code','PURCHASE_PRODUCT_CROSS_ORG','label','Purchase lines use same-organization products','ok',v_count=0,'count',v_count,'detail','Purchase line product references crossing organization boundaries.')); v_total:=v_total+1; if v_count<>0 then v_failed:=v_failed+1; end if;

  select count(*) into v_count from public.inventory_movements im join public.products p on p.id=im.product_id where im.organization_id=p_org and p.organization_id<>p_org;
  v_result:=v_result||jsonb_build_array(jsonb_build_object('code','INVENTORY_PRODUCT_CROSS_ORG','label','Inventory movements use same-organization products','ok',v_count=0,'count',v_count,'detail','Inventory product references crossing organization boundaries.')); v_total:=v_total+1; if v_count<>0 then v_failed:=v_failed+1; end if;

  select count(*) into v_count from public.production_lines pl join public.production_batches b on b.id=pl.batch_id join public.products p on p.id=pl.product_id where b.organization_id=p_org and p.organization_id<>p_org;
  v_result:=v_result||jsonb_build_array(jsonb_build_object('code','PRODUCTION_PRODUCT_CROSS_ORG','label','Production lines use same-organization products','ok',v_count=0,'count',v_count,'detail','Production product references crossing organization boundaries.')); v_total:=v_total+1; if v_count<>0 then v_failed:=v_failed+1; end if;

  select count(*) into v_count from public.loan_payments lp join public.loans l on l.id=lp.loan_id where lp.organization_id=p_org and l.organization_id<>p_org;
  v_result:=v_result||jsonb_build_array(jsonb_build_object('code','LOAN_CROSS_ORG','label','Loan repayments use same-organization loans','ok',v_count=0,'count',v_count,'detail','Loan repayment references crossing organization boundaries.')); v_total:=v_total+1; if v_count<>0 then v_failed:=v_failed+1; end if;

  select count(*) into v_count from (select im.product_id from public.inventory_movements im join public.products p on p.id=im.product_id where im.organization_id=p_org and p.track_inventory=true group by im.product_id having sum(im.quantity)<0) n;
  v_result:=v_result||jsonb_build_array(jsonb_build_object('code','NEGATIVE_STOCK','label','Tracked products do not have negative stock','ok',v_count=0,'count',v_count,'detail','Products whose net inventory movement is below zero.')); v_total:=v_total+1; if v_count<>0 then v_failed:=v_failed+1; end if;

  select count(*) into v_count from public.organization_settings s where s.organization_id=p_org and s.default_payment_account is not null and not exists(select 1 from public.accounts a where a.id=s.default_payment_account and a.organization_id=p_org and a.active=true);
  v_result:=v_result||jsonb_build_array(jsonb_build_object('code','DEFAULT_PAYMENT_ACCOUNT','label','Default payment account is valid','ok',v_count=0,'count',v_count,'detail','Organization setting points to a missing, inactive, or foreign account.')); v_total:=v_total+1; if v_count<>0 then v_failed:=v_failed+1; end if;

  select count(*) into v_count from public.audit_logs a where a.organization_id=p_org and coalesce(trim(a.action),'')='';
  v_result:=v_result||jsonb_build_array(jsonb_build_object('code','AUDIT_LOG_SHAPE','label','Audit log rows have actions','ok',v_count=0,'count',v_count,'detail','Audit records missing the required action value.')); v_total:=v_total+1; if v_count<>0 then v_failed:=v_failed+1; end if;

  return jsonb_build_object('organization_id',p_org,'generated_at',now(),'cutover_locked',coalesce(v_locked,false),'checks',v_result,'total_checks',v_total,'failed_checks',v_failed,'ready',v_failed=0);
end;
$$;

grant execute on function public.get_operational_integrity_report(uuid) to authenticated;
