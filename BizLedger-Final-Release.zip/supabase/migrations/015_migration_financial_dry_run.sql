-- BizLedger Phase 11: financial migration dry-run staging
-- This phase NEVER inserts into sales/purchases/expenses/payments/loans/withholding.
create table if not exists public.migration_financial_rows (
  id uuid primary key default gen_random_uuid(),
  batch_id uuid not null references public.migration_batches(id) on delete cascade,
  module text not null check (module in ('sales','purchases','expenses','txpay','cashbook','inventory','production','loans','loanpay','wht','whc','whremit')),
  row_number integer not null,
  proposed_document_key text,
  proposed_source_id uuid,
  proposed_contact_id uuid,
  proposed_product_id uuid,
  proposed_date date,
  proposed_amount numeric(18,2),
  proposed_quantity numeric(18,6),
  status text not null default 'READY' check (status in ('READY','REVIEW','ERROR','IMPORTED','SKIPPED')),
  issues jsonb not null default '[]'::jsonb,
  raw_data jsonb not null,
  created_at timestamptz not null default now(),
  unique(batch_id,module,row_number)
);
create index if not exists idx_migration_financial_batch on public.migration_financial_rows(batch_id,module,status);

alter table public.migration_financial_rows enable row level security;
drop policy if exists migration_financial_rows_admin on public.migration_financial_rows;
create policy migration_financial_rows_admin on public.migration_financial_rows for all
using (exists(select 1 from public.migration_batches b where b.id=batch_id and public.has_permission(b.organization_id,'members.manage')))
with check (exists(select 1 from public.migration_batches b where b.id=batch_id and public.has_permission(b.organization_id,'members.manage')));

create or replace function public.get_migration_financial_summary(p_batch uuid)
returns jsonb language plpgsql security definer set search_path=public as $$
declare v_org uuid; v jsonb;
begin
  select organization_id into v_org from public.migration_batches where id=p_batch;
  if v_org is null then raise exception 'Migration batch not found'; end if;
  if not public.has_permission(v_org,'members.manage') then raise exception 'Not authorized'; end if;
  select jsonb_build_object(
    'rows',count(*),
    'ready',count(*) filter(where status='READY'),
    'review',count(*) filter(where status='REVIEW'),
    'error',count(*) filter(where status='ERROR'),
    'by_module',coalesce((select jsonb_object_agg(module, n) from (select module,count(*) n from public.migration_financial_rows where batch_id=p_batch group by module) s),'{}'::jsonb),
    'amounts',coalesce((select jsonb_object_agg(module, amount) from (select module,coalesce(sum(proposed_amount),0) amount from public.migration_financial_rows where batch_id=p_batch group by module) s),'{}'::jsonb)
  ) into v from public.migration_financial_rows where batch_id=p_batch;
  return coalesce(v,'{}'::jsonb);
end;
$$;

revoke all on function public.get_migration_financial_summary(uuid) from public;
grant execute on function public.get_migration_financial_summary(uuid) to authenticated;
